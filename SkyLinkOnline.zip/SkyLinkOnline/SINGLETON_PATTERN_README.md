# Singleton Pattern Implementation in SkyLinkOnline

This document explains the Singleton pattern implementation added to the SkyLinkOnline project.

## 🎯 Overview

The Singleton pattern ensures that a class has only one instance and provides a global point of access to it. In this project, we've implemented three Singleton classes to manage different aspects of the application:

1. **DatabaseConnectionManager** - Manages database connections
2. **Logger** - Handles application logging
3. **ConfigurationManager** - Manages application configuration

## 📁 Files Added/Modified

### New Files Created:

- `src/main/java/com/example/util/DatabaseConnectionManager.java`
- `src/main/java/com/example/util/Logger.java`
- `src/main/java/com/example/util/ConfigurationManager.java`
- `src/main/java/com/example/servlets/SingletonDemoServlet.java`

### Modified Files:

- `src/main/java/com/example/util/DatabaseConnection.java` - Updated to use Singleton pattern
- `src/main/java/com/example/servlets/LoginServlet.java` - Updated to use Logger Singleton

## 🔧 Implementation Details

### 1. DatabaseConnectionManager Singleton

**Purpose**: Manages database connections with connection pooling for better performance.

**Key Features**:

- Thread-safe Singleton implementation using double-checked locking
- Connection pooling to reuse connections
- Thread-specific connection management
- Automatic connection cleanup

**Usage**:

```java
// Get the singleton instance
DatabaseConnectionManager connMgr = DatabaseConnectionManager.getInstance();

// Get a connection
Connection conn = connMgr.getConnection();

// Close a connection
connMgr.closeConnection(conn);

// Get connection pool status
String status = connMgr.getConnectionPoolStatus();
```

### 2. Logger Singleton

**Purpose**: Provides centralized logging functionality for the entire application.

**Key Features**:

- Thread-safe Singleton implementation
- Multiple log levels (DEBUG, INFO, WARN, ERROR, FATAL)
- File-based logging with console output
- Configurable log levels
- Thread-safe file operations

**Usage**:

```java
// Get the singleton instance
Logger logger = Logger.getInstance();

// Log messages
logger.info("Application started");
logger.error("Error occurred", exception);
logger.debug("Debug information");

// Set log level
logger.setLogLevel(Logger.LogLevel.DEBUG);

// Clear log file
logger.clearLogFile();
```

### 3. ConfigurationManager Singleton

**Purpose**: Manages application configuration properties.

**Key Features**:

- Thread-safe Singleton implementation
- Load/save configuration from/to files
- Default configuration values
- Thread-safe read-write operations
- Property validation

**Usage**:

```java
// Get the singleton instance
ConfigurationManager config = ConfigurationManager.getInstance();

// Get configuration values
String dbUrl = config.getDatabaseUrl();
boolean debugMode = config.isDebugEnabled();
int sessionTimeout = config.getSessionTimeout();

// Set configuration values
config.setProperty("custom.property", "value");

// Save configuration
config.saveConfiguration();
```

## 🚀 How to Use

### 1. Database Connections

The existing `DatabaseConnection` class now acts as a facade to the `DatabaseConnectionManager` Singleton:

```java
// Existing code continues to work
Connection conn = DatabaseConnection.getConnection();
DatabaseConnection.closeConnection(conn);

// New features available
int activeConnections = DatabaseConnection.getActiveConnectionCount();
String poolStatus = DatabaseConnection.getConnectionPoolStatus();
```

### 2. Logging

Replace `System.out.println()` calls with Logger Singleton:

```java
// Old way
System.out.println("User logged in: " + username);

// New way
Logger logger = Logger.getInstance();
logger.info("User logged in: " + username);
```

### 3. Configuration

Access application configuration through the ConfigurationManager:

```java
ConfigurationManager config = ConfigurationManager.getInstance();
String appName = config.getApplicationName();
String dbUrl = config.getDatabaseUrl();
```

## 🧪 Testing the Implementation

### 1. Access the Demo Servlet

Navigate to: `http://localhost:8080/SkyLinkOnline/singleton-demo`

This will show:

- All Singleton instances working
- Connection pool status
- Configuration values
- Logging functionality
- Singleton pattern verification

### 2. Check Log Files

- Application logs: `logs/skylink_application.log`
- Configuration file: `config/application.properties`

## 🔒 Thread Safety

All Singleton implementations are thread-safe:

1. **Double-checked locking** for lazy initialization
2. **Volatile keyword** for instance variables
3. **Synchronized blocks** for critical sections
4. **ReadWriteLock** for configuration access
5. **ReentrantLock** for file operations

## 📊 Benefits

### 1. Resource Management

- Single instance manages database connections efficiently
- Connection pooling reduces overhead
- Automatic cleanup prevents memory leaks

### 2. Configuration Centralization

- All configuration in one place
- Easy to modify and maintain
- Default values for missing properties

### 3. Logging Consistency

- Unified logging across the application
- Configurable log levels
- File and console output

### 4. Thread Safety

- Safe for concurrent access
- No race conditions
- Proper synchronization

### 5. Memory Efficiency

- No duplicate instances
- Reduced memory footprint
- Better performance

## 🛠️ Configuration

### Default Configuration Values

The `ConfigurationManager` comes with default values:

```properties
database.url=jdbc:sqlserver://localhost;databaseName=SkyLinkOnline;integratedSecurity=false;
database.username=sa
database.password=789
application.name=SkyLinkOnline
application.version=1.0.0
logging.level=INFO
session.timeout=1800
max.connections=10
```

### Customizing Configuration

1. Modify `config/application.properties` file
2. Use `ConfigurationManager.setProperty()` method
3. Call `ConfigurationManager.saveConfiguration()` to persist changes

## 🔍 Monitoring

### Connection Pool Monitoring

```java
// Check active connections
int activeConnections = DatabaseConnection.getActiveConnectionCount();

// Get pool status
String status = DatabaseConnection.getConnectionPoolStatus();

// Close all connections (for shutdown)
DatabaseConnection.closeAllConnections();
```

### Logging Monitoring

```java
// Check log level
Logger.LogLevel level = logger.getLogLevel();

// Get log file path
String logFile = logger.getLogFilePath();

// Clear logs
logger.clearLogFile();
```

## 🚨 Important Notes

### 1. Singleton Limitations

- Can make testing difficult
- Hidden dependencies
- Global state management

### 2. Best Practices

- Use Singleton only when truly needed
- Ensure thread safety
- Provide proper cleanup methods
- Consider dependency injection alternatives

### 3. Migration Guide

To migrate existing code:

1. **Replace System.out.println()**:

   ```java
   // Old
   System.out.println("Message");

   // New
   Logger.getInstance().info("Message");
   ```

2. **Use ConfigurationManager**:

   ```java
   // Old
   String dbUrl = "jdbc:sqlserver://localhost;...";

   // New
   String dbUrl = ConfigurationManager.getInstance().getDatabaseUrl();
   ```

3. **Database connections remain the same**:
   ```java
   // No changes needed - facade pattern maintains compatibility
   Connection conn = DatabaseConnection.getConnection();
   ```

## 📝 Example Usage in Servlets

```java
@WebServlet("/example")
public class ExampleServlet extends HttpServlet {

    // Singleton instances
    private static final Logger logger = Logger.getInstance();
    private static final ConfigurationManager config = ConfigurationManager.getInstance();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        logger.info("ExampleServlet accessed");

        try {
            // Use database connection
            Connection conn = DatabaseConnection.getConnection();
            // ... database operations ...
            DatabaseConnection.closeConnection(conn);

            logger.info("Database operation completed");

        } catch (SQLException e) {
            logger.error("Database error", e);
        }

        // Use configuration
        String appName = config.getApplicationName();
        logger.info("Application: " + appName);
    }
}
```

## 🎉 Conclusion

The Singleton pattern implementation provides:

- **Better resource management** for database connections
- **Centralized logging** for better debugging
- **Configuration management** for easier maintenance
- **Thread safety** for concurrent access
- **Backward compatibility** with existing code

The implementation follows best practices and provides a solid foundation for the SkyLinkOnline application.
