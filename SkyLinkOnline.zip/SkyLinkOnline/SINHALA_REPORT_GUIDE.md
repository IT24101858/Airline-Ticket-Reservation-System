# Design Patterns Assignment Report සිංහල මාර්ගෝපදේශය

## SkyLinkOnline - Air Ticket Reservation System

---

## 1. Group Details (කණ්ඩායම් විස්තර)

### කරන්නේ කුමක්ද?

ඔබේ කණ්ඩායමේ සියලුම සාමාජිකයන්ගේ නම් සහ Student ID ලැයිස්තුවක් සකස් කරන්න.

### කොහොමද කරන්නේ?

```markdown
| Member Name     | Student ID | Role                    |
| --------------- | ---------- | ----------------------- |
| [Member 1 Name] | [ID]       | Project Lead            |
| [Member 2 Name] | [ID]       | Backend Developer       |
| [Member 3 Name] | [ID]       | Frontend Developer      |
| [Member 4 Name] | [ID]       | Database Developer      |
| [Member 5 Name] | [ID]       | UI/UX Designer          |
| [Member 6 Name] | [ID]       | Testing & Documentation |
```

### උදාහරණය:

```markdown
| Member Name          | Student ID  | Role                    |
| -------------------- | ----------- | ----------------------- |
| Yasindu Dharmasiri   | 2020/CS/001 | Project Lead            |
| Kamal Perera         | 2020/CS/002 | Backend Developer       |
| Nimal Silva          | 2020/CS/003 | Frontend Developer      |
| Sunil Fernando       | 2020/CS/004 | Database Developer      |
| Priya Wickramasinghe | 2020/CS/005 | UI/UX Designer          |
| Sahan Rajapaksa      | 2020/CS/006 | Testing & Documentation |
```

---

## 2. Design Pattern(s) Used (භාවිතා කරන Design Pattern(s))

### කරන්නේ කුමක්ද?

ඔබේ project එකේ implement කර ඇති design patterns ලැයිස්තුවක් සකස් කරන්න.

### ඔබේ Project එකේ ඇති Design Patterns:

#### 1. Singleton Pattern

**Implementation Files:**

- `src/main/java/com/example/util/DatabaseConnectionManager.java`
- `src/main/java/com/example/util/Logger.java`
- `src/main/java/com/example/util/ConfigurationManager.java`

#### 2. Observer Pattern

**Implementation Files:**

- `src/main/java/com/example/util/Observer.java`
- `src/main/java/com/example/util/Subject.java`
- `src/main/java/com/example/util/FlightBookingSubject.java`
- `src/main/java/com/example/util/EmailNotificationObserver.java`
- `src/main/java/com/example/util/SMSNotificationObserver.java`
- `src/main/java/com/example/util/LoggingObserver.java`
- `src/main/java/com/example/util/DynamicObserverManager.java`

#### 3. Facade Pattern

**Implementation Files:**

- `src/main/java/com/example/util/DatabaseConnection.java`

---

## 3. Justification for Each Pattern (සෑම Pattern එකක් සඳහාම හේතු)

### Singleton Pattern සඳහා හේතු:

#### ඇයි තෝරා ගත්තේ?

- **Resource Management**: Database connections expensive වේ create කරන්නට සහ maintain කරන්නට
- **Configuration Centralization**: Application settings consistent විය යුතුය සියලු components වල
- **Logging Consistency**: Application එකේ සියලුම parts එකම logging mechanism එක use කරිය යුතුය
- **Thread Safety**: Web applications වලට concurrent access සඳහා thread-safe implementations අවශ්යයි
- **Memory Efficiency**: Multiple instances unnecessary memory consume කරනවා prevent කරන්නට

#### Design එක improve කරන්නේ කොහොමද?

1. **DatabaseConnectionManager Singleton**

   - Connection pool එකක් පමණක් තිබීම ensure කරයි
   - Connection leaks සහ resource exhaustion prevent කරයි
   - Thread-safe connection management provide කරයි
   - Better performance සඳහා connection pooling implement කරයි

2. **Logger Singleton**

   - සියලුම logging operations centralize කරයි
   - Application එකේ consistent log format ensure කරයි
   - Configurable log levels provide කරයි
   - Thread-safe file operations

3. **ConfigurationManager Singleton**
   - Application configuration centralize කරයි
   - Missing properties සඳහා default values provide කරයි
   - Thread-safe read-write operations
   - Easy configuration management

### Observer Pattern සඳහා හේතු:

#### ඇයි තෝරා ගත්තේ?

- **Event Notification**: Users ට booking status changes ගැන notify කරන්න අවශ්යයි
- **Loose Coupling**: Notification logic business logic අතර separation
- **Extensibility**: නව notification types (email, SMS, push notifications) add කරන්න පහසුයි
- **Dynamic Behavior**: Actual contact information සමඟ user-specific observers create කරන්න පුළුවන්
- **Real-time Updates**: Important events සඳහා immediate notifications provide කරයි

#### Design එක improve කරන්නේ කොහොමද?

1. **FlightBookingSubject**

   - Flight booking events සහ notifications manage කරයි
   - Multiple observer types support කරයි
   - Structured data provide කරයි notifications සඳහා

2. **Dynamic Observer Manager**

   - Actual email සහ phone numbers සමඟ user-specific observers create කරයි
   - Database එකෙන් user data dynamically fetch කරයි
   - User data unavailable නම් default values fallback කරයි

3. **Notification Observers**
   - EmailNotificationObserver: Email notifications send කරයි
   - SMSNotificationObserver: SMS notifications send කරයි
   - LoggingObserver: System monitoring සඳහා සියලුම events log කරයි

### Facade Pattern සඳහා හේතු:

#### ඇයි තෝරා ගත්තේ?

- **Simplified Interface**: DatabaseConnectionManager එකේ complexity hide කරයි
- **Backward Compatibility**: Existing code compatibility maintain කරයි
- **Easier Migration**: Singleton pattern adoption කරන්නට gradual path provide කරයි
- **Abstraction**: Database operations සඳහා simple interface provide කරයි

#### Design එක improve කරන්නේ කොහොමද?

- Database connection usage simplify කරයි
- Existing API maintain කරමින් underlying implementation improve කරයි
- Connection management සඳහා additional utility methods provide කරයි
- Old සහ new implementations අතර bridge එකක් වැනි ක්රියා කරයි

---

## 4. Screenshots of Implementation (Implementation Screenshots)

### කරන්නේ කුමක්ද?

ඔබේ code snippets සහ output screenshots include කරන්න.

### කොහොමද Screenshots ගන්නේ?

#### 1. Code Screenshots ගන්න:

1. **IDE එකේ code open කරන්න** (IntelliJ IDEA, Eclipse, VS Code)
2. **Screenshot tool use කරන්න** (Windows: Snipping Tool, Mac: Cmd+Shift+4)
3. **Relevant code sections capture කරන්න**

#### 2. Output Screenshots ගන්න:

1. **Application run කරන්න**
2. **Browser එකේ demo pages open කරන්න**:
   - `http://localhost:8080/SkyLinkOnline/singleton-demo`
   - `http://localhost:8080/SkyLinkOnline/observer-demo`
3. **Console output capture කරන්න**
4. **Log files open කරන්න** (`logs/skylink_application.log`)

### උදාහරණ Code Snippets:

#### Singleton Pattern Implementation:

```java
public class DatabaseConnectionManager {
    // Singleton instance - volatile for thread safety
    private static volatile DatabaseConnectionManager instance;

    // Thread-safe Singleton getInstance method using double-checked locking
    public static DatabaseConnectionManager getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnectionManager.class) {
                if (instance == null) {
                    instance = new DatabaseConnectionManager();
                }
            }
        }
        return instance;
    }

    // Private constructor to prevent instantiation
    private DatabaseConnectionManager() {
        this.connectionPool = new ConcurrentHashMap<>();
        loadDriver();
    }
}
```

#### Observer Pattern Implementation:

```java
public class FlightBookingSubject extends AbstractSubject {

    /**
     * Notify observers when a flight is booked
     */
    public void notifyFlightBooked(int userId, int flightId, int seats, double totalPrice) {
        BookingData data = new BookingData(userId, flightId, seats, totalPrice, "BOOKED");
        notifyObservers("Flight booking confirmed", data);
    }
}
```

---

## 5. Code Files (Code Files)

### කරන්නේ කුමක්ද?

Clean සහ organized structure සමඟ source code submit කරන්න.

### Requirements:

#### 1. Proper use of Java classes:

- **Main Class**: DatabaseConnectionManager, Logger, ConfigurationManager
- **Context Class**: DatabaseConnection (Facade), DynamicObserverManager
- **Concrete Classes**: All Singleton සහ Observer implementations
- **Interfaces**: Observer, Subject for proper abstraction

#### 2. Clear naming conventions සහ comments:

- Descriptive class names (DatabaseConnectionManager, ConfigurationManager)
- Clear method names (getInstance, getConnection, notifyFlightBooked)
- Consistent naming patterns
- Meaningful variable names

#### 3. Code must be functional:

- All code compiles සහ runs successfully
- Proper error handling
- Thread-safe implementations
- Resource management

### File Structure:

```
src/main/java/com/example/
├── util/
│   ├── DatabaseConnectionManager.java    (Singleton)
│   ├── Logger.java                       (Singleton)
│   ├── ConfigurationManager.java         (Singleton)
│   ├── Observer.java                     (Observer Interface)
│   ├── Subject.java                      (Subject Interface)
│   ├── FlightBookingSubject.java         (Observer Subject)
│   ├── EmailNotificationObserver.java    (Observer Implementation)
│   ├── SMSNotificationObserver.java      (Observer Implementation)
│   ├── LoggingObserver.java              (Observer Implementation)
│   ├── DynamicObserverManager.java       (Observer Manager)
│   └── DatabaseConnection.java           (Facade)
└── servlets/
    ├── SingletonDemoServlet.java         (Demo Servlet)
    ├── ObserverPatternDemoServlet.java   (Demo Servlet)
    ├── BookServlet.java                  (Uses Observer Pattern)
    ├── LoginServlet.java                 (Uses Singleton Pattern)
    └── PaymentServlet.java               (Uses Observer Pattern)
```

---

## 6. Testing Instructions (Testing මාර්ගෝපදේශ)

### කරන්නේ කුමක්ද?

Design patterns properly work කරනවාද test කරන්න.

### Testing Steps:

#### 1. Singleton Pattern Test:

```java
// Test multiple instances
DatabaseConnectionManager connMgr1 = DatabaseConnectionManager.getInstance();
DatabaseConnectionManager connMgr2 = DatabaseConnectionManager.getInstance();
System.out.println("Instances equal: " + (connMgr1 == connMgr2)); // Should print true
```

#### 2. Observer Pattern Test:

1. **Login as a customer** with actual email සහ phone number
2. **Book a flight** - Dynamic observer notifications see කරන්න
3. **Make a payment** - Payment confirmation notifications see කරන්න
4. **Cancel a booking** - Cancellation notifications see කරන්න

#### 3. Demo Servlets Access කරන්න:

- **Singleton Demo**: `http://localhost:8080/SkyLinkOnline/singleton-demo`
- **Observer Demo**: `http://localhost:8080/SkyLinkOnline/observer-demo`

---

## 7. Report Format (Report Format)

### Markdown Format Use කරන්න:

````markdown
# Design Patterns Assignment Report

## SkyLinkOnline - Air Ticket Reservation System

---

## Group Details

| Member Name | Student ID | Role   |
| ----------- | ---------- | ------ |
| [Name]      | [ID]       | [Role] |

---

## Design Pattern(s) Used

### 1. Singleton Pattern

**Implementation Files:**

- `src/main/java/com/example/util/DatabaseConnectionManager.java`
- `src/main/java/com/example/util/Logger.java`
- `src/main/java/com/example/util/ConfigurationManager.java`

---

## Justification for Each Pattern

### Singleton Pattern

**Why Selected:**

- Resource Management
- Configuration Centralization
- Thread Safety

**How It Improves Design:**

- Single instance management
- Connection pooling
- Thread-safe implementation

---

## Screenshots of Implementation

### 1. Singleton Pattern Implementation

#### DatabaseConnectionManager.java

```java
// Code snippet here
```
````

---

## Code Files

### File Structure:

```
src/main/java/com/example/
├── util/
│   ├── DatabaseConnectionManager.java
│   └── Logger.java
└── servlets/
    └── LoginServlet.java
```

### Code Quality Features:

1. Proper Java Classes
2. Clear Naming Conventions
3. Comments and Documentation
4. Functional Code

---

## Conclusion

The SkyLinkOnline project successfully implements design patterns to improve:

1. Resource Management
2. Configuration Management
3. Thread Safety
4. Code Maintainability

```

---

## 8. Submission Checklist (Submission Checklist)

### Report සඳහා:
- [ ] Group Details with Student IDs
- [ ] Design Patterns Used section
- [ ] Justification for Each Pattern
- [ ] Screenshots of Implementation
- [ ] Code Files with proper structure
- [ ] Clear naming conventions
- [ ] Comments for readability
- [ ] Functional code demonstration

### Code Files සඳහා:
- [ ] All Java classes properly implemented
- [ ] Singleton pattern with thread safety
- [ ] Observer pattern with dynamic observers
- [ ] Facade pattern for simplified interface
- [ ] Proper error handling
- [ ] Resource management
- [ ] Database integration
- [ ] Demo servlets for testing

---

## 9. Common Mistakes to Avoid (වැරදි වළක්වන්න)

### Report වල:
- [ ] Student IDs missing
- [ ] Incomplete justification
- [ ] No screenshots
- [ ] Poor formatting
- [ ] Missing code snippets

### Code වල:
- [ ] Not thread-safe Singleton
- [ ] Missing error handling
- [ ] No resource cleanup
- [ ] Poor naming conventions
- [ ] No comments
- [ ] Non-functional code

---

## 10. Final Tips (අවසාන උපදෙස්)

1. **Start Early**: Report writing early start කරන්න
2. **Test Thoroughly**: All patterns properly work කරනවාද test කරන්න
3. **Take Screenshots**: Implementation screenshots ගන්න
4. **Review Code**: Code quality check කරන්න
5. **Format Properly**: Markdown format properly use කරන්න
6. **Submit on Time**: Deadline එකට before submit කරන්න

---

**Good Luck!** 🍀

**ඔබේ Design Patterns Assignment සාර්ථක වේවා!** ✨
```
