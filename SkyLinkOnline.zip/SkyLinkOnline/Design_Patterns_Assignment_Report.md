# Design Patterns Assignment Report

## SkyLinkOnline - Air Ticket Reservation System

---

## Group Details

| Member Name     | Student ID | Role                    |
| --------------- | ---------- | ----------------------- |
| [Member 1 Name] | [ID]       | Project Lead            |
| [Member 2 Name] | [ID]       | Backend Developer       |
| [Member 3 Name] | [ID]       | Frontend Developer      |
| [Member 4 Name] | [ID]       | Database Developer      |
| [Member 5 Name] | [ID]       | UI/UX Designer          |
| [Member 6 Name] | [ID]       | Testing & Documentation |

---

## Design Pattern(s) Used

### 1. Singleton Pattern

**Implementation Files:**

- `src/main/java/com/example/util/DatabaseConnectionManager.java`
- `src/main/java/com/example/util/Logger.java`
- `src/main/java/com/example/util/ConfigurationManager.java`

### 2. Facade Pattern

**Implementation Files:**

- `src/main/java/com/example/util/DatabaseConnection.java`

---

## Justification for Each Pattern

### Singleton Pattern

**Why Selected:**

- **Resource Management**: Database connections are expensive to create and maintain
- **Configuration Centralization**: Application settings need to be consistent across all components
- **Logging Consistency**: All parts of the application should use the same logging mechanism
- **Thread Safety**: Web applications require thread-safe implementations for concurrent access

**How It Improves Design:**

1. **DatabaseConnectionManager Singleton**

   - Ensures only one connection pool exists
   - Prevents connection leaks and resource exhaustion
   - Provides thread-safe connection management
   - Implements connection pooling for better performance

2. **Logger Singleton**

   - Centralizes all logging operations
   - Ensures consistent log format across the application
   - Provides configurable log levels
   - Thread-safe file operations

3. **ConfigurationManager Singleton**
   - Centralizes application configuration
   - Provides default values for missing properties
   - Thread-safe read-write operations
   - Easy configuration management

### Facade Pattern

**Why Selected:**

- **Simplified Interface**: Hides the complexity of DatabaseConnectionManager
- **Backward Compatibility**: Maintains existing code compatibility
- **Easier Migration**: Allows gradual adoption of Singleton pattern
- **Abstraction**: Provides a simple interface for database operations

**How It Improves Design:**

- Simplifies database connection usage
- Maintains existing API while improving underlying implementation
- Provides additional utility methods for connection management
- Acts as a bridge between old and new implementations

---

## Screenshots of Implementation

### 1. Singleton Pattern Implementation

#### DatabaseConnectionManager.java

```java
public class DatabaseConnectionManager {
    // Singleton instance - volatile for thread safety
    private static volatile DatabaseConnectionManager instance;

    // Thread-safe Singleton getInstance method using double-checked locking
    public static DatabaseConnectionManager getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnectionManager.class) {
                if (instance == null) {
                    instance = new DatabaseConnectionManager();
                }
            }
        }
        return instance;
    }

    // Private constructor to prevent instantiation
    private DatabaseConnectionManager() {
        this.connectionPool = new ConcurrentHashMap<>();
        loadDriver();
    }
}
```

#### Logger.java

```java
public class Logger {
    // Singleton instance - volatile for thread safety
    private static volatile Logger instance;

    // Thread-safe Singleton getInstance method using double-checked locking
    public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }

    // Private constructor to prevent instantiation
    private Logger() {
        initializeLogFile();
    }
}
```

#### ConfigurationManager.java

```java
public class ConfigurationManager {
    // Singleton instance - volatile for thread safety
    private static volatile ConfigurationManager instance;

    // Thread-safe Singleton getInstance method using double-checked locking
    public static ConfigurationManager getInstance() {
        if (instance == null) {
            synchronized (ConfigurationManager.class) {
                if (instance == null) {
                    instance = new ConfigurationManager();
                }
            }
        }
        return instance;
    }

    // Private constructor to prevent instantiation
    private ConfigurationManager() {
        this.properties = new Properties();
        loadConfiguration();
    }
}
```

### 2. Facade Pattern Implementation

#### DatabaseConnection.java

```java
public class DatabaseConnection {
    // Singleton instance of DatabaseConnectionManager
    private static final DatabaseConnectionManager connectionManager =
        DatabaseConnectionManager.getInstance();

    // Facade methods that delegate to Singleton
    public static Connection getConnection() throws SQLException {
        return connectionManager.getConnection();
    }

    public static void closeConnection(Connection connection) {
        connectionManager.closeConnection(connection);
    }

    public static boolean testConnection() {
        return connectionManager.testConnection();
    }
}
```

### 3. Usage Examples in Servlets

#### LoginServlet.java

```java
public class LoginServlet extends HttpServlet {
    // Singleton logger instance
    private static final Logger logger = Logger.getInstance();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        logger.info("Login attempt - username=" + username);

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Database operations using Facade
            PreparedStatement stmt = conn.prepareStatement("SELECT id, role FROM Users WHERE username = ? AND password = ?");
            // ... rest of implementation
        } catch (SQLException e) {
            logger.error("Database error during login", e);
        }
    }
}
```

### 4. Demo Servlet Implementation

#### SingletonDemoServlet.java

```java
@WebServlet("/singleton-demo")
public class SingletonDemoServlet extends HttpServlet {
    // Singleton instances
    private static final Logger logger = Logger.getInstance();
    private static final ConfigurationManager configManager = ConfigurationManager.getInstance();
    private static final DatabaseConnectionManager connectionManager = DatabaseConnectionManager.getInstance();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        // Demonstrates all Singleton instances working together
        logger.info("SingletonDemoServlet accessed");

        // Test Singleton pattern verification
        Logger logger2 = Logger.getInstance();
        ConfigurationManager configManager2 = ConfigurationManager.getInstance();
        DatabaseConnectionManager connectionManager2 = DatabaseConnectionManager.getInstance();

        // Verify instances are the same
        boolean allSingletons = (logger == logger2 &&
                               configManager == configManager2 &&
                               connectionManager == connectionManager2);
    }
}
```

---

## Testing the Implementation

### 1. Access Demo Servlet

Navigate to: `http://localhost:8080/SkyLinkOnline/singleton-demo`

This demonstrates:

- All Singleton instances working
- Connection pool status
- Configuration values
- Logging functionality
- Singleton pattern verification

### 2. Verify Singleton Pattern

```java
// Test multiple instances
Logger logger1 = Logger.getInstance();
Logger logger2 = Logger.getInstance();
System.out.println("Logger instances equal: " + (logger1 == logger2)); // Should print true

ConfigurationManager config1 = ConfigurationManager.getInstance();
ConfigurationManager config2 = ConfigurationManager.getInstance();
System.out.println("Config instances equal: " + (config1 == config2)); // Should print true
```

### 3. Check Log Files

- Application logs: `logs/skylink_application.log`
- Configuration file: `config/application.properties`

---

## Benefits Achieved

### 1. Resource Management

- Single instance manages database connections efficiently
- Connection pooling reduces overhead
- Automatic cleanup prevents memory leaks

### 2. Configuration Centralization

- All configuration in one place
- Easy to modify and maintain
- Default values for missing properties

### 3. Logging Consistency

- Unified logging across the application
- Configurable log levels
- File and console output

### 4. Thread Safety

- Safe for concurrent access
- No race conditions
- Proper synchronization

### 5. Memory Efficiency

- No duplicate instances
- Reduced memory footprint
- Better performance

### 6. Simplified Interface

- Facade pattern provides easy-to-use interface
- Maintains backward compatibility
- Gradual migration path

---

## Code Quality Features

### 1. Proper Java Classes

- **Main Classes**: DatabaseConnectionManager, Logger, ConfigurationManager
- **Context Classes**: DatabaseConnection (Facade)
- **Concrete Classes**: All Singleton implementations
- **Interfaces**: Proper abstraction through Facade

### 2. Clear Naming Conventions

- Descriptive class names (DatabaseConnectionManager, ConfigurationManager)
- Clear method names (getInstance, getConnection, closeConnection)
- Consistent naming patterns

### 3. Comments and Documentation

- Comprehensive JavaDoc comments
- Inline comments explaining complex logic
- README documentation for usage

### 4. Functional Code

- All code compiles and runs successfully
- Proper error handling
- Thread-safe implementations
- Resource management

---

## Conclusion

The SkyLinkOnline project successfully implements the Singleton and Facade design patterns to improve:

1. **Resource Management**: Efficient database connection handling
2. **Configuration Management**: Centralized application settings
3. **Logging**: Consistent application-wide logging
4. **Thread Safety**: Safe concurrent access
5. **Code Maintainability**: Clean, organized, and well-documented code
6. **Performance**: Optimized resource usage and connection pooling

The implementation follows best practices with proper error handling, thread safety, and comprehensive documentation. The patterns chosen are appropriate for the web application context and provide significant benefits in terms of resource management, consistency, and maintainability.

---

## Additional Recommendations

### Future Enhancements

1. **Strategy Pattern**: Implement different payment strategies
2. **Factory Pattern**: Create user objects based on roles
3. **Observer Pattern**: Notify users of booking status changes
4. **Template Method Pattern**: Standardize servlet request handling

### Best Practices Applied

1. Thread-safe Singleton implementation
2. Proper resource cleanup
3. Comprehensive error handling
4. Clear separation of concerns
5. Maintainable code structure

---

**Project Repository**: SkyLinkOnline  
**Technology Stack**: Java Servlets, JSP, SQL Server, Maven  
**Design Patterns**: Singleton, Facade  
**Implementation Date**: [Current Date]  
**Team Size**: 6 Members



