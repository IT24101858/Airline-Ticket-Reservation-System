# Code Organization Guide - SkyLinkOnline Design Patterns

## Complete Code File Structure

### Project Structure Overview

```
SkyLinkOnline/
├── src/main/java/com/example/
│   ├── util/                           # Utility Classes (Design Patterns)
│   │   ├── DatabaseConnectionManager.java    # Singleton Pattern
│   │   ├── Logger.java                       # Singleton Pattern
│   │   ├── ConfigurationManager.java         # Singleton Pattern
│   │   ├── Observer.java                     # Observer Interface
│   │   ├── Subject.java                      # Subject Interface
│   │   ├── FlightBookingSubject.java         # Observer Subject
│   │   ├── EmailNotificationObserver.java    # Observer Implementation
│   │   ├── SMSNotificationObserver.java      # Observer Implementation
│   │   ├── LoggingObserver.java              # Observer Implementation
│   │   ├── DynamicObserverManager.java       # Observer Manager
│   │   ├── DatabaseConnection.java           # Facade Pattern
│   │   └── ObserverInitializer.java          # Observer Initializer
│   └── servlets/                        # Servlet Classes
│       ├── SingletonDemoServlet.java         # Singleton Demo
│       ├── ObserverPatternDemoServlet.java   # Observer Demo
│       ├── BookServlet.java                  # Uses Observer Pattern
│       ├── LoginServlet.java                 # Uses Singleton Pattern
│       ├── PaymentServlet.java               # Uses Observer Pattern
│       ├── CancelBookingServlet.java         # Uses Observer Pattern
│       └── [Other Servlets...]
├── src/main/webapp/                    # Web Resources
│   ├── WEB-INF/
│   │   └── web.xml                     # Web Configuration
│   ├── *.jsp                          # JSP Pages
│   └── [Other Web Resources...]
├── target/                            # Compiled Classes
├── logs/                              # Log Files
├── config/                            # Configuration Files
└── [Documentation Files...]
```

---

## 1. Singleton Pattern Implementation

### 1.1 DatabaseConnectionManager.java

**Purpose**: Manages database connections with connection pooling
**Pattern**: Singleton with Thread Safety

```java
package com.example.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe Singleton pattern implementation for database connection management.
 * Ensures only one instance exists throughout the application lifecycle.
 * Provides connection pooling capabilities for better performance.
 */
public class DatabaseConnectionManager {

    // Singleton instance - volatile for thread safety
    private static volatile DatabaseConnectionManager instance;

    // Connection pool for better performance
    private final ConcurrentHashMap<String, Connection> connectionPool;

    // Database connection constants
    private static final String DB_URL = "jdbc:sqlserver://localhost;databaseName=SkyLinkOnline;integratedSecurity=false;";
    private static final String DB_USER = "sa";
    private static final String DB_PASSWORD = "789";
    private static final String DRIVER_CLASS = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

    // Private constructor to prevent instantiation
    private DatabaseConnectionManager() {
        this.connectionPool = new ConcurrentHashMap<>();
        loadDriver();
    }

    /**
     * Thread-safe Singleton getInstance method using double-checked locking
     * @return The single instance of DatabaseConnectionManager
     */
    public static DatabaseConnectionManager getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnectionManager.class) {
                if (instance == null) {
                    instance = new DatabaseConnectionManager();
                }
            }
        }
        return instance;
    }

    /**
     * Get a database connection with connection pooling
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public Connection getConnection() throws SQLException {
        String threadId = Thread.currentThread().getName();

        // Check if connection exists in pool
        Connection connection = connectionPool.get(threadId);

        if (connection == null || connection.isClosed()) {
            try {
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                connectionPool.put(threadId, connection);
                System.out.println("[DatabaseConnectionManager] New connection created for thread: " + threadId);
            } catch (SQLException e) {
                System.err.println("[DatabaseConnectionManager] Failed to establish database connection: " + e.getMessage());
                throw e;
            }
        }

        return connection;
    }

    /**
     * Close a specific connection
     * @param connection The connection to close
     */
    public void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                // Remove from pool
                String threadId = Thread.currentThread().getName();
                connectionPool.remove(threadId);

                connection.close();
                System.out.println("[DatabaseConnectionManager] Connection closed for thread: " + threadId);
            } catch (SQLException e) {
                System.err.println("[DatabaseConnectionManager] Error closing database connection: " + e.getMessage());
            }
        }
    }

    /**
     * Test the database connection
     * @return true if connection is successful, false otherwise
     */
    public boolean testConnection() {
        try (Connection connection = getConnection()) {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            System.err.println("[DatabaseConnectionManager] Database connection test failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Get connection pool status
     * @return String representation of connection pool status
     */
    public String getConnectionPoolStatus() {
        return String.format("Active connections: %d, Pool size: %d",
                           connectionPool.size(), connectionPool.size());
    }

    /**
     * Prevent cloning of the singleton instance
     */
    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Singleton instance cannot be cloned");
    }

    /**
     * Prevent deserialization of the singleton instance
     */
    protected Object readResolve() {
        return getInstance();
    }

    // Additional methods for driver loading, connection management, etc.
}
```

### 1.2 Logger.java

**Purpose**: Centralized logging functionality
**Pattern**: Singleton with Thread Safety

```java
package com.example.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Thread-safe Singleton Logger implementation.
 * Provides centralized logging functionality for the entire application.
 * Supports different log levels and file-based logging.
 */
public class Logger {

    // Singleton instance - volatile for thread safety
    private static volatile Logger instance;

    // Thread-safe lock for file operations
    private final ReentrantLock lock = new ReentrantLock();

    // Log file path
    private static final String LOG_FILE_PATH = "logs/skylink_application.log";

    // Date formatter for timestamps
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // Log levels
    public enum LogLevel {
        DEBUG, INFO, WARN, ERROR, FATAL
    }

    // Current log level (default: INFO)
    private LogLevel currentLogLevel = LogLevel.INFO;

    // Private constructor to prevent instantiation
    private Logger() {
        initializeLogFile();
    }

    /**
     * Thread-safe Singleton getInstance method using double-checked locking
     * @return The single instance of Logger
     */
    public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }

    /**
     * Log info message
     * @param message Message to log
     */
    public void info(String message) {
        log(LogLevel.INFO, message);
    }

    /**
     * Log error message
     * @param message Message to log
     */
    public void error(String message) {
        log(LogLevel.ERROR, message);
    }

    /**
     * Log error message with throwable
     * @param message Message to log
     * @param throwable Throwable to log
     */
    public void error(String message, Throwable throwable) {
        log(LogLevel.ERROR, message, throwable);
    }

    // Additional logging methods...
}
```

### 1.3 ConfigurationManager.java

**Purpose**: Centralized configuration management
**Pattern**: Singleton with Thread Safety

```java
package com.example.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Thread-safe Singleton Configuration Manager.
 * Provides centralized configuration management for the entire application.
 * Supports loading and saving configuration properties from/to files.
 */
public class ConfigurationManager {

    // Singleton instance - volatile for thread safety
    private static volatile ConfigurationManager instance;

    // Thread-safe read-write lock for properties access
    private final ReadWriteLock lock = new ReentrantReadWriteLock();

    // Properties object to store configuration
    private final Properties properties;

    // Configuration file path
    private static final String CONFIG_FILE_PATH = "config/application.properties";

    // Private constructor to prevent instantiation
    private ConfigurationManager() {
        this.properties = new Properties();
        loadConfiguration();
    }

    /**
     * Thread-safe Singleton getInstance method using double-checked locking
     * @return The single instance of ConfigurationManager
     */
    public static ConfigurationManager getInstance() {
        if (instance == null) {
            synchronized (ConfigurationManager.class) {
                if (instance == null) {
                    instance = new ConfigurationManager();
                }
            }
        }
        return instance;
    }

    /**
     * Get a configuration property value
     * @param key Property key
     * @return Property value or null if not found
     */
    public String getProperty(String key) {
        lock.readLock().lock();
        try {
            return properties.getProperty(key);
        } finally {
            lock.readLock().unlock();
        }
    }

    // Additional configuration methods...
}
```

---

## 2. Observer Pattern Implementation

### 2.1 Observer.java (Interface)

**Purpose**: Defines the contract for observers
**Pattern**: Observer Interface

```java
package com.example.util;

/**
 * Observer interface for the Observer Pattern
 * This interface defines the contract for objects that want to be notified
 * when a subject's state changes.
 */
public interface Observer {

    /**
     * Method called by the subject when a state change occurs
     * @param message The notification message
     * @param data Additional data related to the change
     */
    void update(String message, Object data);
}
```

### 2.2 Subject.java (Interface)

**Purpose**: Defines the contract for subjects
**Pattern**: Subject Interface

```java
package com.example.util;

/**
 * Subject interface for the Observer Pattern
 * This interface defines the contract for objects that can be observed
 */
public interface Subject {

    /**
     * Add an observer to the list of observers
     * @param observer The observer to add
     */
    void addObserver(Observer observer);

    /**
     * Remove an observer from the list of observers
     * @param observer The observer to remove
     */
    void removeObserver(Observer observer);

    /**
     * Notify all observers of a state change
     * @param message The notification message
     * @param data Additional data related to the change
     */
    void notifyObservers(String message, Object data);
}
```

### 2.3 FlightBookingSubject.java

**Purpose**: Manages flight booking events and notifications
**Pattern**: Observer Subject

```java
package com.example.util;

/**
 * FlightBookingSubject class that extends AbstractSubject
 * This class manages flight booking events and notifies observers
 * when booking-related events occur.
 */
public class FlightBookingSubject extends AbstractSubject {

    private static FlightBookingSubject instance;

    // Public constructor for dynamic instances
    public FlightBookingSubject() {
        // This constructor allows creating new instances for dynamic observers
    }

    // Private constructor for Singleton pattern
    private FlightBookingSubject(boolean isSingleton) {
        // This constructor is used for singleton instances
    }

    /**
     * Get the singleton instance of FlightBookingSubject
     * @return The singleton instance
     */
    public static synchronized FlightBookingSubject getInstance() {
        if (instance == null) {
            instance = new FlightBookingSubject(true);
        }
        return instance;
    }

    /**
     * Notify observers when a flight is booked
     * @param userId The ID of the user who made the booking
     * @param flightId The ID of the flight that was booked
     * @param seats The number of seats booked
     * @param totalPrice The total price of the booking
     */
    public void notifyFlightBooked(int userId, int flightId, int seats, double totalPrice) {
        BookingData data = new BookingData(userId, flightId, seats, totalPrice, "BOOKED");
        notifyObservers("Flight booking confirmed", data);
    }

    /**
     * Notify observers when a payment is confirmed
     * @param userId The ID of the user who made the payment
     * @param bookingId The ID of the booking
     * @param amount The payment amount
     */
    public void notifyPaymentConfirmed(int userId, int bookingId, double amount) {
        PaymentData data = new PaymentData(userId, bookingId, amount, "CONFIRMED");
        notifyObservers("Payment confirmed", data);
    }

    /**
     * Data class to hold booking information
     */
    public static class BookingData {
        public final int userId;
        public final int flightId;
        public final int seats;
        public final double totalPrice;
        public final String status;

        public BookingData(int userId, int flightId, int seats, double totalPrice, String status) {
            this.userId = userId;
            this.flightId = flightId;
            this.seats = seats;
            this.totalPrice = totalPrice;
            this.status = status;
        }

        @Override
        public String toString() {
            return String.format("BookingData{userId=%d, flightId=%d, seats=%d, totalPrice=%.2f, status='%s'}",
                               userId, flightId, seats, totalPrice, status);
        }
    }

    /**
     * Data class to hold payment information
     */
    public static class PaymentData {
        public final int userId;
        public final int bookingId;
        public final double amount;
        public final String status;

        public PaymentData(int userId, int bookingId, double amount, String status) {
            this.userId = userId;
            this.bookingId = bookingId;
            this.amount = amount;
            this.status = status;
        }

        @Override
        public String toString() {
            return String.format("PaymentData{userId=%d, bookingId=%d, amount=%.2f, status='%s'}",
                               userId, bookingId, amount, status);
        }
    }
}
```

### 2.4 EmailNotificationObserver.java

**Purpose**: Sends email notifications
**Pattern**: Observer Implementation

```java
package com.example.util;

/**
 * EmailNotificationObserver class that implements the Observer interface
 * This class handles email notifications for flight booking events
 */
public class EmailNotificationObserver implements Observer {

    private final String emailAddress;

    public EmailNotificationObserver(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    @Override
    public void update(String message, Object data) {
        System.out.println("=== EMAIL NOTIFICATION ===");
        System.out.println("To: " + emailAddress);

        if (data instanceof FlightBookingSubject.BookingData) {
            FlightBookingSubject.BookingData bookingData = (FlightBookingSubject.BookingData) data;
            System.out.println("Subject: Flight booking confirmed");
            System.out.println("Body: Dear Customer,");
            System.out.println("Your flight booking has been booked.");
            System.out.println("Flight ID: " + bookingData.flightId);
            System.out.println("Seats: " + bookingData.seats);
            System.out.println("Total Price: $" + String.format("%.2f", bookingData.totalPrice));
            System.out.println("Thank you for choosing SkyLink Airlines!");
        } else if (data instanceof FlightBookingSubject.PaymentData) {
            FlightBookingSubject.PaymentData paymentData = (FlightBookingSubject.PaymentData) data;
            System.out.println("Subject: Payment confirmed");
            System.out.println("Body: Dear Customer,");
            System.out.println("Your payment has been confirmed.");
            System.out.println("Booking ID: " + paymentData.bookingId);
            System.out.println("Amount: $" + String.format("%.2f", paymentData.amount));
            System.out.println("Your booking is now confirmed!");
        }

        System.out.println("=========================");
    }
}
```

### 2.5 SMSNotificationObserver.java

**Purpose**: Sends SMS notifications
**Pattern**: Observer Implementation

```java
package com.example.util;

/**
 * SMSNotificationObserver class that implements the Observer interface
 * This class handles SMS notifications for flight booking events
 */
public class SMSNotificationObserver implements Observer {

    private final String phoneNumber;

    public SMSNotificationObserver(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public void update(String message, Object data) {
        System.out.println("=== SMS NOTIFICATION ===");
        System.out.println("To: " + phoneNumber);

        if (data instanceof FlightBookingSubject.BookingData) {
            FlightBookingSubject.BookingData bookingData = (FlightBookingSubject.BookingData) data;
            System.out.println("Message: SkyLink Airlines - Flight booked! Flight ID: " +
                             bookingData.flightId + ", Seats: " + bookingData.seats);
            System.out.println("Amount: $" + String.format("%.2f", bookingData.totalPrice));
        } else if (data instanceof FlightBookingSubject.PaymentData) {
            FlightBookingSubject.PaymentData paymentData = (FlightBookingSubject.PaymentData) data;
            System.out.println("Message: SkyLink Airlines - Payment confirmed! Booking ID: " +
                             paymentData.bookingId + ", Amount: $" + String.format("%.2f", paymentData.amount));
        }

        System.out.println("=======================");
    }
}
```

### 2.6 LoggingObserver.java

**Purpose**: Logs all events for system monitoring
**Pattern**: Observer Implementation

```java
package com.example.util;

/**
 * LoggingObserver class that implements the Observer interface
 * This class handles logging for flight booking events
 */
public class LoggingObserver implements Observer {

    private final String logLevel;
    private final Logger logger;

    public LoggingObserver(String logLevel) {
        this.logLevel = logLevel;
        this.logger = Logger.getInstance();
    }

    @Override
    public void update(String message, Object data) {
        System.out.println("=== SYSTEM LOG ===");

        if (data instanceof FlightBookingSubject.BookingData) {
            FlightBookingSubject.BookingData bookingData = (FlightBookingSubject.BookingData) data;
            logger.info("Flight booking confirmed");
            System.out.println("User ID: " + bookingData.userId);
            System.out.println("Flight ID: " + bookingData.flightId);
            System.out.println("Seats: " + bookingData.seats);
            System.out.println("Status: " + bookingData.status);
            System.out.println("Total Price: $" + String.format("%.2f", bookingData.totalPrice));
        } else if (data instanceof FlightBookingSubject.PaymentData) {
            FlightBookingSubject.PaymentData paymentData = (FlightBookingSubject.PaymentData) data;
            logger.info("Payment confirmed");
            System.out.println("User ID: " + paymentData.userId);
            System.out.println("Booking ID: " + paymentData.bookingId);
            System.out.println("Amount: $" + String.format("%.2f", paymentData.amount));
            System.out.println("Status: " + paymentData.status);
        }

        System.out.println("==================");
    }
}
```

### 2.7 DynamicObserverManager.java

**Purpose**: Creates observers dynamically based on user data
**Pattern**: Observer Manager

```java
package com.example.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.example.util.DatabaseConnection;

/**
 * DynamicObserverManager class that creates observers dynamically based on user data
 * This ensures that notifications are sent to the correct user's email and phone
 */
public class DynamicObserverManager {

    private static DynamicObserverManager instance;

    private DynamicObserverManager() {}

    /**
     * Get the singleton instance of DynamicObserverManager
     * @return The singleton instance
     */
    public static synchronized DynamicObserverManager getInstance() {
        if (instance == null) {
            instance = new DynamicObserverManager();
        }
        return instance;
    }

    /**
     * Create and register observers for a specific user
     * @param userId The user ID to create observers for
     * @return List of created observers
     */
    public List<Observer> createUserObservers(int userId) {
        List<Observer> observers = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Get user details from database
            PreparedStatement stmt = conn.prepareStatement(
                "SELECT email, phone_number, first_name, last_name FROM Users WHERE id = ?"
            );
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String email = rs.getString("email");
                String phoneNumber = rs.getString("phone_number");
                String firstName = rs.getString("first_name");
                String lastName = rs.getString("last_name");

                // Create email observer with user's email
                if (email != null && !email.trim().isEmpty()) {
                    EmailNotificationObserver emailObserver = new EmailNotificationObserver(email);
                    observers.add(emailObserver);
                    System.out.println("📧 Created email observer for: " + email);
                } else {
                    // Fallback to default email
                    EmailNotificationObserver emailObserver = new EmailNotificationObserver("customer@skylink.com");
                    observers.add(emailObserver);
                    System.out.println("📧 Created default email observer (user email not available)");
                }

                // Create SMS observer with user's phone number
                if (phoneNumber != null && !phoneNumber.trim().isEmpty()) {
                    SMSNotificationObserver smsObserver = new SMSNotificationObserver(phoneNumber);
                    observers.add(smsObserver);
                    System.out.println("📱 Created SMS observer for: " + phoneNumber);
                } else {
                    // Fallback to default phone number
                    SMSNotificationObserver smsObserver = new SMSNotificationObserver("+1234567890");
                    observers.add(smsObserver);
                    System.out.println("📱 Created default SMS observer (user phone not available)");
                }

                // Always create logging observer
                LoggingObserver loggingObserver = new LoggingObserver("INFO");
                observers.add(loggingObserver);
                System.out.println("📝 Created logging observer");

                System.out.println("✅ Created " + observers.size() + " observers for user: " +
                                 (firstName != null ? firstName : "Unknown") + " " +
                                 (lastName != null ? lastName : ""));

            } else {
                System.out.println("⚠️ User not found in database, creating default observers");
                // Create default observers if user not found
                observers.add(new EmailNotificationObserver("customer@skylink.com"));
                observers.add(new SMSNotificationObserver("+1234567890"));
                observers.add(new LoggingObserver("INFO"));
            }

        } catch (SQLException e) {
            System.err.println("❌ Error creating user observers: " + e.getMessage());
            // Create default observers as fallback
            observers.add(new EmailNotificationObserver("customer@skylink.com"));
            observers.add(new SMSNotificationObserver("+1234567890"));
            observers.add(new LoggingObserver("INFO"));
        }

        return observers;
    }

    /**
     * Notify observers for a specific user about flight booking
     * @param userId The user ID
     * @param flightId The flight ID
     * @param seats Number of seats
     * @param totalPrice Total price
     */
    public void notifyUserFlightBooked(int userId, int flightId, int seats, double totalPrice) {
        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION ===");
        System.out.println("Creating user-specific observers for User ID: " + userId);

        List<Observer> userObservers = createUserObservers(userId);

        // Create temporary subject for this user
        FlightBookingSubject tempSubject = new FlightBookingSubject();

        // Add user-specific observers
        for (Observer observer : userObservers) {
            tempSubject.addObserver(observer);
        }

        // Send notification
        tempSubject.notifyFlightBooked(userId, flightId, seats, totalPrice);

        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION COMPLETE ===");
    }

    /**
     * Notify observers for a specific user about payment confirmation
     * @param userId The user ID
     * @param bookingId The booking ID
     * @param amount The payment amount
     */
    public void notifyUserPaymentConfirmed(int userId, int bookingId, double amount) {
        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION ===");
        System.out.println("Creating user-specific observers for User ID: " + userId);

        List<Observer> userObservers = createUserObservers(userId);

        // Create temporary subject for this user
        FlightBookingSubject tempSubject = new FlightBookingSubject();

        // Add user-specific observers
        for (Observer observer : userObservers) {
            tempSubject.addObserver(observer);
        }

        // Send notification
        tempSubject.notifyPaymentConfirmed(userId, bookingId, amount);

        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION COMPLETE ===");
    }
}
```

---

## 3. Facade Pattern Implementation

### 3.1 DatabaseConnection.java

**Purpose**: Provides a simplified interface to the DatabaseConnectionManager
**Pattern**: Facade

```java
package com.example.util;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Facade class that provides a simplified interface to the DatabaseConnectionManager Singleton.
 * This class acts as a bridge between the old API and the new Singleton implementation.
 */
public class DatabaseConnection {

    // Singleton instance of DatabaseConnectionManager
    private static final DatabaseConnectionManager connectionManager =
        DatabaseConnectionManager.getInstance();

    /**
     * Get a database connection using the Singleton pattern
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection() throws SQLException {
        return connectionManager.getConnection();
    }

    /**
     * Close a database connection
     * @param connection The connection to close
     */
    public static void closeConnection(Connection connection) {
        connectionManager.closeConnection(connection);
    }

    /**
     * Test the database connection
     * @return true if connection is successful, false otherwise
     */
    public static boolean testConnection() {
        return connectionManager.testConnection();
    }

    /**
     * Get connection pool status
     * @return String representation of connection pool status
     */
    public static String getConnectionPoolStatus() {
        return connectionManager.getConnectionPoolStatus();
    }
}
```

---

## 4. Demo Servlets

### 4.1 SingletonDemoServlet.java

**Purpose**: Demonstrates Singleton pattern usage
**Pattern**: Demo Servlet

```java
package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;
import com.example.util.DatabaseConnectionManager;
import com.example.util.Logger;
import com.example.util.ConfigurationManager;

/**
 * Demo servlet to showcase Singleton pattern implementations.
 * This servlet demonstrates how all Singleton instances work together.
 */
@WebServlet("/singleton-demo")
public class SingletonDemoServlet extends HttpServlet {

    // Singleton instances
    private static final Logger logger = Logger.getInstance();
    private static final ConfigurationManager configManager = ConfigurationManager.getInstance();
    private static final DatabaseConnectionManager connectionManager = DatabaseConnectionManager.getInstance();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Singleton Pattern Demo</title></head><body>");
        out.println("<h1>Singleton Pattern Demonstration</h1>");

        // Test Singleton pattern verification
        Logger logger2 = Logger.getInstance();
        ConfigurationManager configManager2 = ConfigurationManager.getInstance();
        DatabaseConnectionManager connectionManager2 = DatabaseConnectionManager.getInstance();

        out.println("<h2>Singleton Instance Verification:</h2>");
        out.println("<p>Logger instances equal: " + (logger == logger2) + "</p>");
        out.println("<p>ConfigurationManager instances equal: " + (configManager == configManager2) + "</p>");
        out.println("<p>DatabaseConnectionManager instances equal: " + (connectionManager == connectionManager2) + "</p>");

        if (logger == logger2 && configManager == configManager2 && connectionManager == connectionManager2) {
            out.println("<p style='color: green;'><strong>✅ All Singleton patterns working correctly!</strong></p>");
        } else {
            out.println("<p style='color: red;'><strong>❌ Singleton patterns not working!</strong></p>");
        }

        // Test database connection
        out.println("<h2>Database Connection Test:</h2>");
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null && !conn.isClosed()) {
                out.println("<p style='color: green;'>✅ Database connection successful</p>");
                out.println("<p>Connection Pool Status: " + connectionManager.getConnectionPoolStatus() + "</p>");
            } else {
                out.println("<p style='color: red;'>❌ Database connection failed</p>");
            }
        } catch (SQLException e) {
            out.println("<p style='color: red;'>❌ Database connection error: " + e.getMessage() + "</p>");
        }

        // Test logging
        out.println("<h2>Logging Test:</h2>");
        logger.info("SingletonDemoServlet accessed from IP: " + request.getRemoteAddr());
        out.println("<p>✅ Log message written successfully</p>");
        out.println("<p>Log file: " + logger.getLogFilePath() + "</p>");

        // Test configuration
        out.println("<h2>Configuration Test:</h2>");
        out.println("<p>Application Name: " + configManager.getApplicationName() + "</p>");
        out.println("<p>Application Version: " + configManager.getApplicationVersion() + "</p>");
        out.println("<p>Database URL: " + configManager.getDatabaseUrl() + "</p>");
        out.println("<p>Logging Level: " + configManager.getLoggingLevel() + "</p>");

        out.println("</body></html>");
    }
}
```

### 4.2 ObserverPatternDemoServlet.java

**Purpose**: Demonstrates Observer pattern usage
**Pattern**: Demo Servlet

```java
package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import com.example.util.FlightBookingSubject;
import com.example.util.EmailNotificationObserver;
import com.example.util.SMSNotificationObserver;
import com.example.util.LoggingObserver;

/**
 * Demo servlet to showcase Observer pattern implementation.
 * This servlet demonstrates how the Observer pattern works with flight bookings.
 */
@WebServlet("/observer-demo")
public class ObserverPatternDemoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Observer Pattern Demo</title></head><body>");
        out.println("<h1>Observer Pattern Demonstration</h1>");

        // Get the singleton instance
        FlightBookingSubject subject = FlightBookingSubject.getInstance();

        // Register observers
        out.println("<h2>Registering Observers:</h2>");
        EmailNotificationObserver emailObserver = new EmailNotificationObserver("demo@skylink.com");
        SMSNotificationObserver smsObserver = new SMSNotificationObserver("+1234567890");
        LoggingObserver loggingObserver = new LoggingObserver("INFO");

        subject.addObserver(emailObserver);
        subject.addObserver(smsObserver);
        subject.addObserver(loggingObserver);

        out.println("<p>✅ Registered " + subject.getObserverCount() + " observers:</p>");
        out.println("<ul>");
        out.println("<li>Email Notification Observer (demo@skylink.com)</li>");
        out.println("<li>SMS Notification Observer (+1234567890)</li>");
        out.println("<li>Logging Observer (INFO level)</li>");
        out.println("</ul>");

        // Test flight booking notification
        out.println("<h2>Testing Flight Booking Notification:</h2>");
        out.println("<p>Simulating flight booking for User ID: 1, Flight ID: 123, Seats: 2, Price: $500.00</p>");

        // This will trigger notifications to all observers
        subject.notifyFlightBooked(1, 123, 2, 500.00);

        out.println("<p>✅ Flight booking notification sent to all observers</p>");
        out.println("<p>Check the console output for notification details</p>");

        // Test payment confirmation notification
        out.println("<h2>Testing Payment Confirmation Notification:</h2>");
        out.println("<p>Simulating payment confirmation for User ID: 1, Booking ID: 456, Amount: $500.00</p>");

        subject.notifyPaymentConfirmed(1, 456, 500.00);

        out.println("<p>✅ Payment confirmation notification sent to all observers</p>");
        out.println("<p>Check the console output for notification details</p>");

        out.println("</body></html>");
    }
}
```

---

## 5. Usage in Business Logic Servlets

### 5.1 BookServlet.java

**Purpose**: Handles flight booking with Observer pattern
**Pattern**: Business Logic with Observer

```java
package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;
import com.example.util.DynamicObserverManager;

@WebServlet("/book")
public class BookServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");
        String role = (String) session.getAttribute("role");

        if (userId == null || !"customer".equals(role)) {
            response.sendRedirect("login.jsp");
            return;
        }

        int flightId = Integer.parseInt(request.getParameter("flight_id"));
        int seats = Integer.parseInt(request.getParameter("seats"));

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Check available seats and get price
            PreparedStatement checkStmt = conn.prepareStatement(
                "SELECT available_seats, price FROM Flights WHERE id = ?"
            );
            checkStmt.setInt(1, flightId);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                int availableSeats = rs.getInt("available_seats");
                double price = rs.getDouble("price");

                if (availableSeats >= seats) {
                    // Insert booking
                    PreparedStatement insertStmt = conn.prepareStatement(
                        "INSERT INTO Bookings (user_id, flight_id, seats, total_price, status) VALUES (?, ?, ?, ?, 'BOOKED')",
                        PreparedStatement.RETURN_GENERATED_KEYS
                    );
                    insertStmt.setInt(1, userId);
                    insertStmt.setInt(2, flightId);
                    insertStmt.setInt(3, seats);
                    insertStmt.setDouble(4, price * seats);
                    insertStmt.executeUpdate();

                    ResultSet generatedKeys = insertStmt.getGeneratedKeys();
                    int bookingId = 0;
                    if (generatedKeys.next()) {
                        bookingId = generatedKeys.getInt(1);
                    }

                    // Update available seats
                    PreparedStatement updateStmt = conn.prepareStatement(
                        "UPDATE Flights SET available_seats = available_seats - ? WHERE id = ?"
                    );
                    updateStmt.setInt(1, seats);
                    updateStmt.setInt(2, flightId);
                    updateStmt.executeUpdate();

                    // Use Observer Pattern to notify user
                    DynamicObserverManager observerManager = DynamicObserverManager.getInstance();
                    observerManager.notifyUserFlightBooked(userId, flightId, seats, price * seats);

                    response.sendRedirect("process_payment.jsp?booking_id=" + bookingId + "&amount=" + (price * seats));
                } else {
                    response.sendRedirect("book.jsp?error=insufficient_seats");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("book.jsp?error=database_error");
        }
    }
}
```

### 5.2 LoginServlet.java

**Purpose**: Handles user login with Singleton pattern
**Pattern**: Business Logic with Singleton

```java
package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;
import com.example.util.Logger;

public class LoginServlet extends HttpServlet {

    // Singleton logger instance
    private static final Logger logger = Logger.getInstance();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        logger.info("Login attempt - username=" + username + ", remoteAddr=" + request.getRemoteAddr());

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT id, role FROM Users WHERE username = ? AND password = ?")) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Login successful
                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                session.setAttribute("user_id", rs.getInt("id"));
                session.setAttribute("role", rs.getString("role"));

                logger.info("Authentication SUCCESS for username=" + username);
                response.sendRedirect("dashboard.jsp");
            } else {
                logger.warn("Authentication FAILED for username=" + username);
                response.sendRedirect("login.jsp?error=true");
            }
        } catch (SQLException e) {
            logger.error("Database error during login", e);
            response.sendRedirect("login.jsp?error=true");
        }
    }
}
```

---

## 6. Testing and Verification

### 6.1 Testing Singleton Pattern

```java
// Test multiple instances
DatabaseConnectionManager connMgr1 = DatabaseConnectionManager.getInstance();
DatabaseConnectionManager connMgr2 = DatabaseConnectionManager.getInstance();
System.out.println("Instances equal: " + (connMgr1 == connMgr2)); // Should print true

Logger logger1 = Logger.getInstance();
Logger logger2 = Logger.getInstance();
System.out.println("Logger instances equal: " + (logger1 == logger2)); // Should print true

ConfigurationManager config1 = ConfigurationManager.getInstance();
ConfigurationManager config2 = ConfigurationManager.getInstance();
System.out.println("Config instances equal: " + (config1 == config2)); // Should print true
```

### 6.2 Testing Observer Pattern

```java
// Test observer pattern
FlightBookingSubject subject = FlightBookingSubject.getInstance();

// Register observers
EmailNotificationObserver emailObserver = new EmailNotificationObserver("test@example.com");
SMSNotificationObserver smsObserver = new SMSNotificationObserver("+1234567890");
LoggingObserver loggingObserver = new LoggingObserver("INFO");

subject.addObserver(emailObserver);
subject.addObserver(smsObserver);
subject.addObserver(loggingObserver);

// Test notifications
subject.notifyFlightBooked(1, 123, 2, 500.00);
subject.notifyPaymentConfirmed(1, 456, 500.00);
```

### 6.3 Testing Facade Pattern

```java
// Test facade pattern
Connection conn = DatabaseConnection.getConnection();
boolean isConnected = DatabaseConnection.testConnection();
String poolStatus = DatabaseConnection.getConnectionPoolStatus();
DatabaseConnection.closeConnection(conn);
```

---

## 7. File Organization Best Practices

### 7.1 Package Structure

- **util package**: Contains all utility classes and design pattern implementations
- **servlets package**: Contains all servlet classes
- **Clear separation**: Business logic separated from utility classes

### 7.2 Naming Conventions

- **Classes**: PascalCase (DatabaseConnectionManager, FlightBookingSubject)
- **Methods**: camelCase (getInstance, notifyFlightBooked)
- **Variables**: camelCase (connectionManager, userObservers)
- **Constants**: UPPER_SNAKE_CASE (DB_URL, LOG_FILE_PATH)

### 7.3 Documentation

- **JavaDoc comments**: For all public methods and classes
- **Inline comments**: For complex logic
- **README files**: For usage instructions
- **Code organization**: Clear and logical structure

### 7.4 Error Handling

- **Try-catch blocks**: For all database operations
- **Logging**: For all errors and important events
- **Graceful degradation**: Fallback mechanisms for failures
- **User-friendly messages**: For user-facing errors

---

## 8. Deployment and Testing

### 8.1 Build Process

```bash
# Clean and compile
mvn clean compile

# Package the application
mvn package

# Deploy to Tomcat
cp target/finance-manager.war $TOMCAT_HOME/webapps/
```

### 8.2 Testing URLs

- **Singleton Demo**: `http://localhost:8080/SkyLinkOnline/singleton-demo`
- **Observer Demo**: `http://localhost:8080/SkyLinkOnline/observer-demo`
- **Application**: `http://localhost:8080/SkyLinkOnline/`

### 8.3 Log Files

- **Application Logs**: `logs/skylink_application.log`
- **Configuration**: `config/application.properties`
- **Console Output**: Check server console for real-time logs

---

## 9. Code Quality Checklist

### 9.1 Design Patterns

- [ ] Singleton pattern properly implemented with thread safety
- [ ] Observer pattern with dynamic observer creation
- [ ] Facade pattern for simplified interface
- [ ] Proper separation of concerns
- [ ] Loose coupling between components

### 9.2 Code Quality

- [ ] Clear naming conventions
- [ ] Comprehensive JavaDoc comments
- [ ] Proper error handling
- [ ] Thread-safe implementations
- [ ] Resource management
- [ ] Database connection pooling
- [ ] Logging and monitoring

### 9.3 Functionality

- [ ] All code compiles successfully
- [ ] Application runs without errors
- [ ] Database connections work properly
- [ ] Observer notifications function correctly
- [ ] Singleton instances are truly single
- [ ] Facade provides simplified interface

---

## 10. Conclusion

This code organization guide provides a comprehensive structure for implementing design patterns in the SkyLinkOnline project. The code is organized into clear packages, follows best practices, and demonstrates proper implementation of Singleton, Observer, and Facade patterns.

The implementation includes:

- **Thread-safe Singleton patterns** for resource management
- **Dynamic Observer pattern** for user-specific notifications
- **Facade pattern** for simplified database access
- **Comprehensive error handling** and logging
- **Clean code structure** with proper documentation
- **Testing and verification** mechanisms

This structure ensures maintainability, scalability, and proper separation of concerns while demonstrating the effective use of design patterns in a real-world web application.
