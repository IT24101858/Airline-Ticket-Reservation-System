# Design Patterns Assignment Report

## SkyLinkOnline - Air Ticket Reservation System

---

## Group Details

| Member Name     | Student ID | Role                    |
| --------------- | ---------- | ----------------------- |
| [Member 1 Name] | [ID]       | Project Lead            |
| [Member 2 Name] | [ID]       | Backend Developer       |
| [Member 3 Name] | [ID]       | Frontend Developer      |
| [Member 4 Name] | [ID]       | Database Developer      |
| [Member 5 Name] | [ID]       | UI/UX Designer          |
| [Member 6 Name] | [ID]       | Testing & Documentation |

---

## Design Pattern Used

### Singleton Pattern

**Implementation File:**

- `src/main/java/com/example/util/DatabaseConnectionManager.java`

---

## Justification for Singleton Pattern

### Why Selected:

- **Resource Management**: Database connections are expensive to create and maintain
- **Connection Pooling**: Ensures only one connection pool exists throughout the application
- **Thread Safety**: Web applications require thread-safe implementations for concurrent access
- **Memory Efficiency**: Prevents multiple instances consuming unnecessary memory
- **Global Access**: Provides easy access to database connections from anywhere in the application

### How It Improves Design:

1. **Single Instance Management**: Ensures only one DatabaseConnectionManager exists
2. **Connection Pooling**: Efficiently manages database connections with pooling
3. **Thread Safety**: Safe for concurrent access from multiple servlets
4. **Resource Optimization**: Prevents connection leaks and resource exhaustion
5. **Performance**: Reduces overhead by reusing connections

---

## Screenshots of Implementation

### 1. Singleton Pattern Implementation

#### DatabaseConnectionManager.java - Complete Implementation

```java
package com.example.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe Singleton pattern implementation for database connection management.
 * Ensures only one instance exists throughout the application lifecycle.
 * Provides connection pooling capabilities for better performance.
 */
public class DatabaseConnectionManager {

    // Singleton instance - volatile for thread safety
    private static volatile DatabaseConnectionManager instance;

    // Connection pool for better performance
    private final ConcurrentHashMap<String, Connection> connectionPool;

    // Database connection constants
    private static final String DB_URL = "jdbc:sqlserver://localhost;databaseName=SkyLinkOnline;integratedSecurity=false;";
    private static final String DB_USER = "sa";
    private static final String DB_PASSWORD = "789";
    private static final String DRIVER_CLASS = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

    // Private constructor to prevent instantiation
    private DatabaseConnectionManager() {
        this.connectionPool = new ConcurrentHashMap<>();
        loadDriver();
    }

    /**
     * Thread-safe Singleton getInstance method using double-checked locking
     * @return The single instance of DatabaseConnectionManager
     */
    public static DatabaseConnectionManager getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnectionManager.class) {
                if (instance == null) {
                    instance = new DatabaseConnectionManager();
                }
            }
        }
        return instance;
    }

    /**
     * Load the JDBC driver
     */
    private void loadDriver() {
        try {
            Class.forName(DRIVER_CLASS);
            System.out.println("[DatabaseConnectionManager] SQL Server JDBC Driver loaded successfully");
        } catch (ClassNotFoundException e) {
            System.err.println("[DatabaseConnectionManager] Failed to load SQL Server JDBC Driver: " + e.getMessage());
            throw new RuntimeException("Database driver not found", e);
        }
    }

    /**
     * Get a database connection with connection pooling
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public Connection getConnection() throws SQLException {
        String threadId = Thread.currentThread().getName();

        // Check if connection exists in pool
        Connection connection = connectionPool.get(threadId);

        if (connection == null || connection.isClosed()) {
            try {
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                connectionPool.put(threadId, connection);
                System.out.println("[DatabaseConnectionManager] New connection created for thread: " + threadId);
            } catch (SQLException e) {
                System.err.println("[DatabaseConnectionManager] Failed to establish database connection: " + e.getMessage());
                throw e;
            }
        }

        return connection;
    }

    /**
     * Close a specific connection
     * @param connection The connection to close
     */
    public void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                // Remove from pool
                String threadId = Thread.currentThread().getName();
                connectionPool.remove(threadId);

                connection.close();
                System.out.println("[DatabaseConnectionManager] Connection closed for thread: " + threadId);
            } catch (SQLException e) {
                System.err.println("[DatabaseConnectionManager] Error closing database connection: " + e.getMessage());
            }
        }
    }

    /**
     * Close all connections in the pool
     */
    public void closeAllConnections() {
        System.out.println("[DatabaseConnectionManager] Closing all connections in pool...");
        for (Connection connection : connectionPool.values()) {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println("[DatabaseConnectionManager] Error closing connection: " + e.getMessage());
            }
        }
        connectionPool.clear();
        System.out.println("[DatabaseConnectionManager] All connections closed");
    }

    /**
     * Test the database connection
     * @return true if connection is successful, false otherwise
     */
    public boolean testConnection() {
        try (Connection connection = getConnection()) {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            System.err.println("[DatabaseConnectionManager] Database connection test failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Get the number of active connections in the pool
     * @return Number of active connections
     */
    public int getActiveConnectionCount() {
        return connectionPool.size();
    }

    /**
     * Get connection pool status
     * @return String representation of connection pool status
     */
    public String getConnectionPoolStatus() {
        return String.format("Active connections: %d, Pool size: %d",
                           connectionPool.size(), connectionPool.size());
    }

    /**
     * Prevent cloning of the singleton instance
     */
    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Singleton instance cannot be cloned");
    }

    /**
     * Prevent deserialization of the singleton instance
     */
    protected Object readResolve() {
        return getInstance();
    }
}
```

### 2. Usage Examples in Servlets

#### LoginServlet.java - Using Singleton

```java
package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnectionManager;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            // Get Singleton instance
            DatabaseConnectionManager connMgr = DatabaseConnectionManager.getInstance();

            // Get database connection
            try (Connection conn = connMgr.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("SELECT id, role FROM Users WHERE username = ? AND password = ?")) {

                stmt.setString(1, username);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    // Login successful
                    HttpSession session = request.getSession();
                    session.setAttribute("username", username);
                    session.setAttribute("user_id", rs.getInt("id"));
                    session.setAttribute("role", rs.getString("role"));

                    response.sendRedirect("dashboard.jsp");
                } else {
                    response.sendRedirect("login.jsp?error=true");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("login.jsp?error=true");
        }
    }
}
```

### 3. Singleton Pattern Verification

#### TestServlet.java - Demonstrating Singleton

```java
package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import com.example.util.DatabaseConnectionManager;

@WebServlet("/singleton-test")
public class TestServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Singleton Pattern Test</title></head><body>");
        out.println("<h1>Singleton Pattern Verification</h1>");

        // Test multiple instances
        DatabaseConnectionManager instance1 = DatabaseConnectionManager.getInstance();
        DatabaseConnectionManager instance2 = DatabaseConnectionManager.getInstance();
        DatabaseConnectionManager instance3 = DatabaseConnectionManager.getInstance();

        out.println("<h2>Instance Comparison:</h2>");
        out.println("<p>Instance 1: " + instance1.toString() + "</p>");
        out.println("<p>Instance 2: " + instance2.toString() + "</p>");
        out.println("<p>Instance 3: " + instance3.toString() + "</p>");

        out.println("<h2>Singleton Verification:</h2>");
        out.println("<p>instance1 == instance2: " + (instance1 == instance2) + "</p>");
        out.println("<p>instance2 == instance3: " + (instance2 == instance3) + "</p>");
        out.println("<p>instance1 == instance3: " + (instance1 == instance3) + "</p>");

        if (instance1 == instance2 && instance2 == instance3) {
            out.println("<p style='color: green;'><strong>✓ Singleton Pattern Working Correctly!</strong></p>");
        } else {
            out.println("<p style='color: red;'><strong>✗ Singleton Pattern Not Working!</strong></p>");
        }

        out.println("<h2>Connection Pool Status:</h2>");
        out.println("<p>Active Connections: " + instance1.getActiveConnectionCount() + "</p>");
        out.println("<p>Pool Status: " + instance1.getConnectionPoolStatus() + "</p>");

        out.println("</body></html>");
    }
}
```

---

## Testing the Implementation

### 1. Access Test Servlet

Navigate to: `http://localhost:8080/SkyLinkOnline/singleton-test`

This demonstrates:

- Singleton pattern verification
- Instance comparison
- Connection pool status
- Thread-safe implementation

### 2. Verify Singleton Pattern

```java
// Test multiple instances
DatabaseConnectionManager connMgr1 = DatabaseConnectionManager.getInstance();
DatabaseConnectionManager connMgr2 = DatabaseConnectionManager.getInstance();
System.out.println("Instances equal: " + (connMgr1 == connMgr2)); // Should print true
```

### 3. Check Connection Pool

```java
DatabaseConnectionManager connMgr = DatabaseConnectionManager.getInstance();
System.out.println("Active connections: " + connMgr.getActiveConnectionCount());
System.out.println("Pool status: " + connMgr.getConnectionPoolStatus());
```

---

## Benefits Achieved

### 1. Resource Management

- Single instance manages all database connections
- Connection pooling reduces overhead
- Automatic cleanup prevents memory leaks
- Efficient connection reuse

### 2. Thread Safety

- Double-checked locking pattern
- Volatile keyword for instance variable
- Synchronized blocks for critical sections
- Safe for concurrent access

### 3. Memory Efficiency

- No duplicate instances
- Reduced memory footprint
- Better performance
- Single point of access

### 4. Connection Pooling

- Thread-specific connections
- Automatic connection management
- Connection status monitoring
- Pool size tracking

### 5. Error Handling

- Proper exception handling
- Connection validation
- Driver loading verification
- Graceful failure handling

---

## Code Quality Features

### 1. Proper Java Classes

- **Main Class**: DatabaseConnectionManager
- **Concrete Class**: Singleton implementation
- **Utility Methods**: Connection management
- **Thread Safety**: Concurrent access support

### 2. Clear Naming Conventions

- Descriptive class name (DatabaseConnectionManager)
- Clear method names (getInstance, getConnection, closeConnection)
- Consistent naming patterns
- Meaningful variable names

### 3. Comments and Documentation

- Comprehensive JavaDoc comments
- Inline comments explaining complex logic
- Method documentation
- Class-level documentation

### 4. Functional Code

- All code compiles and runs successfully
- Proper error handling
- Thread-safe implementations
- Resource management

---

## Conclusion

The SkyLinkOnline project successfully implements the Singleton pattern in the DatabaseConnectionManager class to improve:

1. **Resource Management**: Efficient database connection handling
2. **Thread Safety**: Safe concurrent access from multiple servlets
3. **Memory Efficiency**: Single instance prevents resource waste
4. **Connection Pooling**: Optimized database connection management
5. **Code Maintainability**: Clean, organized, and well-documented code

The implementation follows best practices with proper error handling, thread safety, and comprehensive documentation. The Singleton pattern is appropriate for database connection management in web applications and provides significant benefits in terms of resource management, consistency, and performance.

---

## Additional Recommendations

### Future Enhancements

1. **Connection Timeout**: Implement connection timeout handling
2. **Connection Validation**: Add connection health checks
3. **Metrics**: Implement connection usage metrics
4. **Configuration**: Make database settings configurable

### Best Practices Applied

1. Thread-safe Singleton implementation
2. Proper resource cleanup
3. Comprehensive error handling
4. Clear separation of concerns
5. Maintainable code structure

---

**Project Repository**: SkyLinkOnline  
**Technology Stack**: Java Servlets, JSP, SQL Server, Maven  
**Design Pattern**: Singleton  
**Implementation Date**: [Current Date]  
**Team Size**: 6 Members



