# Screenshots Guide - Design Patterns Implementation

## How to Take Screenshots for Your Design Patterns Report

### Overview

This guide will help you capture all the necessary screenshots to demonstrate your design patterns implementation in the SkyLinkOnline project.

---

## 1. Code Screenshots

### 1.1 Singleton Pattern Code Screenshots

#### DatabaseConnectionManager.java

**What to capture:**

- Class declaration with Singleton instance variable
- Private constructor
- getInstance() method with double-checked locking
- Connection management methods

**Steps:**

1. Open `src/main/java/com/example/util/DatabaseConnectionManager.java` in your IDE
2. Take screenshot of the class structure:

   ```java
   public class DatabaseConnectionManager {
       // Singleton instance - volatile for thread safety
       private static volatile DatabaseConnectionManager instance;

       // Private constructor to prevent instantiation
       private DatabaseConnectionManager() {
           this.connectionPool = new ConcurrentHashMap<>();
           loadDriver();
       }

       // Thread-safe Singleton getInstance method using double-checked locking
       public static DatabaseConnectionManager getInstance() {
           if (instance == null) {
               synchronized (DatabaseConnectionManager.class) {
                   if (instance == null) {
                       instance = new DatabaseConnectionManager();
                   }
               }
           }
           return instance;
       }
   ```

#### Logger.java

**What to capture:**

- Singleton implementation
- Logging methods
- Thread-safe file operations

**Steps:**

1. Open `src/main/java/com/example/util/Logger.java`
2. Take screenshot showing:
   - Singleton instance declaration
   - getInstance() method
   - Logging methods (info, error, etc.)

#### ConfigurationManager.java

**What to capture:**

- Singleton implementation
- Configuration loading methods
- Thread-safe property access

**Steps:**

1. Open `src/main/java/com/example/util/ConfigurationManager.java`
2. Take screenshot showing:
   - Singleton pattern implementation
   - Configuration loading methods
   - Property access methods

### 1.2 Observer Pattern Code Screenshots

#### Observer Interface

**What to capture:**

- Interface declaration
- update() method signature

**Steps:**

1. Open `src/main/java/com/example/util/Observer.java`
2. Take screenshot of the complete interface

#### FlightBookingSubject.java

**What to capture:**

- Class extending AbstractSubject
- Notification methods
- Data classes

**Steps:**

1. Open `src/main/java/com/example/util/FlightBookingSubject.java`
2. Take screenshot showing:
   - Class declaration
   - notifyFlightBooked() method
   - notifyPaymentConfirmed() method
   - BookingData and PaymentData classes

#### DynamicObserverManager.java

**What to capture:**

- createUserObservers() method
- Database query for user data
- Observer creation logic

**Steps:**

1. Open `src/main/java/com/example/util/DynamicObserverManager.java`
2. Take screenshot showing:
   - createUserObservers() method
   - Database query section
   - Observer creation with user-specific data

#### Observer Implementations

**What to capture:**

- EmailNotificationObserver.java
- SMSNotificationObserver.java
- LoggingObserver.java

**Steps:**

1. Open each observer implementation file
2. Take screenshot showing:
   - Class declaration implementing Observer
   - update() method implementation
   - Notification logic

### 1.3 Facade Pattern Code Screenshots

#### DatabaseConnection.java

**What to capture:**

- Facade class declaration
- Static methods delegating to Singleton
- Simplified interface

**Steps:**

1. Open `src/main/java/com/example/util/DatabaseConnection.java`
2. Take screenshot showing:
   - Class declaration
   - Static methods (getConnection, closeConnection, etc.)
   - Delegation to DatabaseConnectionManager

### 1.4 Servlet Usage Screenshots

#### BookServlet.java

**What to capture:**

- Observer pattern usage
- DynamicObserverManager integration
- Notification triggering

**Steps:**

1. Open `src/main/java/com/example/servlets/BookServlet.java`
2. Take screenshot showing:
   - DynamicObserverManager usage
   - notifyUserFlightBooked() call
   - Integration with booking logic

#### LoginServlet.java

**What to capture:**

- Singleton pattern usage
- Logger integration
- DatabaseConnection usage

**Steps:**

1. Open `src/main/java/com/example/servlets/LoginServlet.java`
2. Take screenshot showing:
   - Logger singleton usage
   - DatabaseConnection facade usage
   - Logging calls

---

## 2. Output Screenshots

### 2.1 Application Running Screenshots

#### Home Page

**What to capture:**

- SkyLinkOnline home page
- Navigation menu
- Application branding

**Steps:**

1. Start your application server (Tomcat)
2. Open browser and navigate to `http://localhost:8080/SkyLinkOnline/`
3. Take screenshot of the home page

#### Login Page

**What to capture:**

- Login form
- Username and password fields
- Login button

**Steps:**

1. Navigate to login page
2. Take screenshot of the login form

### 2.2 Demo Servlet Screenshots

#### Singleton Demo Page

**What to capture:**

- Singleton pattern verification results
- Instance comparison results
- Database connection test results
- Configuration values

**Steps:**

1. Navigate to `http://localhost:8080/SkyLinkOnline/singleton-demo`
2. Take screenshot showing:
   - "✅ All Singleton patterns working correctly!" message
   - Instance comparison results (all should be true)
   - Database connection status
   - Configuration values

#### Observer Demo Page

**What to capture:**

- Observer registration results
- Notification test results
- Observer count

**Steps:**

1. Navigate to `http://localhost:8080/SkyLinkOnline/observer-demo`
2. Take screenshot showing:
   - Observer registration success
   - Notification test results
   - Observer count (should be 3)

### 2.3 Console Output Screenshots

#### Server Console

**What to capture:**

- Application startup logs
- Singleton initialization messages
- Observer pattern initialization
- Database connection messages

**Steps:**

1. Open your server console (Tomcat console)
2. Take screenshot showing:
   - Application startup messages
   - Singleton initialization logs
   - Observer pattern setup messages
   - Database connection success messages

#### Observer Notifications

**What to capture:**

- Dynamic observer creation messages
- Email notification output
- SMS notification output
- System log output

**Steps:**

1. Perform a flight booking in the application
2. Take screenshot of console output showing:
   - "=== DYNAMIC OBSERVER NOTIFICATION ==="
   - User-specific observer creation
   - Email notification details
   - SMS notification details
   - System log entries

### 2.4 Log Files Screenshots

#### Application Log File

**What to capture:**

- Log file content
- Timestamped entries
- Different log levels
- User activity logs

**Steps:**

1. Open `logs/skylink_application.log` file
2. Take screenshot showing:
   - Log file header
   - Recent log entries
   - Different log levels (INFO, ERROR, etc.)
   - User activity logs

#### Configuration File

**What to capture:**

- Configuration properties
- Default values
- Application settings

**Steps:**

1. Open `config/application.properties` file
2. Take screenshot showing:
   - Configuration properties
   - Database settings
   - Application settings
   - Default values

---

## 3. Testing Screenshots

### 3.1 Singleton Pattern Testing

#### Multiple Instance Test

**What to capture:**

- Code testing multiple instances
- Console output showing instances are equal
- Verification results

**Steps:**

1. Create a test class or use the demo servlet
2. Take screenshot of code testing multiple instances
3. Take screenshot of console output showing all instances are equal

### 3.2 Observer Pattern Testing

#### Booking Flow Test

**What to capture:**

- User login
- Flight search and selection
- Booking process
- Notification output

**Steps:**

1. Login as a customer
2. Search for flights
3. Select a flight and book it
4. Take screenshots of each step
5. Take screenshot of notification output in console

#### Payment Flow Test

**What to capture:**

- Payment process
- Payment confirmation
- Notification output

**Steps:**

1. Complete a booking
2. Process payment
3. Take screenshot of payment confirmation
4. Take screenshot of payment notification output

### 3.3 Database Connection Testing

#### Connection Pool Status

**What to capture:**

- Connection pool status
- Active connections count
- Connection management

**Steps:**

1. Access the singleton demo page
2. Take screenshot showing connection pool status
3. Perform multiple operations
4. Take screenshot showing connection pool changes

---

## 4. Screenshot Tools and Tips

### 4.1 Screenshot Tools

#### Windows

- **Snipping Tool**: Built-in Windows tool
- **Snagit**: Professional screenshot tool
- **Lightshot**: Free screenshot tool
- **Windows + Shift + S**: Built-in screenshot shortcut

#### Mac

- **Cmd + Shift + 4**: Select area screenshot
- **Cmd + Shift + 3**: Full screen screenshot
- **Screenshot app**: Built-in macOS tool

#### Linux

- **gnome-screenshot**: GNOME screenshot tool
- **scrot**: Command-line screenshot tool
- **Shutter**: Feature-rich screenshot tool

### 4.2 Screenshot Tips

#### Code Screenshots

- **Use syntax highlighting**: Ensure your IDE has syntax highlighting enabled
- **Focus on relevant code**: Crop to show only the important parts
- **Include line numbers**: Show line numbers for reference
- **Clear font**: Use a clear, readable font
- **Proper indentation**: Ensure code is properly formatted

#### Output Screenshots

- **Full screen capture**: Capture the entire browser window or console
- **Clear text**: Ensure text is readable and not blurry
- **Include context**: Show enough context to understand what's happening
- **Highlight important parts**: Use arrows or boxes to highlight key information

#### File Screenshots

- **Show file path**: Include the file path in the screenshot
- **Show file content**: Capture the relevant file content
- **Include timestamps**: Show file modification times if relevant
- **Clear formatting**: Ensure file content is properly formatted

### 4.3 Screenshot Organization

#### Naming Convention

- **Use descriptive names**: `singleton-database-connection-manager.png`
- **Include pattern type**: `observer-flight-booking-subject.png`
- **Include section**: `facade-database-connection.png`
- **Use consistent format**: All lowercase with hyphens

#### File Organization

```
screenshots/
├── code/
│   ├── singleton/
│   │   ├── database-connection-manager.png
│   │   ├── logger.png
│   │   └── configuration-manager.png
│   ├── observer/
│   │   ├── observer-interface.png
│   │   ├── flight-booking-subject.png
│   │   ├── dynamic-observer-manager.png
│   │   └── observer-implementations.png
│   └── facade/
│       └── database-connection.png
├── output/
│   ├── application/
│   │   ├── home-page.png
│   │   ├── login-page.png
│   │   └── booking-flow.png
│   ├── demo/
│   │   ├── singleton-demo.png
│   │   └── observer-demo.png
│   └── console/
│       ├── server-startup.png
│       ├── observer-notifications.png
│       └── database-connections.png
└── testing/
    ├── singleton-test.png
    ├── observer-test.png
    └── database-test.png
```

---

## 5. Screenshot Checklist

### 5.1 Code Screenshots

- [ ] DatabaseConnectionManager.java (Singleton)
- [ ] Logger.java (Singleton)
- [ ] ConfigurationManager.java (Singleton)
- [ ] Observer.java (Interface)
- [ ] FlightBookingSubject.java (Observer Subject)
- [ ] DynamicObserverManager.java (Observer Manager)
- [ ] EmailNotificationObserver.java (Observer Implementation)
- [ ] SMSNotificationObserver.java (Observer Implementation)
- [ ] LoggingObserver.java (Observer Implementation)
- [ ] DatabaseConnection.java (Facade)
- [ ] BookServlet.java (Usage Example)
- [ ] LoginServlet.java (Usage Example)

### 5.2 Output Screenshots

- [ ] Application home page
- [ ] Login page
- [ ] Singleton demo page
- [ ] Observer demo page
- [ ] Server console startup
- [ ] Observer notifications output
- [ ] Database connection messages
- [ ] Log file content
- [ ] Configuration file content

### 5.3 Testing Screenshots

- [ ] Singleton pattern verification
- [ ] Observer pattern testing
- [ ] Database connection testing
- [ ] Booking flow testing
- [ ] Payment flow testing
- [ ] Notification output testing

### 5.4 Quality Check

- [ ] All screenshots are clear and readable
- [ ] Code syntax highlighting is enabled
- [ ] Important parts are highlighted
- [ ] File names are descriptive
- [ ] Screenshots are properly organized
- [ ] All required sections are covered

---

## 6. Common Screenshot Mistakes to Avoid

### 6.1 Code Screenshots

- **Blurry text**: Ensure screenshots are high resolution
- **Missing context**: Include enough code to understand the pattern
- **Poor formatting**: Ensure code is properly indented and formatted
- **Wrong focus**: Focus on the pattern implementation, not unrelated code

### 6.2 Output Screenshots

- **Incomplete capture**: Capture the entire relevant output
- **Unreadable text**: Ensure text is clear and not too small
- **Missing timestamps**: Include timestamps for log entries
- **Wrong window**: Capture the correct application window

### 6.3 File Screenshots

- **Wrong file**: Ensure you're capturing the correct file
- **Incomplete content**: Show enough file content to be meaningful
- [ ] **Missing file path**: Include the file path in the screenshot
- [ ] **Poor formatting**: Ensure file content is properly formatted

---

## 7. Screenshot Examples

### 7.1 Good Code Screenshot Example

```
┌─────────────────────────────────────────────────────────────┐
│ DatabaseConnectionManager.java - IntelliJ IDEA             │
├─────────────────────────────────────────────────────────────┤
│ 1  package com.example.util;                               │
│ 2                                                          │
│ 3  import java.sql.Connection;                             │
│ 4  import java.sql.DriverManager;                          │
│ 5  import java.sql.SQLException;                           │
│ 6  import java.util.concurrent.ConcurrentHashMap;          │
│ 7                                                          │
│ 8  /**                                                     │
│ 9   * Thread-safe Singleton pattern implementation         │
│ 10  */                                                     │
│ 11 public class DatabaseConnectionManager {                │
│ 12     // Singleton instance - volatile for thread safety  │
│ 13     private static volatile DatabaseConnectionManager   │
│ 14         instance;                                        │
│ 15                                                         │
│ 16     // Private constructor to prevent instantiation     │
│ 17     private DatabaseConnectionManager() {               │
│ 18         this.connectionPool = new ConcurrentHashMap<>(); │
│ 19         loadDriver();                                    │
│ 20     }                                                   │
│ 21                                                         │
│ 22     // Thread-safe Singleton getInstance method         │
│ 23     public static DatabaseConnectionManager             │
│ 24         getInstance() {                                  │
│ 25         if (instance == null) {                         │
│ 26             synchronized (DatabaseConnectionManager.class) { │
│ 27                 if (instance == null) {                 │
│ 28                     instance = new DatabaseConnectionManager(); │
│ 29                 }                                       │
│ 30             }                                           │
│ 31         }                                               │
│ 32         return instance;                                │
│ 33     }                                                   │
└─────────────────────────────────────────────────────────────┘
```

### 7.2 Good Output Screenshot Example

```
┌─────────────────────────────────────────────────────────────┐
│ Singleton Pattern Demo - Google Chrome                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Singleton Pattern Demonstration                           │
│                                                             │
│  Singleton Instance Verification:                          │
│  Logger instances equal: true                              │
│  ConfigurationManager instances equal: true                │
│  DatabaseConnectionManager instances equal: true           │
│                                                             │
│  ✅ All Singleton patterns working correctly!              │
│                                                             │
│  Database Connection Test:                                 │
│  ✅ Database connection successful                         │
│  Connection Pool Status: Active connections: 1, Pool size: 1 │
│                                                             │
│  Logging Test:                                             │
│  ✅ Log message written successfully                       │
│  Log file: logs/skylink_application.log                    │
│                                                             │
│  Configuration Test:                                       │
│  Application Name: SkyLinkOnline                           │
│  Application Version: 1.0.0                                │
│  Database URL: jdbc:sqlserver://localhost;databaseName=... │
│  Logging Level: INFO                                       │
└─────────────────────────────────────────────────────────────┘
```

### 7.3 Good Console Output Screenshot Example

```
┌─────────────────────────────────────────────────────────────┐
│ Apache Tomcat 9.0 - Console                                │
├─────────────────────────────────────────────────────────────┤
│ [DatabaseConnectionManager] SQL Server JDBC Driver loaded  │
│ [Logger] Log file initialized: logs/skylink_application.log │
│ [ConfigurationManager] Configuration loaded from file: ... │
│                                                             │
│ === DYNAMIC OBSERVER NOTIFICATION ===                      │
│ Creating user-specific observers for User ID: 16           │
│ 📧 Created email observer for: yasindu@example.com         │
│ 📱 Created SMS observer for: +94771234567                  │
│ 📝 Created logging observer                                │
│ ✅ Created 3 observers for user: Yasindu Dharmasiri        │
│                                                             │
│ === EMAIL NOTIFICATION ===                                 │
│ To: yasindu@example.com                                    │
│ Subject: Flight booking confirmed                          │
│ Body: Dear Customer,                                       │
│ Your flight booking has been booked.                       │
│ Flight ID: 19                                              │
│ Seats: 1                                                   │
│ Total Price: $2000.00                                      │
│ Thank you for choosing SkyLink Airlines!                   │
│ =========================                                   │
└─────────────────────────────────────────────────────────────┘
```

---

## 8. Final Tips

### 8.1 Before Taking Screenshots

- **Clean up your code**: Ensure code is properly formatted
- **Test your application**: Make sure everything works
- **Prepare test data**: Have sample data ready for testing
- **Close unnecessary windows**: Keep only relevant windows open

### 8.2 While Taking Screenshots

- **Take multiple angles**: Capture different aspects of the same feature
- **Include context**: Show enough context to understand what's happening
- **Highlight important parts**: Use arrows or boxes to draw attention
- **Maintain consistency**: Use the same style for all screenshots

### 8.3 After Taking Screenshots

- **Review and select**: Choose the best screenshots for your report
- **Organize properly**: Name and organize files logically
- **Add captions**: Provide clear captions for each screenshot
- **Test in report**: Ensure screenshots display properly in your report

### 8.4 Quality Assurance

- **Check readability**: Ensure all text is readable
- **Verify completeness**: Make sure all required screenshots are included
- **Test on different devices**: Ensure screenshots look good on different screens
- **Get feedback**: Ask others to review your screenshots

---

## 9. Conclusion

This screenshots guide provides comprehensive instructions for capturing all the necessary screenshots to demonstrate your design patterns implementation. Follow these guidelines to create a professional and complete report that clearly shows your understanding and implementation of the Singleton, Observer, and Facade design patterns.

Remember to:

- **Take clear, high-quality screenshots**
- **Include all required sections**
- **Organize files properly**
- **Provide clear captions**
- **Test everything before submitting**

Good luck with your design patterns assignment! 🍀
