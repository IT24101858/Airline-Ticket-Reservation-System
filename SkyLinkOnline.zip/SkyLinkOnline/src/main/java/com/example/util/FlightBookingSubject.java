package com.example.util;

/**
 * FlightBookingSubject class that extends AbstractSubject
 * This class manages flight booking events and notifies observers
 * when booking-related events occur.
 */
public class FlightBookingSubject extends AbstractSubject {
    
    private static FlightBookingSubject instance;
    
    // Public constructor for dynamic instances
    public FlightBookingSubject() {
        // This constructor allows creating new instances for dynamic observers
    }
    
    // Private constructor for Singleton pattern
    private FlightBookingSubject(boolean isSingleton) {
        // This constructor is used for singleton instances
    }
    
    /**
     * Get the singleton instance of FlightBookingSubject
     * @return The singleton instance
     */
    public static synchronized FlightBookingSubject getInstance() {
        if (instance == null) {
            instance = new FlightBookingSubject(true);
        }
        return instance;
    }
    
    /**
     * Notify observers when a flight is booked
     * @param userId The ID of the user who made the booking
     * @param flightId The ID of the flight that was booked
     * @param seats The number of seats booked
     * @param totalPrice The total price of the booking
     */
    public void notifyFlightBooked(int userId, int flightId, int seats, double totalPrice) {
        BookingData data = new BookingData(userId, flightId, seats, totalPrice, "BOOKED");
        notifyObservers("Flight booking confirmed", data);
    }
    
    /**
     * Notify observers when a flight booking is cancelled
     * @param userId The ID of the user who cancelled the booking
     * @param flightId The ID of the flight that was cancelled
     * @param seats The number of seats that were cancelled
     */
    public void notifyFlightCancelled(int userId, int flightId, int seats) {
        BookingData data = new BookingData(userId, flightId, seats, 0.0, "CANCELLED");
        notifyObservers("Flight booking cancelled", data);
    }
    
    /**
     * Notify observers when a flight booking is rescheduled
     * @param userId The ID of the user who rescheduled the booking
     * @param oldFlightId The ID of the original flight
     * @param newFlightId The ID of the new flight
     * @param seats The number of seats rescheduled
     */
    public void notifyFlightRescheduled(int userId, int oldFlightId, int newFlightId, int seats) {
        RescheduleData data = new RescheduleData(userId, oldFlightId, newFlightId, seats);
        notifyObservers("Flight booking rescheduled", data);
    }
    
    /**
     * Notify observers when a payment is confirmed
     * @param userId The ID of the user who made the payment
     * @param bookingId The ID of the booking
     * @param amount The payment amount
     */
    public void notifyPaymentConfirmed(int userId, int bookingId, double amount) {
        PaymentData data = new PaymentData(userId, bookingId, amount, "CONFIRMED");
        notifyObservers("Payment confirmed", data);
    }
    
    /**
     * Data class to hold booking information
     */
    public static class BookingData {
        public final int userId;
        public final int flightId;
        public final int seats;
        public final double totalPrice;
        public final String status;
        
        public BookingData(int userId, int flightId, int seats, double totalPrice, String status) {
            this.userId = userId;
            this.flightId = flightId;
            this.seats = seats;
            this.totalPrice = totalPrice;
            this.status = status;
        }
        
        @Override
        public String toString() {
            return String.format("BookingData{userId=%d, flightId=%d, seats=%d, totalPrice=%.2f, status='%s'}", 
                               userId, flightId, seats, totalPrice, status);
        }
    }
    
    /**
     * Data class to hold reschedule information
     */
    public static class RescheduleData {
        public final int userId;
        public final int oldFlightId;
        public final int newFlightId;
        public final int seats;
        
        public RescheduleData(int userId, int oldFlightId, int newFlightId, int seats) {
            this.userId = userId;
            this.oldFlightId = oldFlightId;
            this.newFlightId = newFlightId;
            this.seats = seats;
        }
        
        @Override
        public String toString() {
            return String.format("RescheduleData{userId=%d, oldFlightId=%d, newFlightId=%d, seats=%d}", 
                               userId, oldFlightId, newFlightId, seats);
        }
    }
    
    /**
     * Data class to hold payment information
     */
    public static class PaymentData {
        public final int userId;
        public final int bookingId;
        public final double amount;
        public final String status;
        
        public PaymentData(int userId, int bookingId, double amount, String status) {
            this.userId = userId;
            this.bookingId = bookingId;
            this.amount = amount;
            this.status = status;
        }
        
        @Override
        public String toString() {
            return String.format("PaymentData{userId=%d, bookingId=%d, amount=%.2f, status='%s'}", 
                               userId, bookingId, amount, status);
        }
    }
}
