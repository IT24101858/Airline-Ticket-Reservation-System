package com.example.util;

/**
 * Simple test class to verify Observer Pattern implementation
 * This class demonstrates how the Observer Pattern works
 */
public class ObserverPatternTest {
    
    public static void main(String[] args) {
        System.out.println("=== Observer Pattern Test ===");
        System.out.println("Testing SkyLink Airlines Observer Pattern Implementation");
        System.out.println();
        
        // Get the singleton instance
        FlightBookingSubject subject = FlightBookingSubject.getInstance();
        
        // Register observers
        System.out.println("1. Registering Observers...");
        EmailNotificationObserver emailObserver = new EmailNotificationObserver("customer@skylink.com");
        SMSNotificationObserver smsObserver = new SMSNotificationObserver("+1234567890");
        LoggingObserver loggingObserver = new LoggingObserver("INFO");
        
        subject.addObserver(emailObserver);
        subject.addObserver(smsObserver);
        subject.addObserver(loggingObserver);
        
        System.out.println("✅ Registered " + subject.getObserverCount() + " observers");
        System.out.println();
        
        // Test 1: Flight Booking Notification
        System.out.println("2. Testing Flight Booking Notification...");
        subject.notifyFlightBooked(123, 456, 2, 299.99);
        System.out.println();
        
        // Test 2: Payment Confirmation Notification
        System.out.println("3. Testing Payment Confirmation Notification...");
        subject.notifyPaymentConfirmed(123, 789, 299.99);
        System.out.println();
        
        // Test 3: Flight Cancellation Notification
        System.out.println("4. Testing Flight Cancellation Notification...");
        subject.notifyFlightCancelled(123, 456, 2);
        System.out.println();
        
        // Test 4: Flight Rescheduling Notification
        System.out.println("5. Testing Flight Rescheduling Notification...");
        subject.notifyFlightRescheduled(123, 456, 789, 2);
        System.out.println();
        
        System.out.println("=== Test Completed Successfully ===");
        System.out.println("✅ Observer Pattern is working correctly!");
        System.out.println("✅ All notifications were sent to registered observers");
        System.out.println("✅ Email, SMS, and Logging observers all received notifications");
    }
}
