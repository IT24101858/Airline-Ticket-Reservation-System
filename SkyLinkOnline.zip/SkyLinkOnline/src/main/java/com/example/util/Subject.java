package com.example.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Subject interface for the Observer Pattern
 * This interface defines the contract for objects that can be observed
 * and can notify observers when their state changes.
 */
public interface Subject {
    
    /**
     * Add an observer to the list of observers
     * @param observer The observer to add
     */
    void addObserver(Observer observer);
    
    /**
     * Remove an observer from the list of observers
     * @param observer The observer to remove
     */
    void removeObserver(Observer observer);
    
    /**
     * Notify all observers about a state change
     * @param message The notification message
     * @param data Additional data related to the change
     */
    void notifyObservers(String message, Object data);
}

/**
 * Abstract Subject class that provides default implementation
 * for managing observers
 */
abstract class AbstractSubject implements Subject {
    
    private List<Observer> observers = new ArrayList<>();
    
    @Override
    public void addObserver(Observer observer) {
        if (observer != null && !observers.contains(observer)) {
            observers.add(observer);
        }
    }
    
    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    
    @Override
    public void notifyObservers(String message, Object data) {
        for (Observer observer : observers) {
            try {
                observer.update(message, data);
            } catch (Exception e) {
                // Log error but don't stop notifying other observers
                System.err.println("Error notifying observer: " + e.getMessage());
            }
        }
    }
    
    /**
     * Get the number of registered observers
     * @return Number of observers
     */
    public int getObserverCount() {
        return observers.size();
    }
}
