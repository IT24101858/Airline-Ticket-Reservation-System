package com.example.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * LoggingObserver class that implements Observer interface
 * This observer logs flight booking events to a log file or console
 */
public class LoggingObserver implements Observer {
    
    private String logLevel;
    
    /**
     * Constructor for LoggingObserver
     * @param logLevel The log level (INFO, WARNING, ERROR, etc.)
     */
    public LoggingObserver(String logLevel) {
        this.logLevel = logLevel;
    }
    
    @Override
    public void update(String message, Object data) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        
        System.out.println("=== SYSTEM LOG ===");
        System.out.println("[" + timestamp + "] [" + logLevel + "] " + message);
        
        if (data instanceof FlightBookingSubject.BookingData) {
            FlightBookingSubject.BookingData bookingData = (FlightBookingSubject.BookingData) data;
            System.out.println("User ID: " + bookingData.userId);
            System.out.println("Flight ID: " + bookingData.flightId);
            System.out.println("Seats: " + bookingData.seats);
            System.out.println("Status: " + bookingData.status);
            if (bookingData.totalPrice > 0) {
                System.out.println("Total Price: $" + String.format("%.2f", bookingData.totalPrice));
            }
            
        } else if (data instanceof FlightBookingSubject.RescheduleData) {
            FlightBookingSubject.RescheduleData rescheduleData = (FlightBookingSubject.RescheduleData) data;
            System.out.println("User ID: " + rescheduleData.userId);
            System.out.println("Old Flight ID: " + rescheduleData.oldFlightId);
            System.out.println("New Flight ID: " + rescheduleData.newFlightId);
            System.out.println("Seats: " + rescheduleData.seats);
            
        } else if (data instanceof FlightBookingSubject.PaymentData) {
            FlightBookingSubject.PaymentData paymentData = (FlightBookingSubject.PaymentData) data;
            System.out.println("User ID: " + paymentData.userId);
            System.out.println("Booking ID: " + paymentData.bookingId);
            System.out.println("Amount: $" + String.format("%.2f", paymentData.amount));
            System.out.println("Status: " + paymentData.status);
        }
        
        System.out.println("==================");
    }
    
    /**
     * Get the log level for this observer
     * @return The log level
     */
    public String getLogLevel() {
        return logLevel;
    }
    
    /**
     * Set the log level for this observer
     * @param logLevel The new log level
     */
    public void setLogLevel(String logLevel) {
        this.logLevel = logLevel;
    }
}
