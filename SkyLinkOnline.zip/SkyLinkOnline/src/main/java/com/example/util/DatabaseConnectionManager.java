package com.example.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe Singleton pattern implementation for database connection management.
 * Ensures only one instance exists throughout the application lifecycle.
 * Provides connection pooling capabilities for better performance.
 */
public class DatabaseConnectionManager {
    
    // Singleton instance - volatile for thread safety
    private static volatile DatabaseConnectionManager instance;
    
    // Connection pool for better performance
    private final ConcurrentHashMap<String, Connection> connectionPool;
    
    // Database connection constants
    private static final String DB_URL = "jdbc:sqlserver://localhost;databaseName=SkyLinkOnline;integratedSecurity=false;";
    private static final String DB_USER = "sa";
    private static final String DB_PASSWORD = "789";
    private static final String DRIVER_CLASS = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    
    // Private constructor to prevent instantiation
    private DatabaseConnectionManager() {
        this.connectionPool = new ConcurrentHashMap<>();
        loadDriver();
    }
    
    /**
     * Thread-safe Singleton getInstance method using double-checked locking
     * @return The single instance of DatabaseConnectionManager
     */
    public static DatabaseConnectionManager getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnectionManager.class) {
                if (instance == null) {
                    instance = new DatabaseConnectionManager();
                }
            }
        }
        return instance;
    }
    
    /**
     * Load the JDBC driver
     */
    private void loadDriver() {
        try {
            Class.forName(DRIVER_CLASS);
            System.out.println("[DatabaseConnectionManager] SQL Server JDBC Driver loaded successfully");
        } catch (ClassNotFoundException e) {
            System.err.println("[DatabaseConnectionManager] Failed to load SQL Server JDBC Driver: " + e.getMessage());
            throw new RuntimeException("Database driver not found", e);
        }
    }
    
    /**
     * Get a database connection with connection pooling
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public Connection getConnection() throws SQLException {
        String threadId = Thread.currentThread().getName();
        
        // Check if connection exists in pool
        Connection connection = connectionPool.get(threadId);
        
        if (connection == null || connection.isClosed()) {
            try {
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                connectionPool.put(threadId, connection);
                System.out.println("[DatabaseConnectionManager] New connection created for thread: " + threadId);
            } catch (SQLException e) {
                System.err.println("[DatabaseConnectionManager] Failed to establish database connection: " + e.getMessage());
                throw e;
            }
        }
        
        return connection;
    }
    
    /**
     * Get a database connection with additional connection properties
     * @param encrypt Whether to use encryption
     * @param trustServerCertificate Whether to trust server certificate
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public Connection getConnection(boolean encrypt, boolean trustServerCertificate) throws SQLException {
        String threadId = Thread.currentThread().getName() + "_encrypted";
        
        Connection connection = connectionPool.get(threadId);
        
        if (connection == null || connection.isClosed()) {
            try {
                String url = DB_URL;
                if (encrypt) {
                    url += "encrypt=true;";
                }
                if (trustServerCertificate) {
                    url += "trustServerCertificate=true;";
                }
                
                connection = DriverManager.getConnection(url, DB_USER, DB_PASSWORD);
                connectionPool.put(threadId, connection);
                System.out.println("[DatabaseConnectionManager] Encrypted connection created for thread: " + threadId);
            } catch (SQLException e) {
                System.err.println("[DatabaseConnectionManager] Failed to establish encrypted database connection: " + e.getMessage());
                throw e;
            }
        }
        
        return connection;
    }
    
    /**
     * Close a specific connection
     * @param connection The connection to close
     */
    public void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                // Remove from pool
                String threadId = Thread.currentThread().getName();
                connectionPool.remove(threadId);
                
                connection.close();
                System.out.println("[DatabaseConnectionManager] Connection closed for thread: " + threadId);
            } catch (SQLException e) {
                System.err.println("[DatabaseConnectionManager] Error closing database connection: " + e.getMessage());
            }
        }
    }
    
    /**
     * Close all connections in the pool
     */
    public void closeAllConnections() {
        System.out.println("[DatabaseConnectionManager] Closing all connections in pool...");
        for (Connection connection : connectionPool.values()) {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println("[DatabaseConnectionManager] Error closing connection: " + e.getMessage());
            }
        }
        connectionPool.clear();
        System.out.println("[DatabaseConnectionManager] All connections closed");
    }
    
    /**
     * Test the database connection
     * @return true if connection is successful, false otherwise
     */
    public boolean testConnection() {
        try (Connection connection = getConnection()) {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            System.err.println("[DatabaseConnectionManager] Database connection test failed: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get the number of active connections in the pool
     * @return Number of active connections
     */
    public int getActiveConnectionCount() {
        return connectionPool.size();
    }
    
    /**
     * Get connection pool status
     * @return String representation of connection pool status
     */
    public String getConnectionPoolStatus() {
        return String.format("Active connections: %d, Pool size: %d", 
                           connectionPool.size(), connectionPool.size());
    }
    
    /**
     * Prevent cloning of the singleton instance
     */
    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Singleton instance cannot be cloned");
    }
    
    /**
     * Prevent deserialization of the singleton instance
     */
    protected Object readResolve() {
        return getInstance();
    }
}
