package com.example.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.example.util.DatabaseConnection;

/**
 * DynamicObserverManager class that creates observers dynamically based on user data
 * This ensures that notifications are sent to the correct user's email and phone
 */
public class DynamicObserverManager {
    
    private static DynamicObserverManager instance;
    
    private DynamicObserverManager() {}
    
    /**
     * Get the singleton instance of DynamicObserverManager
     * @return The singleton instance
     */
    public static synchronized DynamicObserverManager getInstance() {
        if (instance == null) {
            instance = new DynamicObserverManager();
        }
        return instance;
    }
    
    /**
     * Create and register observers for a specific user
     * @param userId The user ID to create observers for
     * @return List of created observers
     */
    public List<Observer> createUserObservers(int userId) {
        List<Observer> observers = new ArrayList<>();
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            // Get user details from database
            PreparedStatement stmt = conn.prepareStatement(
                "SELECT email, phone_number, first_name, last_name FROM Users WHERE id = ?"
            );
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                String email = rs.getString("email");
                String phoneNumber = rs.getString("phone_number");
                String firstName = rs.getString("first_name");
                String lastName = rs.getString("last_name");
                
                // Create email observer with user's email
                if (email != null && !email.trim().isEmpty()) {
                    EmailNotificationObserver emailObserver = new EmailNotificationObserver(email);
                    observers.add(emailObserver);
                    System.out.println("📧 Created email observer for: " + email);
                } else {
                    // Fallback to default email
                    EmailNotificationObserver emailObserver = new EmailNotificationObserver("customer@skylink.com");
                    observers.add(emailObserver);
                    System.out.println("📧 Created default email observer (user email not available)");
                }
                
                // Create SMS observer with user's phone number
                if (phoneNumber != null && !phoneNumber.trim().isEmpty()) {
                    SMSNotificationObserver smsObserver = new SMSNotificationObserver(phoneNumber);
                    observers.add(smsObserver);
                    System.out.println("📱 Created SMS observer for: " + phoneNumber);
                } else {
                    // Fallback to default phone number
                    SMSNotificationObserver smsObserver = new SMSNotificationObserver("+1234567890");
                    observers.add(smsObserver);
                    System.out.println("📱 Created default SMS observer (user phone not available)");
                }
                
                // Always create logging observer
                LoggingObserver loggingObserver = new LoggingObserver("INFO");
                observers.add(loggingObserver);
                System.out.println("📝 Created logging observer");
                
                System.out.println("✅ Created " + observers.size() + " observers for user: " + 
                                 (firstName != null ? firstName : "Unknown") + " " + 
                                 (lastName != null ? lastName : ""));
                
            } else {
                System.out.println("⚠️ User not found in database, creating default observers");
                // Create default observers if user not found
                observers.add(new EmailNotificationObserver("customer@skylink.com"));
                observers.add(new SMSNotificationObserver("+1234567890"));
                observers.add(new LoggingObserver("INFO"));
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error creating user observers: " + e.getMessage());
            // Create default observers as fallback
            observers.add(new EmailNotificationObserver("customer@skylink.com"));
            observers.add(new SMSNotificationObserver("+1234567890"));
            observers.add(new LoggingObserver("INFO"));
        }
        
        return observers;
    }
    
    /**
     * Notify observers for a specific user about flight booking
     * @param userId The user ID
     * @param flightId The flight ID
     * @param seats Number of seats
     * @param totalPrice Total price
     */
    public void notifyUserFlightBooked(int userId, int flightId, int seats, double totalPrice) {
        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION ===");
        System.out.println("Creating user-specific observers for User ID: " + userId);
        
        List<Observer> userObservers = createUserObservers(userId);
        
        // Create temporary subject for this user
        FlightBookingSubject tempSubject = new FlightBookingSubject();
        
        // Add user-specific observers
        for (Observer observer : userObservers) {
            tempSubject.addObserver(observer);
        }
        
        // Send notification
        tempSubject.notifyFlightBooked(userId, flightId, seats, totalPrice);
        
        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION COMPLETE ===");
    }
    
    /**
     * Notify observers for a specific user about payment confirmation
     * @param userId The user ID
     * @param bookingId The booking ID
     * @param amount The payment amount
     */
    public void notifyUserPaymentConfirmed(int userId, int bookingId, double amount) {
        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION ===");
        System.out.println("Creating user-specific observers for User ID: " + userId);
        
        List<Observer> userObservers = createUserObservers(userId);
        
        // Create temporary subject for this user
        FlightBookingSubject tempSubject = new FlightBookingSubject();
        
        // Add user-specific observers
        for (Observer observer : userObservers) {
            tempSubject.addObserver(observer);
        }
        
        // Send notification
        tempSubject.notifyPaymentConfirmed(userId, bookingId, amount);
        
        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION COMPLETE ===");
    }
    
    /**
     * Notify observers for a specific user about flight cancellation
     * @param userId The user ID
     * @param flightId The flight ID
     * @param seats Number of seats
     */
    public void notifyUserFlightCancelled(int userId, int flightId, int seats) {
        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION ===");
        System.out.println("Creating user-specific observers for User ID: " + userId);
        
        List<Observer> userObservers = createUserObservers(userId);
        
        // Create temporary subject for this user
        FlightBookingSubject tempSubject = new FlightBookingSubject();
        
        // Add user-specific observers
        for (Observer observer : userObservers) {
            tempSubject.addObserver(observer);
        }
        
        // Send notification
        tempSubject.notifyFlightCancelled(userId, flightId, seats);
        
        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION COMPLETE ===");
    }
}
