package com.example.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Thread-safe Singleton Logger implementation.
 * Provides centralized logging functionality for the entire application.
 * Supports different log levels and file-based logging.
 */
public class Logger {
    
    // Singleton instance - volatile for thread safety
    private static volatile Logger instance;
    
    // Thread-safe lock for file operations
    private final ReentrantLock lock = new ReentrantLock();
    
    // Log file path
    private static final String LOG_FILE_PATH = "logs/skylink_application.log";
    
    // Date formatter for timestamps
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    // Log levels
    public enum LogLevel {
        DEBUG, INFO, WARN, ERROR, FATAL
    }
    
    // Current log level (default: INFO)
    private LogLevel currentLogLevel = LogLevel.INFO;
    
    // Private constructor to prevent instantiation
    private Logger() {
        // Initialize log file
        initializeLogFile();
    }
    
    /**
     * Thread-safe Singleton getInstance method using double-checked locking
     * @return The single instance of Logger
     */
    public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }
    
    /**
     * Initialize the log file
     */
    private void initializeLogFile() {
        try {
            // Create logs directory if it doesn't exist
            java.io.File logDir = new java.io.File("logs");
            if (!logDir.exists()) {
                logDir.mkdirs();
            }
            
            // Test file creation
            try (FileWriter fw = new FileWriter(LOG_FILE_PATH, true)) {
                fw.write("=== SkyLinkOnline Application Logger Initialized ===\n");
                fw.write("Started at: " + LocalDateTime.now().format(DATE_FORMATTER) + "\n");
                fw.write("==================================================\n");
            }
            
            System.out.println("[Logger] Log file initialized: " + LOG_FILE_PATH);
        } catch (IOException e) {
            System.err.println("[Logger] Failed to initialize log file: " + e.getMessage());
        }
    }
    
    /**
     * Set the current log level
     * @param level The log level to set
     */
    public void setLogLevel(LogLevel level) {
        this.currentLogLevel = level;
        info("Log level changed to: " + level);
    }
    
    /**
     * Get the current log level
     * @return Current log level
     */
    public LogLevel getLogLevel() {
        return currentLogLevel;
    }
    
    /**
     * Log a message with specified level
     * @param level Log level
     * @param message Message to log
     * @param throwable Optional throwable
     */
    public void log(LogLevel level, String message, Throwable throwable) {
        if (level.ordinal() < currentLogLevel.ordinal()) {
            return; // Skip logging if level is below current threshold
        }
        
        String timestamp = LocalDateTime.now().format(DATE_FORMATTER);
        String threadName = Thread.currentThread().getName();
        String logEntry = String.format("[%s] [%s] [%s] [%s] %s", 
                                      timestamp, level, threadName, getCallerInfo(), message);
        
        // Print to console
        if (level == LogLevel.ERROR || level == LogLevel.FATAL) {
            System.err.println(logEntry);
            if (throwable != null) {
                throwable.printStackTrace();
            }
        } else {
            System.out.println(logEntry);
        }
        
        // Write to file
        writeToFile(logEntry, throwable);
    }
    
    /**
     * Log a message with specified level
     * @param level Log level
     * @param message Message to log
     */
    public void log(LogLevel level, String message) {
        log(level, message, null);
    }
    
    /**
     * Log debug message
     * @param message Message to log
     */
    public void debug(String message) {
        log(LogLevel.DEBUG, message);
    }
    
    /**
     * Log info message
     * @param message Message to log
     */
    public void info(String message) {
        log(LogLevel.INFO, message);
    }
    
    /**
     * Log warning message
     * @param message Message to log
     */
    public void warn(String message) {
        log(LogLevel.WARN, message);
    }
    
    /**
     * Log error message
     * @param message Message to log
     */
    public void error(String message) {
        log(LogLevel.ERROR, message);
    }
    
    /**
     * Log error message with throwable
     * @param message Message to log
     * @param throwable Throwable to log
     */
    public void error(String message, Throwable throwable) {
        log(LogLevel.ERROR, message, throwable);
    }
    
    /**
     * Log fatal message
     * @param message Message to log
     */
    public void fatal(String message) {
        log(LogLevel.FATAL, message);
    }
    
    /**
     * Log fatal message with throwable
     * @param message Message to log
     * @param throwable Throwable to log
     */
    public void fatal(String message, Throwable throwable) {
        log(LogLevel.FATAL, message, throwable);
    }
    
    /**
     * Write log entry to file
     * @param logEntry Log entry to write
     * @param throwable Optional throwable
     */
    private void writeToFile(String logEntry, Throwable throwable) {
        lock.lock();
        try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE_PATH, true))) {
            writer.println(logEntry);
            if (throwable != null) {
                writer.println("Exception details:");
                throwable.printStackTrace(writer);
            }
            writer.flush();
        } catch (IOException e) {
            System.err.println("[Logger] Failed to write to log file: " + e.getMessage());
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * Get caller information for logging
     * @return Caller information string
     */
    private String getCallerInfo() {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        if (stackTrace.length > 4) {
            StackTraceElement caller = stackTrace[4];
            return caller.getClassName() + "." + caller.getMethodName() + ":" + caller.getLineNumber();
        }
        return "Unknown";
    }
    
    /**
     * Clear the log file
     */
    public void clearLogFile() {
        lock.lock();
        try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE_PATH, false))) {
            writer.write("=== SkyLinkOnline Application Logger Cleared ===\n");
            writer.write("Cleared at: " + LocalDateTime.now().format(DATE_FORMATTER) + "\n");
            writer.write("================================================\n");
            writer.flush();
            info("Log file cleared");
        } catch (IOException e) {
            error("Failed to clear log file", e);
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * Get log file path
     * @return Log file path
     */
    public String getLogFilePath() {
        return LOG_FILE_PATH;
    }
    
    /**
     * Prevent cloning of the singleton instance
     */
    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Singleton instance cannot be cloned");
    }
    
    /**
     * Prevent deserialization of the singleton instance
     */
    protected Object readResolve() {
        return getInstance();
    }
}
