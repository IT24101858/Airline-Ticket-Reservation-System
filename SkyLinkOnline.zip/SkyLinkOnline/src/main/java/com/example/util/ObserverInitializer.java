package com.example.util;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

/**
 * ObserverInitializer class that initializes observers when the web application starts
 * This ensures that observers are registered and ready to receive notifications
 */
@WebListener
public class ObserverInitializer implements ServletContextListener {
    
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("=== Initializing Observer Pattern ===");
        
        // Get the singleton instance
        FlightBookingSubject subject = FlightBookingSubject.getInstance();
        
        // Register default observers
        EmailNotificationObserver emailObserver = new EmailNotificationObserver("customer@skylink.com");
        SMSNotificationObserver smsObserver = new SMSNotificationObserver("+1234567890");
        LoggingObserver loggingObserver = new LoggingObserver("INFO");
        
        subject.addObserver(emailObserver);
        subject.addObserver(smsObserver);
        subject.addObserver(loggingObserver);
        
        System.out.println("✅ Registered " + subject.getObserverCount() + " observers:");
        System.out.println("   - Email Notification Observer (customer@skylink.com)");
        System.out.println("   - SMS Notification Observer (+1234567890)");
        System.out.println("   - Logging Observer (INFO level)");
        System.out.println("=== Observer Pattern Initialization Complete ===");
        
        // Store in servlet context for potential future use
        sce.getServletContext().setAttribute("observerSubject", subject);
    }
    
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("=== Observer Pattern Shutdown ===");
        // Clean up if needed
    }
}
