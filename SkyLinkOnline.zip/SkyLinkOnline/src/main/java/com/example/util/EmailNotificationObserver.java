package com.example.util;

/**
 * EmailNotificationObserver class that implements Observer interface
 * This observer sends email notifications when flight booking events occur
 */
public class EmailNotificationObserver implements Observer {
    
    private String emailAddress;
    
    /**
     * Constructor for EmailNotificationObserver
     * @param emailAddress The email address to send notifications to
     */
    public EmailNotificationObserver(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    
    @Override
    public void update(String message, Object data) {
        System.out.println("=== EMAIL NOTIFICATION ===");
        System.out.println("To: " + emailAddress);
        System.out.println("Subject: " + message);
        
        if (data instanceof FlightBookingSubject.BookingData) {
            FlightBookingSubject.BookingData bookingData = (FlightBookingSubject.BookingData) data;
            System.out.println("Body: Dear Customer,");
            System.out.println("Your flight booking has been " + bookingData.status.toLowerCase() + ".");
            System.out.println("Flight ID: " + bookingData.flightId);
            System.out.println("Seats: " + bookingData.seats);
            if (bookingData.totalPrice > 0) {
                System.out.println("Total Price: $" + String.format("%.2f", bookingData.totalPrice));
            }
            System.out.println("Thank you for choosing SkyLink Airlines!");
            
        } else if (data instanceof FlightBookingSubject.RescheduleData) {
            FlightBookingSubject.RescheduleData rescheduleData = (FlightBookingSubject.RescheduleData) data;
            System.out.println("Body: Dear Customer,");
            System.out.println("Your flight has been rescheduled.");
            System.out.println("Old Flight ID: " + rescheduleData.oldFlightId);
            System.out.println("New Flight ID: " + rescheduleData.newFlightId);
            System.out.println("Seats: " + rescheduleData.seats);
            System.out.println("Please check your new flight details.");
            
        } else if (data instanceof FlightBookingSubject.PaymentData) {
            FlightBookingSubject.PaymentData paymentData = (FlightBookingSubject.PaymentData) data;
            System.out.println("Body: Dear Customer,");
            System.out.println("Your payment has been " + paymentData.status.toLowerCase() + ".");
            System.out.println("Booking ID: " + paymentData.bookingId);
            System.out.println("Amount: $" + String.format("%.2f", paymentData.amount));
            System.out.println("Your booking is now confirmed!");
        }
        
        System.out.println("=========================");
    }
    
    /**
     * Get the email address for this observer
     * @return The email address
     */
    public String getEmailAddress() {
        return emailAddress;
    }
    
    /**
     * Set the email address for this observer
     * @param emailAddress The new email address
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}
