package com.example.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Thread-safe Singleton Configuration Manager.
 * Provides centralized configuration management for the entire application.
 * Supports loading and saving configuration properties from/to files.
 */
public class ConfigurationManager {
    
    // Singleton instance - volatile for thread safety
    private static volatile ConfigurationManager instance;
    
    // Thread-safe read-write lock for properties access
    private final ReadWriteLock lock = new ReentrantReadWriteLock();
    
    // Properties object to store configuration
    private final Properties properties;
    
    // Configuration file path
    private static final String CONFIG_FILE_PATH = "config/application.properties";
    
    // Default configuration values
    private static final String[][] DEFAULT_CONFIG = {
        {"database.url", "jdbc:sqlserver://localhost;databaseName=SkyLinkOnline;integratedSecurity=false;"},
        {"database.username", "sa"},
        {"database.password", "789"},
        {"database.driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver"},
        {"application.name", "SkyLinkOnline"},
        {"application.version", "1.0.0"},
        {"application.debug", "false"},
        {"logging.level", "INFO"},
        {"logging.file.path", "logs/skylink_application.log"},
        {"session.timeout", "1800"},
        {"max.connections", "10"},
        {"backup.frequency", "daily"},
        {"backup.path", "backups/"},
        {"email.smtp.host", "localhost"},
        {"email.smtp.port", "587"},
        {"email.smtp.username", ""},
        {"email.smtp.password", ""},
        {"payment.gateway.url", "https://api.paymentgateway.com"},
        {"payment.gateway.timeout", "30000"},
        {"security.password.min.length", "8"},
        {"security.session.max.age", "3600"}
    };
    
    // Private constructor to prevent instantiation
    private ConfigurationManager() {
        this.properties = new Properties();
        loadConfiguration();
    }
    
    /**
     * Thread-safe Singleton getInstance method using double-checked locking
     * @return The single instance of ConfigurationManager
     */
    public static ConfigurationManager getInstance() {
        if (instance == null) {
            synchronized (ConfigurationManager.class) {
                if (instance == null) {
                    instance = new ConfigurationManager();
                }
            }
        }
        return instance;
    }
    
    /**
     * Load configuration from file or create default configuration
     */
    private void loadConfiguration() {
        lock.writeLock().lock();
        try {
            // Create config directory if it doesn't exist
            java.io.File configDir = new java.io.File("config");
            if (!configDir.exists()) {
                configDir.mkdirs();
            }
            
            // Try to load existing configuration
            try (FileInputStream fis = new FileInputStream(CONFIG_FILE_PATH)) {
                properties.load(fis);
                System.out.println("[ConfigurationManager] Configuration loaded from file: " + CONFIG_FILE_PATH);
            } catch (IOException e) {
                System.out.println("[ConfigurationManager] Configuration file not found, creating default configuration");
                createDefaultConfiguration();
            }
            
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * Create default configuration
     */
    private void createDefaultConfiguration() {
        for (String[] config : DEFAULT_CONFIG) {
            properties.setProperty(config[0], config[1]);
        }
        saveConfiguration();
    }
    
    /**
     * Save configuration to file
     */
    public void saveConfiguration() {
        lock.writeLock().lock();
        try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE_PATH)) {
            properties.store(fos, "SkyLinkOnline Application Configuration\nGenerated on: " + java.time.LocalDateTime.now());
            System.out.println("[ConfigurationManager] Configuration saved to file: " + CONFIG_FILE_PATH);
        } catch (IOException e) {
            System.err.println("[ConfigurationManager] Failed to save configuration: " + e.getMessage());
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * Get a configuration property value
     * @param key Property key
     * @return Property value or null if not found
     */
    public String getProperty(String key) {
        lock.readLock().lock();
        try {
            return properties.getProperty(key);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Get a configuration property value with default
     * @param key Property key
     * @param defaultValue Default value if property not found
     * @return Property value or default value
     */
    public String getProperty(String key, String defaultValue) {
        lock.readLock().lock();
        try {
            return properties.getProperty(key, defaultValue);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Set a configuration property value
     * @param key Property key
     * @param value Property value
     */
    public void setProperty(String key, String value) {
        lock.writeLock().lock();
        try {
            properties.setProperty(key, value);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * Get database URL
     * @return Database URL
     */
    public String getDatabaseUrl() {
        return getProperty("database.url");
    }
    
    /**
     * Get database username
     * @return Database username
     */
    public String getDatabaseUsername() {
        return getProperty("database.username");
    }
    
    /**
     * Get database password
     * @return Database password
     */
    public String getDatabasePassword() {
        return getProperty("database.password");
    }
    
    /**
     * Get database driver class
     * @return Database driver class
     */
    public String getDatabaseDriver() {
        return getProperty("database.driver");
    }
    
    /**
     * Get application name
     * @return Application name
     */
    public String getApplicationName() {
        return getProperty("application.name");
    }
    
    /**
     * Get application version
     * @return Application version
     */
    public String getApplicationVersion() {
        return getProperty("application.version");
    }
    
    /**
     * Check if debug mode is enabled
     * @return true if debug mode is enabled
     */
    public boolean isDebugEnabled() {
        return Boolean.parseBoolean(getProperty("application.debug", "false"));
    }
    
    /**
     * Get logging level
     * @return Logging level
     */
    public String getLoggingLevel() {
        return getProperty("logging.level", "INFO");
    }
    
    /**
     * Get session timeout in seconds
     * @return Session timeout
     */
    public int getSessionTimeout() {
        return Integer.parseInt(getProperty("session.timeout", "1800"));
    }
    
    /**
     * Get maximum number of connections
     * @return Maximum connections
     */
    public int getMaxConnections() {
        return Integer.parseInt(getProperty("max.connections", "10"));
    }
    
    /**
     * Get backup frequency
     * @return Backup frequency
     */
    public String getBackupFrequency() {
        return getProperty("backup.frequency", "daily");
    }
    
    /**
     * Get backup path
     * @return Backup path
     */
    public String getBackupPath() {
        return getProperty("backup.path", "backups/");
    }
    
    /**
     * Get email SMTP host
     * @return SMTP host
     */
    public String getEmailSmtpHost() {
        return getProperty("email.smtp.host", "localhost");
    }
    
    /**
     * Get email SMTP port
     * @return SMTP port
     */
    public int getEmailSmtpPort() {
        return Integer.parseInt(getProperty("email.smtp.port", "587"));
    }
    
    /**
     * Get payment gateway URL
     * @return Payment gateway URL
     */
    public String getPaymentGatewayUrl() {
        return getProperty("payment.gateway.url");
    }
    
    /**
     * Get payment gateway timeout
     * @return Payment gateway timeout in milliseconds
     */
    public int getPaymentGatewayTimeout() {
        return Integer.parseInt(getProperty("payment.gateway.timeout", "30000"));
    }
    
    /**
     * Get minimum password length
     * @return Minimum password length
     */
    public int getMinPasswordLength() {
        return Integer.parseInt(getProperty("security.password.min.length", "8"));
    }
    
    /**
     * Get maximum session age
     * @return Maximum session age in seconds
     */
    public int getMaxSessionAge() {
        return Integer.parseInt(getProperty("security.session.max.age", "3600"));
    }
    
    /**
     * Get all configuration properties
     * @return Properties object
     */
    public Properties getAllProperties() {
        lock.readLock().lock();
        try {
            Properties copy = new Properties();
            copy.putAll(properties);
            return copy;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Check if a property exists
     * @param key Property key
     * @return true if property exists
     */
    public boolean hasProperty(String key) {
        lock.readLock().lock();
        try {
            return properties.containsKey(key);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Remove a property
     * @param key Property key
     * @return Previous value or null
     */
    public String removeProperty(String key) {
        lock.writeLock().lock();
        try {
            return (String) properties.remove(key);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * Get configuration file path
     * @return Configuration file path
     */
    public String getConfigFilePath() {
        return CONFIG_FILE_PATH;
    }
    
    /**
     * Reload configuration from file
     */
    public void reloadConfiguration() {
        lock.writeLock().lock();
        try {
            properties.clear();
            loadConfiguration();
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * Prevent cloning of the singleton instance
     */
    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Singleton instance cannot be cloned");
    }
    
    /**
     * Prevent deserialization of the singleton instance
     */
    protected Object readResolve() {
        return getInstance();
    }
}
