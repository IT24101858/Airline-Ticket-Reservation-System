package com.example.util;

/**
 * SMSNotificationObserver class that implements Observer interface
 * This observer sends SMS notifications when flight booking events occur
 */
public class SMSNotificationObserver implements Observer {
    
    private String phoneNumber;
    
    /**
     * Constructor for SMSNotificationObserver
     * @param phoneNumber The phone number to send SMS notifications to
     */
    public SMSNotificationObserver(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    @Override
    public void update(String message, Object data) {
        System.out.println("=== SMS NOTIFICATION ===");
        System.out.println("To: " + phoneNumber);
        
        if (data instanceof FlightBookingSubject.BookingData) {
            FlightBookingSubject.BookingData bookingData = (FlightBookingSubject.BookingData) data;
            System.out.println("Message: SkyLink Airlines - Flight " + bookingData.status.toLowerCase() + 
                             "! Flight ID: " + bookingData.flightId + 
                             ", Seats: " + bookingData.seats);
            if (bookingData.totalPrice > 0) {
                System.out.println("Amount: $" + String.format("%.2f", bookingData.totalPrice));
            }
            
        } else if (data instanceof FlightBookingSubject.RescheduleData) {
            FlightBookingSubject.RescheduleData rescheduleData = (FlightBookingSubject.RescheduleData) data;
            System.out.println("Message: SkyLink Airlines - Flight rescheduled! " +
                             "New Flight ID: " + rescheduleData.newFlightId + 
                             ", Seats: " + rescheduleData.seats);
            
        } else if (data instanceof FlightBookingSubject.PaymentData) {
            FlightBookingSubject.PaymentData paymentData = (FlightBookingSubject.PaymentData) data;
            System.out.println("Message: SkyLink Airlines - Payment " + paymentData.status.toLowerCase() + 
                             "! Booking ID: " + paymentData.bookingId + 
                             ", Amount: $" + String.format("%.2f", paymentData.amount));
        }
        
        System.out.println("=======================");
    }
    
    /**
     * Get the phone number for this observer
     * @return The phone number
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    /**
     * Set the phone number for this observer
     * @param phoneNumber The new phone number
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
