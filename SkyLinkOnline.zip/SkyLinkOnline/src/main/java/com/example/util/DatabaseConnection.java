package com.example.util;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Database connection utility class for SkyLinkOnline application.
 * Now uses Singleton pattern for better resource management.
 * This class acts as a facade to the DatabaseConnectionManager singleton.
 */
public class DatabaseConnection {
    
    // Singleton instance of DatabaseConnectionManager
    private static final DatabaseConnectionManager connectionManager = DatabaseConnectionManager.getInstance();
    
    // Static block to initialize the connection manager
    static {
        try {
            // Test the connection on startup
            connectionManager.testConnection();
            System.out.println("[DatabaseConnection] DatabaseConnectionManager initialized successfully");
        } catch (Exception e) {
            System.err.println("[DatabaseConnection] Failed to initialize DatabaseConnectionManager: " + e.getMessage());
            throw new RuntimeException("Database connection manager initialization failed", e);
        }
    }
    
    /**
     * Gets a database connection using the Singleton connection manager.
     * 
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection() throws SQLException {
        return connectionManager.getConnection();
    }
    
    /**
     * Gets a database connection with additional connection properties.
     * 
     * @param encrypt Whether to use encryption
     * @param trustServerCertificate Whether to trust server certificate
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection(boolean encrypt, boolean trustServerCertificate) throws SQLException {
        return connectionManager.getConnection(encrypt, trustServerCertificate);
    }
    
    /**
     * Closes a database connection safely using the Singleton connection manager.
     * 
     * @param connection The connection to close
     */
    public static void closeConnection(Connection connection) {
        connectionManager.closeConnection(connection);
    }
    
    /**
     * Tests the database connection using the Singleton connection manager.
     * 
     * @return true if connection is successful, false otherwise
     */
    public static boolean testConnection() {
        return connectionManager.testConnection();
    }
    
    /**
     * Get the number of active connections in the pool.
     * 
     * @return Number of active connections
     */
    public static int getActiveConnectionCount() {
        return connectionManager.getActiveConnectionCount();
    }
    
    /**
     * Get connection pool status.
     * 
     * @return String representation of connection pool status
     */
    public static String getConnectionPoolStatus() {
        return connectionManager.getConnectionPoolStatus();
    }
    
    /**
     * Close all connections in the pool.
     */
    public static void closeAllConnections() {
        connectionManager.closeAllConnections();
    }
}
