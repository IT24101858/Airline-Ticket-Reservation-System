package com.example.util;

/**
 * Observer interface for the Observer Pattern
 * This interface defines the contract for objects that want to be notified
 * when a subject's state changes.
 */
public interface Observer {
    
    /**
     * Method called by the subject when a state change occurs
     * @param message The notification message
     * @param data Additional data related to the change
     */
    void update(String message, Object data);
}
