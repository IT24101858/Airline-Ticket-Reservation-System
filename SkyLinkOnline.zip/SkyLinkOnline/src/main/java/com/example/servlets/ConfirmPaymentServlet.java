package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
import com.example.util.DatabaseConnection;
import com.example.util.FlightBookingSubject;

@WebServlet("/confirmPayment")
public class ConfirmPaymentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Session + Role check
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null || !"finance_officer".equals(session.getAttribute("role"))) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Get transaction ID and booking ID from request parameters
        String transactionIdStr = request.getParameter("transaction_id");
        String bookingIdStr = request.getParameter("booking_id");
        System.out.println("[ConfirmPaymentServlet] doPost - transaction_id=" + transactionIdStr + ", booking_id=" + bookingIdStr);

        if (transactionIdStr == null || bookingIdStr == null) {
            response.sendRedirect(request.getContextPath() + "/failed_alerts.jsp?message=Invalid transaction details");
            return;
        }

        int transactionId;
        int bookingId;

        try {
            transactionId = Integer.parseInt(transactionIdStr);
            bookingId = Integer.parseInt(bookingIdStr);
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/failed_alerts.jsp?message=Invalid transaction or booking ID");
            return;
        }

        // Database connection and query execution
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DatabaseConnection.getConnection();

            // Start a transaction (commit and rollback handling)
            conn.setAutoCommit(false);

            // Step 1: Update Transaction status to "success"
            String updateTransactionQuery = "UPDATE Transactions SET status = 'success' WHERE id = ? AND status = 'pending'";
            ps = conn.prepareStatement(updateTransactionQuery);
            ps.setInt(1, transactionId);
            int rowsUpdated = ps.executeUpdate();

            if (rowsUpdated == 0) {
                System.out.println("[ConfirmPaymentServlet] Transaction not found or already processed: id=" + transactionId);
                conn.rollback();
                response.sendRedirect(request.getContextPath() + "/failed_alerts.jsp?message=Transaction not found or already processed");
                return;
            }

            // Step 2: Update Booking status to "confirmed"
            String updateBookingQuery = "UPDATE Bookings SET status = 'confirmed' WHERE id = ?";
            ps = conn.prepareStatement(updateBookingQuery);
            ps.setInt(1, bookingId);
            ps.executeUpdate();

            // Commit the transaction
            conn.commit();
            System.out.println("[ConfirmPaymentServlet] Payment confirmed, booking updated for booking_id=" + bookingId);

            // Get booking details for notification
            try (PreparedStatement getBookingDetails = conn.prepareStatement(
                    "SELECT user_id, total_price FROM Bookings WHERE id = ?")) {
                getBookingDetails.setInt(1, bookingId);
                ResultSet bookingRs = getBookingDetails.executeQuery();
                if (bookingRs.next()) {
                    int userId = bookingRs.getInt("user_id");
                    double amount = bookingRs.getDouble("total_price");
                    
                    // Notify observers about the payment confirmation
                    FlightBookingSubject.getInstance().notifyPaymentConfirmed(userId, bookingId, amount);
                }
            }

            // Send confirmation response
            response.sendRedirect(request.getContextPath() + "/successful_alerts.jsp?message=Payment confirmed successfully");

        } catch (SQLException e) {
            e.printStackTrace();
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ignored) {}
            System.out.println("[ConfirmPaymentServlet] Error confirming payment: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/failed_alerts.jsp?message=Error confirming payment");
        } finally {
            try {
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException ignored) {}
        }
    }
}
