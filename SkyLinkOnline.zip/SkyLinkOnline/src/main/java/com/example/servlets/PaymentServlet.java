package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;
import com.example.util.FlightBookingSubject;
import com.example.util.DynamicObserverManager;
// import java.util.Random; // Removed: no longer simulating random outcomes

@MultipartConfig
public class PaymentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("role") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        Integer user_id = (Integer) session.getAttribute("user_id");
        String amountStr = request.getParameter("amount");
        String payment_method = request.getParameter("payment_method");
        String booking_idStr = request.getParameter("booking_id");

        // Fallback for multipart/form-data: read from Parts if regular parameters are null
        if (amountStr == null || payment_method == null || booking_idStr == null) {
            try {
                if (amountStr == null) {
                    Part p = request.getPart("amount");
                    if (p != null) amountStr = new String(p.getInputStream().readAllBytes()).trim();
                }
                if (payment_method == null) {
                    Part p = request.getPart("payment_method");
                    if (p != null) payment_method = new String(p.getInputStream().readAllBytes()).trim();
                }
                if (booking_idStr == null) {
                    Part p = request.getPart("booking_id");
                    if (p != null) booking_idStr = new String(p.getInputStream().readAllBytes()).trim();
                }
            } catch (Exception ignore) { }
        }
        System.out.println("[PaymentServlet] doPost - user_id=" + user_id + ", amount=" + amountStr + ", method=" + payment_method + ", booking_id=" + booking_idStr);

        if (amountStr == null || amountStr.isEmpty() || booking_idStr == null || booking_idStr.isEmpty()) {
            System.out.println("[PaymentServlet] Missing amount or booking_id after multipart fallback - amount=" + amountStr + ", booking_id=" + booking_idStr);
            response.sendRedirect("process_payment.jsp?message=Amount and booking ID are required");
            return;
        }

        double amount = Double.parseDouble(amountStr);
        int booking_id = Integer.parseInt(booking_idStr);

        // Always treat payments as successful (disable random simulation)
        String status = "success";

        try {
            try (Connection conn = DatabaseConnection.getConnection()) {
                // Insert transaction
                PreparedStatement stmt = conn.prepareStatement("INSERT INTO Transactions (user_id, amount, payment_method, status, booking_id) VALUES (?, ?, ?, ?, ?)");
                stmt.setInt(1, user_id);
                stmt.setDouble(2, amount);
                stmt.setString(3, payment_method);
                stmt.setString(4, status);
                stmt.setInt(5, booking_id);
                stmt.executeUpdate();

                // Get transaction_id
                int transaction_id = 0;
                PreparedStatement idStmt = conn.prepareStatement("SELECT SCOPE_IDENTITY() AS id");
                ResultSet idRs = idStmt.executeQuery();
                if (idRs.next()) {
                    transaction_id = idRs.getInt("id");
                }
                System.out.println("[PaymentServlet] Transaction inserted, id=" + transaction_id + ", status=" + status);

                if ("success".equals(status)) {
                    // Update booking status to 'paid'
                    PreparedStatement updateBooking = conn.prepareStatement("UPDATE Bookings SET status = 'paid' WHERE id = ? AND user_id = ?");
                    updateBooking.setInt(1, booking_id);
                    updateBooking.setInt(2, user_id); // Security: only user's booking
                    int updated = updateBooking.executeUpdate();
                    if (updated > 0) {
                        System.out.println("[PaymentServlet] Booking marked paid, booking_id=" + booking_id);
                        
                        // Notify observers about the payment confirmation using user-specific data
                        DynamicObserverManager.getInstance().notifyUserPaymentConfirmed(user_id, booking_id, amount);
                        
                        response.sendRedirect(request.getContextPath() + "/ticket.jsp?booking_id=" + booking_id + "&message=Payment successful");
                    } else {
                        System.out.println("[PaymentServlet] Booking not found for user_id=" + user_id + ", booking_id=" + booking_id);
                        response.sendRedirect("process_payment.jsp?message=Booking not found");
                    }
                } else {
                    // If failed, add log
                    PreparedStatement logStmt = conn.prepareStatement("INSERT INTO PaymentLogs (transaction_id, log_message) VALUES (?, ?)");
                    logStmt.setInt(1, transaction_id);
                    logStmt.setString(2, "Payment failed for amount " + amount + " (Booking ID: " + booking_id + ")");
                    logStmt.executeUpdate();
                    System.out.println("[PaymentServlet] Payment failure logged for transaction_id=" + transaction_id);
                    response.sendRedirect("process_payment.jsp?message=Payment processed: " + status);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("[PaymentServlet] Error processing payment: " + e.getMessage());
            response.sendRedirect("process_payment.jsp?message=Error processing payment: " + e.getMessage());
        }
    }
}