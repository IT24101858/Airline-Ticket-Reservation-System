package com.example.servlets;  // ඔබගේ package name (ඔබේ project අනුව adjust කරන්න)

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.example.util.DatabaseConnection;

@WebServlet("/cancel_flight")
public class CancelFlightServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String flightIdStr = request.getParameter("flight_id");
        if (flightIdStr == null || flightIdStr.trim().isEmpty()) {
            response.sendRedirect("cancel_flight.jsp?message=" + java.net.URLEncoder.encode("Missing flight id", "UTF-8"));
            return;
        }

        int flightId = Integer.parseInt(flightIdStr);

        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // 1) Find bookings for this flight
            try (PreparedStatement psBookings = conn.prepareStatement("SELECT id FROM Bookings WHERE flight_id = ?")) {
                psBookings.setInt(1, flightId);
                try (ResultSet rs = psBookings.executeQuery()) {
                    // For each booking, delete dependent transactions and payment logs
                    while (rs.next()) {
                        int bookingId = rs.getInt("id");

                        // Delete PaymentLogs -> Transactions for this booking
                        try (PreparedStatement psTxnForBooking = conn.prepareStatement("SELECT id FROM Transactions WHERE booking_id = ?")) {
                            psTxnForBooking.setInt(1, bookingId);
                            try (ResultSet rsTxn = psTxnForBooking.executeQuery()) {
                                while (rsTxn.next()) {
                                    int txnId = rsTxn.getInt("id");
                                    try (PreparedStatement psDelLogs = conn.prepareStatement("DELETE FROM PaymentLogs WHERE transaction_id = ?")) {
                                        psDelLogs.setInt(1, txnId);
                                        psDelLogs.executeUpdate();
                                    }
                                }
                            }
                        }
                        try (PreparedStatement psDelTxns = conn.prepareStatement("DELETE FROM Transactions WHERE booking_id = ?")) {
                            psDelTxns.setInt(1, bookingId);
                            psDelTxns.executeUpdate();
                        }
                    }
                }
            }

            // 2) Delete bookings for this flight
            try (PreparedStatement psDelBookings = conn.prepareStatement("DELETE FROM Bookings WHERE flight_id = ?")) {
                psDelBookings.setInt(1, flightId);
                psDelBookings.executeUpdate();
            }

            // 3) Finally delete the flight
            int rowsAffected = 0;
            try (PreparedStatement psDelFlight = conn.prepareStatement("DELETE FROM Flights WHERE id = ?")) {
                psDelFlight.setInt(1, flightId);
                rowsAffected = psDelFlight.executeUpdate();
            }

            conn.commit();

            String message = (rowsAffected > 0) ? "Flight cancelled successfully" : "Flight not found";
            // Redirect back to scheduler dashboard for better UX (context-aware)
            response.sendRedirect(request.getContextPath() + "/scheduler_dashboard.jsp?message=" + java.net.URLEncoder.encode(message, "UTF-8"));
        } catch (Exception e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignore) {}
            }
            String error = "Error cancelling flight: " + e.getMessage();
            response.sendRedirect(request.getContextPath() + "/cancel_flight.jsp?message=" + java.net.URLEncoder.encode(error, "UTF-8"));
        } finally {
            if (ps != null) try { ps.close(); } catch (SQLException ignored) {}
            if (conn != null) try { conn.setAutoCommit(true); conn.close(); } catch (SQLException ignored) {}
        }
    }
}