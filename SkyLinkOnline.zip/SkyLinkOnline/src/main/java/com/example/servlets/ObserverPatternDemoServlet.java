package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import com.example.util.FlightBookingSubject;
import com.example.util.EmailNotificationObserver;
import com.example.util.SMSNotificationObserver;
import com.example.util.LoggingObserver;

/**
 * ObserverPatternDemoServlet demonstrates the Observer Pattern implementation
 * This servlet shows how observers are registered and how notifications work
 */
@WebServlet("/observerDemo")
public class ObserverPatternDemoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Observer Pattern Demo - SkyLink Airlines</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }");
        out.println(".container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }");
        out.println(".demo-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }");
        out.println(".success { background-color: #d4edda; border-color: #c3e6cb; }");
        out.println(".info { background-color: #d1ecf1; border-color: #bee5eb; }");
        out.println("pre { background-color: #f8f9fa; padding: 10px; border-radius: 5px; overflow-x: auto; }");
        out.println("h1 { color: #333; text-align: center; }");
        out.println("h2 { color: #666; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<h1>🛫 Observer Pattern Demo - SkyLink Airlines</h1>");
        
        // Get the singleton instance
        FlightBookingSubject subject = FlightBookingSubject.getInstance();
        
        out.println("<div class='demo-section info'>");
        out.println("<h2>📋 Observer Pattern Explanation</h2>");
        out.println("<p><strong>Observer Pattern</strong> allows objects to notify multiple other objects about changes in their state.</p>");
        out.println("<p>In our flight booking system:</p>");
        out.println("<ul>");
        out.println("<li><strong>Subject:</strong> FlightBookingSubject (manages observers and sends notifications)</li>");
        out.println("<li><strong>Observers:</strong> EmailNotificationObserver, SMSNotificationObserver, LoggingObserver</li>");
        out.println("<li><strong>Events:</strong> Flight booking, cancellation, rescheduling, payment confirmation</li>");
        out.println("</ul>");
        out.println("</div>");
        
        // Register observers
        out.println("<div class='demo-section'>");
        out.println("<h2>🔧 Registering Observers</h2>");
        
        EmailNotificationObserver emailObserver = new EmailNotificationObserver("customer@example.com");
        SMSNotificationObserver smsObserver = new SMSNotificationObserver("+1234567890");
        LoggingObserver loggingObserver = new LoggingObserver("INFO");
        
        subject.addObserver(emailObserver);
        subject.addObserver(smsObserver);
        subject.addObserver(loggingObserver);
        
        out.println("<p>✅ Registered " + subject.getObserverCount() + " observers:</p>");
        out.println("<ul>");
        out.println("<li>📧 Email Notification Observer (customer@example.com)</li>");
        out.println("<li>📱 SMS Notification Observer (+1234567890)</li>");
        out.println("<li>📝 Logging Observer (INFO level)</li>");
        out.println("</ul>");
        out.println("</div>");
        
        // Simulate flight booking
        out.println("<div class='demo-section success'>");
        out.println("<h2>✈️ Simulating Flight Booking Event</h2>");
        out.println("<p>Triggering flight booking notification...</p>");
        out.println("<pre>");
        
        // Capture console output
        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        java.io.PrintStream originalOut = System.out;
        System.setOut(new java.io.PrintStream(baos));
        
        // Trigger the notification
        subject.notifyFlightBooked(123, 456, 2, 299.99);
        
        // Restore original output
        System.setOut(originalOut);
        
        // Display the captured output
        out.println(baos.toString());
        out.println("</pre>");
        out.println("</div>");
        
        // Simulate payment confirmation
        out.println("<div class='demo-section success'>");
        out.println("<h2>💳 Simulating Payment Confirmation Event</h2>");
        out.println("<p>Triggering payment confirmation notification...</p>");
        out.println("<pre>");
        
        // Capture console output again
        baos.reset();
        System.setOut(new java.io.PrintStream(baos));
        
        // Trigger the notification
        subject.notifyPaymentConfirmed(123, 789, 299.99);
        
        // Restore original output
        System.setOut(originalOut);
        
        // Display the captured output
        out.println(baos.toString());
        out.println("</pre>");
        out.println("</div>");
        
        // Simulate flight cancellation
        out.println("<div class='demo-section success'>");
        out.println("<h2>❌ Simulating Flight Cancellation Event</h2>");
        out.println("<p>Triggering flight cancellation notification...</p>");
        out.println("<pre>");
        
        // Capture console output again
        baos.reset();
        System.setOut(new java.io.PrintStream(baos));
        
        // Trigger the notification
        subject.notifyFlightCancelled(123, 456, 2);
        
        // Restore original output
        System.setOut(originalOut);
        
        // Display the captured output
        out.println(baos.toString());
        out.println("</pre>");
        out.println("</div>");
        
        out.println("<div class='demo-section info'>");
        out.println("<h2>🎯 Benefits of Observer Pattern</h2>");
        out.println("<ul>");
        out.println("<li><strong>Loose Coupling:</strong> Subject doesn't need to know about specific observers</li>");
        out.println("<li><strong>Extensibility:</strong> Easy to add new notification types (Push notifications, Slack, etc.)</li>");
        out.println("<li><strong>Reusability:</strong> Observers can be reused in different contexts</li>");
        out.println("<li><strong>Maintainability:</strong> Changes to notification logic don't affect the main booking flow</li>");
        out.println("</ul>");
        out.println("</div>");
        
        out.println("<div class='demo-section'>");
        out.println("<h2>🔗 Integration Points</h2>");
        out.println("<p>The Observer Pattern is integrated into these servlets:</p>");
        out.println("<ul>");
        out.println("<li><strong>BookServlet:</strong> Notifies when flights are booked</li>");
        out.println("<li><strong>CancelBookingServlet:</strong> Notifies when bookings are cancelled</li>");
        out.println("<li><strong>ConfirmPaymentServlet:</strong> Notifies when payments are confirmed</li>");
        out.println("</ul>");
        out.println("<p><a href='index.jsp'>← Back to Home</a></p>");
        out.println("</div>");
        
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}
