package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;

public class TransactionsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null || !"finance_officer".equals(session.getAttribute("role"))) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        System.out.println("[TransactionsServlet] doGet - listing transactions");

        // Get filter parameters
        String statusFilter = request.getParameter("status");
        String methodFilter = request.getParameter("method");
        String dateFrom = request.getParameter("dateFrom");
        String dateTo = request.getParameter("dateTo");
        String searchTerm = request.getParameter("search");
        String sortBy = request.getParameter("sortBy");
        String sortOrder = request.getParameter("sortOrder");

        // Default values
        if (statusFilter == null) statusFilter = "";
        if (methodFilter == null) methodFilter = "";
        if (dateFrom == null) dateFrom = "";
        if (dateTo == null) dateTo = "";
        if (searchTerm == null) searchTerm = "";
        if (sortBy == null) sortBy = "id";
        if (sortOrder == null) sortOrder = "DESC";

        try {
            Connection conn = DatabaseConnection.getConnection();
            
            // Build dynamic query for transactions
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT t.id, t.user_id, t.amount, t.payment_method, t.status, t.booking_id, t.transaction_date, ");
            sql.append("u.username, u.first_name, u.last_name, u.email ");
            sql.append("FROM Transactions t ");
            sql.append("LEFT JOIN Users u ON t.user_id = u.id ");
            sql.append("WHERE 1=1 ");

            if (!statusFilter.isEmpty()) {
                sql.append("AND t.status = ? ");
            }
            if (!methodFilter.isEmpty()) {
                sql.append("AND t.payment_method = ? ");
            }
            if (!dateFrom.isEmpty()) {
                sql.append("AND t.transaction_date >= ? ");
            }
            if (!dateTo.isEmpty()) {
                sql.append("AND t.transaction_date <= ? ");
            }
            if (!searchTerm.isEmpty()) {
                sql.append("AND (u.username LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ? OR t.id LIKE ?) ");
            }

            sql.append("ORDER BY t.").append(sortBy).append(" ").append(sortOrder);

            PreparedStatement ps = conn.prepareStatement(sql.toString());
            
            int paramIndex = 1;
            if (!statusFilter.isEmpty()) {
                ps.setString(paramIndex++, statusFilter);
            }
            if (!methodFilter.isEmpty()) {
                ps.setString(paramIndex++, methodFilter);
            }
            if (!dateFrom.isEmpty()) {
                ps.setString(paramIndex++, dateFrom + " 00:00:00");
            }
            if (!dateTo.isEmpty()) {
                ps.setString(paramIndex++, dateTo + " 23:59:59");
            }
            if (!searchTerm.isEmpty()) {
                String searchPattern = "%" + searchTerm + "%";
                ps.setString(paramIndex++, searchPattern);
                ps.setString(paramIndex++, searchPattern);
                ps.setString(paramIndex++, searchPattern);
                ps.setString(paramIndex++, searchPattern);
                ps.setString(paramIndex++, searchPattern);
            }

            ResultSet rs = ps.executeQuery();
            request.setAttribute("transactions_rs", rs);
            
            // Get statistics data
            PreparedStatement statsPs = conn.prepareStatement(
                "SELECT " +
                "COUNT(*) as total, " +
                "SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success_count, " +
                "SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count, " +
                "SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_count, " +
                "SUM(CASE WHEN status = 'refunded' THEN 1 ELSE 0 END) as refunded_count " +
                "FROM Transactions"
            );
            ResultSet statsRs = statsPs.executeQuery();
            
            if (statsRs.next()) {
                request.setAttribute("total_transactions", statsRs.getInt("total"));
                request.setAttribute("success_count", statsRs.getInt("success_count"));
                request.setAttribute("pending_count", statsRs.getInt("pending_count"));
                request.setAttribute("failed_count", statsRs.getInt("failed_count"));
                request.setAttribute("refunded_count", statsRs.getInt("refunded_count"));
            }
            
            // Set filter parameters for JSP
            request.setAttribute("statusFilter", statusFilter);
            request.setAttribute("methodFilter", methodFilter);
            request.setAttribute("dateFrom", dateFrom);
            request.setAttribute("dateTo", dateTo);
            request.setAttribute("searchTerm", searchTerm);
            request.setAttribute("sortBy", sortBy);
            request.setAttribute("sortOrder", sortOrder);
            
            request.getRequestDispatcher("transactions.jsp").forward(request, response);
            // Note: rs/ps/conn closed by container when request ends if using forward with streaming ResultSet; for safety, a DAO would buffer. Keeping simple for now.
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("[TransactionsServlet] Error loading transactions: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/failed_alerts.jsp?message=Error loading transactions");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null || !"finance_officer".equals(session.getAttribute("role"))) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        final String action = request.getParameter("action");
        System.out.println("[TransactionsServlet] doPost - action=" + action);

        try (Connection conn = DatabaseConnection.getConnection()) {
            if ("create".equals(action)) {
                String userIdStr = request.getParameter("user_id");
                String amountStr = request.getParameter("amount");
                String bookingIdStr = request.getParameter("booking_id");
                String method = request.getParameter("payment_method");
                String status = request.getParameter("status");

                if (userIdStr == null || amountStr == null || bookingIdStr == null || method == null || userIdStr.isEmpty() || amountStr.isEmpty() || bookingIdStr.isEmpty() || method.isEmpty()) {
                    response.sendRedirect("transactions.jsp?message=Missing required fields");
                    return;
                }

                int userId = Integer.parseInt(userIdStr);
                double amount = Double.parseDouble(amountStr);
                int bookingId = Integer.parseInt(bookingIdStr);
                if (status == null || status.isEmpty()) status = "pending";

                try (PreparedStatement ps = conn.prepareStatement("INSERT INTO Transactions (user_id, amount, payment_method, status, booking_id) VALUES (?,?,?,?,?)")) {
                    ps.setInt(1, userId);
                    ps.setDouble(2, amount);
                    ps.setString(3, method);
                    ps.setString(4, status);
                    ps.setInt(5, bookingId);
                    ps.executeUpdate();
                }
                System.out.println("[TransactionsServlet] Created transaction for booking_id=" + bookingId);
                response.sendRedirect("transactions");
                return;

            } else if ("update".equals(action)) {
                String idStr = request.getParameter("id");
                String amountStr = request.getParameter("amount");
                String method = request.getParameter("payment_method");
                String status = request.getParameter("status");
                if (idStr == null || idStr.isEmpty()) {
                    response.sendRedirect("transactions.jsp?message=Missing transaction id");
                    return;
                }
                int id = Integer.parseInt(idStr);

                try (PreparedStatement ps = conn.prepareStatement("UPDATE Transactions SET amount = COALESCE(?, amount), payment_method = COALESCE(?, payment_method), status = COALESCE(?, status) WHERE id = ?")) {
                    if (amountStr == null || amountStr.isEmpty()) ps.setNull(1, java.sql.Types.DECIMAL); else ps.setDouble(1, Double.parseDouble(amountStr));
                    if (method == null || method.isEmpty()) ps.setNull(2, java.sql.Types.VARCHAR); else ps.setString(2, method);
                    if (status == null || status.isEmpty()) ps.setNull(3, java.sql.Types.VARCHAR); else ps.setString(3, status);
                    ps.setInt(4, id);
                    ps.executeUpdate();
                }
                System.out.println("[TransactionsServlet] Updated transaction id=" + id);
                response.sendRedirect("transactions");
                return;

            } else if ("delete".equals(action)) {
                String idStr = request.getParameter("id");
                if (idStr == null || idStr.isEmpty()) {
                    response.sendRedirect("transactions.jsp?message=Missing transaction id");
                    return;
                }
                int id = Integer.parseInt(idStr);
                try (PreparedStatement ps = conn.prepareStatement("DELETE FROM Transactions WHERE id = ?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
                System.out.println("[TransactionsServlet] Deleted transaction id=" + id);
                response.sendRedirect("transactions");
                return;

            } else if ("refund".equals(action)) {
                String idStr = request.getParameter("id");
                if (idStr == null || idStr.isEmpty()) {
                    response.sendRedirect("transactions.jsp?message=Missing transaction id");
                    return;
                }
                int id = Integer.parseInt(idStr);
                try (PreparedStatement ps = conn.prepareStatement("UPDATE Transactions SET status = 'refunded' WHERE id = ?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps2 = conn.prepareStatement("UPDATE Bookings SET status = 'refunded' WHERE id = (SELECT booking_id FROM Transactions WHERE id = ?)")) {
                    ps2.setInt(1, id);
                    ps2.executeUpdate();
                } catch (SQLException ignore) {}
                System.out.println("[TransactionsServlet] Refunded transaction id=" + id);
                response.sendRedirect("transactions");
                return;
            }

            response.sendRedirect("transactions.jsp?message=Unknown action");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("transactions.jsp?message=Database error: " + e.getMessage());
        }
    }
}


