package com.example.servlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import com.example.util.DatabaseConnection;

public class SearchServlet extends HttpServlet {

    //Getting Search Details
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String departure_airport = request.getParameter("departure_airport");
        String arrival_airport = request.getParameter("arrival_airport");
        String departure_date = request.getParameter("departure_date");
        String flight_class = request.getParameter("flight_class");
        String passengersStr = request.getParameter("passengers");
        System.out.println("[SearchServlet] doGet - from=" + departure_airport + ", to=" + arrival_airport + ", date=" + departure_date + ", class=" + flight_class + ", passengers=" + passengersStr);

        //search data Validation

        if (departure_airport == null || arrival_airport == null || departure_date == null || flight_class == null || passengersStr == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        // Validate departure date - must be today or future
        try {
            LocalDate searchDate = LocalDate.parse(departure_date);
            LocalDate today = LocalDate.now();
            
            if (searchDate.isBefore(today)) {
                System.out.println("[SearchServlet] Invalid date - past date selected: " + departure_date);
                response.sendRedirect("index.jsp?message=Please select a date from today onwards");
                return;
            }
        } catch (DateTimeParseException e) {
            System.out.println("[SearchServlet] Invalid date format: " + departure_date);
            response.sendRedirect("index.jsp?message=Invalid date format");
            return;
        }

        int passengers = Integer.parseInt(passengersStr);

        //search with database

        try {
            try (Connection conn = DatabaseConnection.getConnection()) {
                // Updated query to only show flights from today onwards
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Flights WHERE departure_airport = ? AND arrival_airport = ? AND departure_date = ? AND flight_class = ? AND available_seats >= ? AND departure_date >= CAST(GETDATE() AS DATE)");
                stmt.setString(1, departure_airport);
                stmt.setString(2, arrival_airport);
                stmt.setDate(3, java.sql.Date.valueOf(departure_date));
                stmt.setString(4, flight_class);
                stmt.setInt(5, passengers);
                ResultSet rs = stmt.executeQuery();
                System.out.println("[SearchServlet] Query executed - forwarding results to results.jsp");

                //Results Forward

                request.setAttribute("results", rs);
                RequestDispatcher dispatcher = request.getRequestDispatcher("results.jsp");
                dispatcher.forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("index.jsp?message=Error searching flights");
        }
    }
}