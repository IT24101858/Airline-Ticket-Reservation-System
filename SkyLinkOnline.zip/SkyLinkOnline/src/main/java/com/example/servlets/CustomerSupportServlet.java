package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;

public class CustomerSupportServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("username") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String senderUsername = (String) session.getAttribute("username");
        String senderEmail = (String) session.getAttribute("email");
        String subject = request.getParameter("subject");
        String message = request.getParameter("message");
        if ((subject == null || subject.isEmpty()) && request.getParameter("message") != null && !request.getParameter("message").isEmpty()) {
            // Fallback for existing supportForm.jsp which only sends message
            subject = "General Inquiry";
        }

        if (message == null || message.isEmpty()) {
            response.sendRedirect("supportForm.jsp?error=1");
            return;
        }

        try {
            try (Connection conn = DatabaseConnection.getConnection()) {
                String name = senderUsername != null ? senderUsername : request.getParameter("customer_name");
                String email = senderEmail != null ? senderEmail : request.getParameter("customer_email");
                String body = (subject != null && !subject.isEmpty()) ? ("[" + subject + "] " + message) : message;
                PreparedStatement stmt = conn.prepareStatement(
                        "INSERT INTO CustomerQueries (customer_name, customer_email, query_message, query_status) VALUES (?, ?, ?, 'Open')");
                stmt.setString(1, name);
                stmt.setString(2, email != null ? email : "unknown@example.com");
                stmt.setString(3, body);
                stmt.executeUpdate();
            }
            response.sendRedirect("supportForm.jsp?success=1");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("supportForm.jsp?error=1");
        }
    }
}


