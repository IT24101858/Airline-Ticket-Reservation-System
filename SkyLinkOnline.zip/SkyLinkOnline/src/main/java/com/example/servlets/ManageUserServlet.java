package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;

public class ManageUserServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("username") == null || !"it_admin".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        int id = Integer.parseInt(request.getParameter("id"));
        System.out.println("[ManageUserServlet] doGet - action=" + action + ", id=" + id);

        if ("delete".equals(action)) {
            try {
                Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement("DELETE FROM Users WHERE id = ?");
                stmt.setInt(1, id);
                stmt.executeUpdate();
                conn.close();
                response.sendRedirect("manage_users.jsp");
            } catch (SQLException e) {
                System.out.println("[ManageUserServlet] Error deleting user id=" + id + ": " + e.getMessage());
                response.sendRedirect("manage_users.jsp?message=Error deleting user: " + e.getMessage());
            }
        } else if ("edit".equals(action)) {
            try {
                Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Users WHERE id = ?");
                stmt.setInt(1, id);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String username = rs.getString("username");
                    String first_name = rs.getString("first_name");
                    String last_name = rs.getString("last_name");
                    String email = rs.getString("email");
                    String role = rs.getString("role");
                    rs.close();
                    stmt.close();
                    conn.close();
                    // Redirect with parameters to edit_user.jsp
                    System.out.println("[ManageUserServlet] Forwarding to edit_user.jsp for id=" + id);
                    response.sendRedirect("edit_user.jsp?id=" + id + "&username=" + username + "&first_name=" + first_name +
                            "&last_name=" + last_name + "&email=" + email + "&role=" + role);
                }
            } catch (SQLException e) {
                System.out.println("[ManageUserServlet] Error fetching user id=" + id + ": " + e.getMessage());
                response.sendRedirect("manage_users.jsp?message=Error fetching user: " + e.getMessage());
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("username") == null || !"it_admin".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        System.out.println("[ManageUserServlet] doPost - action=" + action);

        if ("add".equals(action)) {
            // Handle adding new user
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String first_name = request.getParameter("first_name");
            String last_name = request.getParameter("last_name");
            String email = request.getParameter("email");
            String phone_number = request.getParameter("phone_number");
            String role = request.getParameter("role");
            
            System.out.println("[ManageUserServlet] Adding new user - username=" + username + ", email=" + email);

            // Validate required fields
            if (username == null || password == null || first_name == null || last_name == null || 
                email == null || phone_number == null || role == null ||
                username.isEmpty() || password.isEmpty() || first_name.isEmpty() || 
                last_name.isEmpty() || email.isEmpty() || phone_number.isEmpty() || role.isEmpty()) {
                response.sendRedirect("manage_users.jsp?message=Please fill all required fields");
                return;
            }

            // Basic email format check
            if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
                response.sendRedirect("manage_users.jsp?message=Invalid email format");
                return;
            }

            try {
                Connection conn = DatabaseConnection.getConnection();
                
                // Check for duplicate username
                PreparedStatement usernameCheck = conn.prepareStatement("SELECT COUNT(*) FROM Users WHERE username = ?");
                usernameCheck.setString(1, username);
                ResultSet usernameRs = usernameCheck.executeQuery();
                usernameRs.next();
                if (usernameRs.getInt(1) > 0) {
                    usernameRs.close();
                    usernameCheck.close();
                    conn.close();
                    response.sendRedirect("manage_users.jsp?message=Username already exists");
                    return;
                }
                usernameRs.close();
                usernameCheck.close();

                // Check for duplicate email
                PreparedStatement emailCheck = conn.prepareStatement("SELECT COUNT(*) FROM Users WHERE email = ?");
                emailCheck.setString(1, email);
                ResultSet emailRs = emailCheck.executeQuery();
                emailRs.next();
                if (emailRs.getInt(1) > 0) {
                    emailRs.close();
                    emailCheck.close();
                    conn.close();
                    response.sendRedirect("manage_users.jsp?message=Email already exists");
                    return;
                }
                emailRs.close();
                emailCheck.close();

                // Insert new user (without passport_number as requested)
                PreparedStatement stmt = conn.prepareStatement(
                        "INSERT INTO Users (username, password, first_name, last_name, email, phone_number, role) VALUES (?, ?, ?, ?, ?, ?, ?)");
                stmt.setString(1, username);
                stmt.setString(2, password); // Future: hash password
                stmt.setString(3, first_name);
                stmt.setString(4, last_name);
                stmt.setString(5, email);
                stmt.setString(6, phone_number);
                stmt.setString(7, role);
                stmt.executeUpdate();
                conn.close();
                
                System.out.println("[ManageUserServlet] User added successfully - username=" + username);
                response.sendRedirect("manage_users.jsp?message=User added successfully");
            } catch (SQLException e) {
                System.out.println("[ManageUserServlet] Error adding user: " + e.getMessage());
                response.sendRedirect("manage_users.jsp?message=Error adding user: " + e.getMessage());
            }
        } else if ("update".equals(action)) {
            // Handle updating existing user
            int id = Integer.parseInt(request.getParameter("id"));
            String username = request.getParameter("username");
            String first_name = request.getParameter("first_name");
            String last_name = request.getParameter("last_name");
            String email = request.getParameter("email");
            String role = request.getParameter("role");
            
            System.out.println("[ManageUserServlet] Updating user - id=" + id + ", username=" + username);

            try {
                Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE Users SET username = ?, first_name = ?, last_name = ?, email = ?, role = ? WHERE id = ?");
                stmt.setString(1, username);
                stmt.setString(2, first_name);
                stmt.setString(3, last_name);
                stmt.setString(4, email);
                stmt.setString(5, role);
                stmt.setInt(6, id);
                stmt.executeUpdate();
                conn.close();
                response.sendRedirect("manage_users.jsp?message=User updated successfully");
            } catch (SQLException e) {
                System.out.println("[ManageUserServlet] Error updating user id=" + id + ": " + e.getMessage());
                response.sendRedirect("manage_users.jsp?message=Error updating user: " + e.getMessage());
            }
        }
    }
}