package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;

public class RestoreFlightAvailabilityServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (!"flight_scheduler".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String flight_idStr = request.getParameter("flight_id");
        System.out.println("[RestoreFlightAvailabilityServlet] doPost - id=" + flight_idStr);

        if (flight_idStr == null || flight_idStr.isEmpty()) {
            response.sendRedirect("scheduler_dashboard.jsp?message=Please provide a flight ID");
            return;
        }

        int flight_id = Integer.parseInt(flight_idStr);

        try {
            try (Connection conn = DatabaseConnection.getConnection()) {
                // First, get the max passengers for this flight
                PreparedStatement getStmt = conn.prepareStatement("SELECT passengers FROM Flights WHERE id = ?");
                getStmt.setInt(1, flight_id);
                ResultSet rs = getStmt.executeQuery();
                
                if (rs.next()) {
                    int maxPassengers = rs.getInt("passengers");
                    
                    // Update available seats to match max passengers (restore full availability)
                    PreparedStatement updateStmt = conn.prepareStatement("UPDATE Flights SET available_seats = ? WHERE id = ?");
                    updateStmt.setInt(1, maxPassengers);
                    updateStmt.setInt(2, flight_id);
                    int updated = updateStmt.executeUpdate();
                    
                    if (updated > 0) {
                        System.out.println("[RestoreFlightAvailabilityServlet] Flight availability restored successfully for id=" + flight_id + ", seats=" + maxPassengers);
                        response.sendRedirect("scheduler_dashboard.jsp?message=Flight availability restored successfully - Flight ID " + flight_id + " is now bookable with " + maxPassengers + " available seats");
                    } else {
                        System.out.println("[RestoreFlightAvailabilityServlet] Flight not found for id=" + flight_id);
                        response.sendRedirect("scheduler_dashboard.jsp?message=Flight not found with ID " + flight_id);
                    }
                } else {
                    System.out.println("[RestoreFlightAvailabilityServlet] Flight not found for id=" + flight_id);
                    response.sendRedirect("scheduler_dashboard.jsp?message=Flight not found with ID " + flight_id);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("[RestoreFlightAvailabilityServlet] Error restoring flight availability: " + e.getMessage());
            response.sendRedirect("scheduler_dashboard.jsp?message=Error restoring flight availability");
        } catch (NumberFormatException e) {
            e.printStackTrace();
            System.out.println("[RestoreFlightAvailabilityServlet] Invalid flight ID format: " + flight_idStr);
            response.sendRedirect("scheduler_dashboard.jsp?message=Invalid flight ID format");
        }
    }
}
