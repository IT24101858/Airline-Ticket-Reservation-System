package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;

public class UpdateSeatsServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (!"flight_scheduler".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String flight_idStr = request.getParameter("flight_id");
        String new_available_seatsStr = request.getParameter("new_available_seats");
        System.out.println("[UpdateSeatsServlet] doPost - id=" + flight_idStr + ", new_seats=" + new_available_seatsStr);

        if (flight_idStr == null || new_available_seatsStr == null || flight_idStr.isEmpty() || new_available_seatsStr.isEmpty()) {
            response.sendRedirect("update_seats.jsp?message=Please fill all fields");
            return;
        }

        int flight_id = Integer.parseInt(flight_idStr);
        int new_available_seats = Integer.parseInt(new_available_seatsStr);

        try {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("UPDATE Flights SET available_seats = ? WHERE id = ?")) {
                stmt.setInt(1, new_available_seats);
                stmt.setInt(2, flight_id);
                int updated = stmt.executeUpdate();
                if (updated > 0) {
                    System.out.println("[UpdateSeatsServlet] Seats updated successfully for id=" + flight_id);
                    response.sendRedirect("scheduler_dashboard.jsp?message=Seats updated successfully");
                } else {
                    System.out.println("[UpdateSeatsServlet] Flight not found for id=" + flight_id);
                    response.sendRedirect("update_seats.jsp?message=Flight not found");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("[UpdateSeatsServlet] Error updating seats: " + e.getMessage());
            response.sendRedirect("update_seats.jsp?message=Error updating seats");
        }
    }
}