package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import com.example.util.DatabaseConnection;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class RescheduleFlightServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (!"flight_scheduler".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String flight_idStr = request.getParameter("flight_id");
        String new_departure_date = request.getParameter("new_departure_date");
        System.out.println("[RescheduleFlightServlet] doPost - id=" + flight_idStr + ", new_date=" + new_departure_date);

        if (flight_idStr == null || new_departure_date == null || flight_idStr.isEmpty() || new_departure_date.isEmpty()) {
            response.sendRedirect("reschedule_flight.jsp?message=Please fill all fields");
            return;
        }

        int flight_id = Integer.parseInt(flight_idStr);

        try {
            // Parse the date string and convert to datetime (assuming time is 00:00:00)
            LocalDate date = LocalDate.parse(new_departure_date);
            LocalDateTime departureDateTime = LocalDateTime.of(date, LocalTime.MIDNIGHT);
            Timestamp departureTimestamp = Timestamp.valueOf(departureDateTime);
            
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("UPDATE Flights SET departure_date = ? WHERE id = ?")) {
                stmt.setTimestamp(1, departureTimestamp);
                stmt.setInt(2, flight_id);
                int updated = stmt.executeUpdate();
                if (updated > 0) {
                    System.out.println("[RescheduleFlightServlet] Flight rescheduled successfully, id=" + flight_id);
                    response.sendRedirect("scheduler_dashboard.jsp?message=Flight rescheduled successfully");
                } else {
                    System.out.println("[RescheduleFlightServlet] Flight not found, id=" + flight_id);
                    response.sendRedirect("reschedule_flight.jsp?message=Flight not found");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("[RescheduleFlightServlet] Error rescheduling flight: " + e.getMessage());
            response.sendRedirect("reschedule_flight.jsp?message=Error rescheduling flight");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("[RescheduleFlightServlet] Error parsing date: " + e.getMessage());
            response.sendRedirect("reschedule_flight.jsp?message=Invalid date format");
        }
    }
}