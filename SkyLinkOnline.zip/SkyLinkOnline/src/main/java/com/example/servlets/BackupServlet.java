package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import com.example.util.DatabaseConnection;

public class BackupServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("username") == null || !"it_admin".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String backup_date = request.getParameter("backup_date") + " " + request.getParameter("backup_time") + ":00";
        Timestamp schedule_time = Timestamp.valueOf(backup_date);
        System.out.println("[BackupServlet] doPost - scheduling backup at " + backup_date);

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO BackupLogs (schedule_time, status) VALUES (?, ?)");
            stmt.setTimestamp(1, schedule_time);
            stmt.setString(2, "Scheduled");
            stmt.executeUpdate();
            conn.close();
            response.sendRedirect("schedule_backups.jsp?message=Backup scheduled successfully at " + backup_date);
        } catch (SQLException e) {
            System.out.println("[BackupServlet] Error scheduling backup: " + e.getMessage());
            response.sendRedirect("schedule_backups.jsp?message=Error scheduling backup: " + e.getMessage());
        }
    }
}