package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.*;
import com.example.util.DatabaseConnection;

@WebServlet("/createTransaction")
public class CreateTransactionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form data from the request
        String userIdStr = request.getParameter("user_id");
        String amountStr = request.getParameter("amount");
        String bookingIdStr = request.getParameter("booking_id");
        System.out.println("[CreateTransactionServlet] doPost - user_id=" + userIdStr + ", amount=" + amountStr + ", booking_id=" + bookingIdStr);

        if (userIdStr == null || amountStr == null || bookingIdStr == null) {
            response.sendRedirect(request.getContextPath() + "/failed_alerts.jsp?message=Missing transaction details");
            return;
        }

        int userId = Integer.parseInt(userIdStr);
        double amount = Double.parseDouble(amountStr);
        int bookingId = Integer.parseInt(bookingIdStr);

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();

            // Insert new transaction for bank payment (status: pending)
            String insertQuery = "INSERT INTO Transactions (user_id, amount, payment_method, status, booking_id) " +
                    "VALUES (?, ?, 'Bank Transfer', 'pending', ?)";
            stmt = conn.prepareStatement(insertQuery);
            stmt.setInt(1, userId);
            stmt.setDouble(2, amount);
            stmt.setInt(3, bookingId);

            int rowsInserted = stmt.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("[CreateTransactionServlet] Transaction created successfully");
                response.sendRedirect(request.getContextPath() + "/successful_alerts.jsp?message=Transaction created successfully");
            } else {
                System.out.println("[CreateTransactionServlet] Failed to create transaction");
                response.sendRedirect(request.getContextPath() + "/failed_alerts.jsp?message=Failed to create transaction");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("[CreateTransactionServlet] Error creating transaction: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/failed_alerts.jsp?message=Error creating transaction");
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ignored) {}
        }
    }
}
