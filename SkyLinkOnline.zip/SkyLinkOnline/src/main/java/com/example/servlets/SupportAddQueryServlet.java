package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;

public class SupportAddQueryServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (!"support_officer".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String customerName = request.getParameter("customer_name");
        String customerEmail = request.getParameter("customer_email");
        String message = request.getParameter("message");

        if (customerName == null || customerName.isEmpty() || message == null || message.isEmpty()) {
            response.sendRedirect("support_add_query.jsp?error=1");
            return;
        }

        try {
            try (Connection conn = DatabaseConnection.getConnection()) {
                PreparedStatement stmt = conn.prepareStatement(
                        "INSERT INTO CustomerQueries (customer_name, customer_email, query_message, query_status, officer_id) VALUES (?, ?, ?, 'Open', ?)");
                stmt.setString(1, customerName);
                stmt.setString(2, customerEmail != null ? customerEmail : "");
                stmt.setString(3, message);
                stmt.setString(4, (String) session.getAttribute("username"));
                stmt.executeUpdate();
            }
            response.sendRedirect("CustomerSupportDashboard.jsp?success=1");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("support_add_query.jsp?error=1");
        }
    }
}


