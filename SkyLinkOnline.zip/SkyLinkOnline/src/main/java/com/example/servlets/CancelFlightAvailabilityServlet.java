package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;

public class CancelFlightAvailabilityServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (!"flight_scheduler".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String flight_idStr = request.getParameter("flight_id");
        System.out.println("[CancelFlightAvailabilityServlet] doPost - id=" + flight_idStr);

        if (flight_idStr == null || flight_idStr.isEmpty()) {
            response.sendRedirect("update_seats.jsp?message=Please provide a flight ID");
            return;
        }

        int flight_id = Integer.parseInt(flight_idStr);

        try {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("UPDATE Flights SET available_seats = 0 WHERE id = ?")) {
                
                stmt.setInt(1, flight_id);
                int updated = stmt.executeUpdate();
                
                if (updated > 0) {
                    System.out.println("[CancelFlightAvailabilityServlet] Flight availability cancelled successfully for id=" + flight_id);
                    response.sendRedirect("scheduler_dashboard.jsp?message=Flight availability cancelled successfully - Flight ID " + flight_id + " is now hidden from bookings");
                } else {
                    System.out.println("[CancelFlightAvailabilityServlet] Flight not found for id=" + flight_id);
                    response.sendRedirect("update_seats.jsp?message=Flight not found with ID " + flight_id);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("[CancelFlightAvailabilityServlet] Error cancelling flight availability: " + e.getMessage());
            response.sendRedirect("update_seats.jsp?message=Error cancelling flight availability");
        } catch (NumberFormatException e) {
            e.printStackTrace();
            System.out.println("[CancelFlightAvailabilityServlet] Invalid flight ID format: " + flight_idStr);
            response.sendRedirect("update_seats.jsp?message=Invalid flight ID format");
        }
    }
}
