package com.example.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.example.util.DatabaseConnection;

@WebServlet("/SalesServlet")
public class SalesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);

        // Check authentication
        if (session == null || !"Sales_Manager".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp?redirect=sales-dashboard.jsp");
            return;
        }

        String action = request.getParameter("action");
        System.out.println("SalesServlet - Action: " + action);

        if (action == null) {
            loadDashboardData(request, session);
            request.getRequestDispatcher("sales-dashboard.jsp").forward(request, response);
            return;
        }

        switch (action) {
            case "viewBookings":
                viewBookings(request, response);
                break;
            case "viewFlights":
                viewFlights(request, response);
                break;
            case "getFlightStats":
                getFlightStats(request, response);
                break;
            case "getReportData":
                getReportData(request, response, session);
                break;
            case "getMonthlyReports":
                getMonthlyReports(request, response, session);
                break;
            case "getRouteTrends":
                getRouteTrends(request, response, session);
                break;
            case "deleteReport":
                deleteReport(request, response, session);
                break;
            case "testConnection":
                testConnection(response);
                break;
            case "generatePdf":
                generatePdfReport(request, response, session);
                break;
            default:
                loadDashboardData(request, session);
                request.getRequestDispatcher("sales-dashboard.jsp").forward(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);

        if (session == null || !"Sales_Manager".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String username = (String) session.getAttribute("username");
        String action = request.getParameter("action");
        String message = "";
        String messageType = "danger";

        try {
            if (action == null) {
                message = "No action specified";
            } else {
                switch (action) {
                    case "generate_monthly_report":
                        message = generateMonthlyReport(request, session, username);
                        messageType = "success";
                        break;
                    case "update_monthly_report":
                        message = updateMonthlyReport(request, session, username);
                        messageType = "success";
                        break;
                    case "regenerate_monthly_report":
                        message = regenerateMonthlyReport(request, session, username);
                        messageType = "success";
                        break;
                    default:
                        message = "Invalid action: " + action;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            message = "An unexpected error occurred: " + e.getMessage();
            messageType = "danger";
        }

        session.setAttribute("message", message);
        session.setAttribute("messageType", messageType);

        // Redirect to the monthly reports section
        response.sendRedirect("sales-dashboard.jsp#monthly-reports");
    }

    private void viewBookings(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("=== viewBookings method started ===");

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        List<Map<String, Object>> bookings = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection(true, true)) {
            System.out.println("Database connection established successfully");

            // Simple query without filters first
            String query = "SELECT id, user_id, flight_id, seats, total_price, booking_date, status, flight_class " +
                    "FROM Bookings ORDER BY booking_date DESC";

            System.out.println("Executing query: " + query);

            try (PreparedStatement pstmt = conn.prepareStatement(query);
                 ResultSet rs = pstmt.executeQuery()) {

                int count = 0;
                while (rs.next()) {
                    count++;
                    Map<String, Object> booking = new HashMap<>();
                    booking.put("id", rs.getInt("id"));
                    booking.put("user_id", rs.getInt("user_id"));
                    booking.put("flight_id", rs.getInt("flight_id"));
                    booking.put("seats", rs.getInt("seats"));
                    booking.put("total_price", rs.getDouble("total_price"));

                    // Handle date properly
                    Timestamp bookingDate = rs.getTimestamp("booking_date");
                    booking.put("booking_date", bookingDate != null ? bookingDate.toString() : null);

                    booking.put("status", rs.getString("status"));
                    booking.put("flight_class", rs.getString("flight_class"));

                    bookings.add(booking);

                    System.out.println("Booking " + count + ": " + booking);
                }
                System.out.println("Total bookings found: " + count);
            }

            // Send JSON response
            String jsonResponse = convertListMapToJson(bookings);
            System.out.println("Sending JSON response: " + jsonResponse);
            out.write(jsonResponse);

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("SQL Error in viewBookings: " + e.getMessage());

            // Send error response
            String errorJson = "{\"error\": \"Database error: " + e.getMessage() + "\"}";
            out.write(errorJson);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("General Error in viewBookings: " + e.getMessage());

            String errorJson = "{\"error\": \"Unexpected error: " + e.getMessage() + "\"}";
            out.write(errorJson);
        }
    }

    private void viewFlights(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("=== viewFlights method started ===");

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        List<Map<String, Object>> flights = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection(true, true)) {
            System.out.println("Database connection established successfully for flights");

            String query = "SELECT id, departure_airport, arrival_airport, departure_date, " +
                    "flight_class, passengers, available_seats, price, departure_time " +
                    "FROM Flights ORDER BY departure_date DESC, departure_time DESC";

            System.out.println("Executing query: " + query);

            try (PreparedStatement pstmt = conn.prepareStatement(query);
                 ResultSet rs = pstmt.executeQuery()) {

                int count = 0;
                while (rs.next()) {
                    count++;
                    Map<String, Object> flight = new HashMap<>();
                    flight.put("id", rs.getInt("id"));
                    flight.put("departure_airport", rs.getString("departure_airport"));
                    flight.put("arrival_airport", rs.getString("arrival_airport"));

                    // Handle date properly
                    Date departureDate = rs.getDate("departure_date");
                    flight.put("departure_date", departureDate != null ? departureDate.toString() : null);

                    flight.put("flight_class", rs.getString("flight_class"));
                    flight.put("passengers", rs.getInt("passengers"));
                    flight.put("available_seats", rs.getInt("available_seats"));
                    flight.put("price", rs.getDouble("price"));

                    // Handle time
                    Time departureTime = rs.getTime("departure_time");
                    flight.put("departure_time", departureTime != null ? departureTime.toString() : null);

                    flights.add(flight);

                    System.out.println("Flight " + count + ": " + flight);
                }
                System.out.println("Total flights found: " + count);
            }

            // Send JSON response
            String jsonResponse = convertListMapToJson(flights);
            System.out.println("Sending JSON response for flights: " + jsonResponse);
            out.write(jsonResponse);

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("SQL Error in viewFlights: " + e.getMessage());

            // Send error response
            String errorJson = "{\"error\": \"Database error: " + e.getMessage() + "\"}";
            out.write(errorJson);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("General Error in viewFlights: " + e.getMessage());

            String errorJson = "{\"error\": \"Unexpected error: " + e.getMessage() + "\"}";
            out.write(errorJson);
        }
    }

    private void getFlightStats(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try (Connection conn = DatabaseConnection.getConnection(true, true)) {
            String query = "SELECT " +
                    "COUNT(*) as total_flights, " +
                    "SUM(CASE WHEN available_seats > 0 THEN 1 ELSE 0 END) as available_flights, " +
                    "SUM(passengers) as total_passengers, " +
                    "AVG(CAST(passengers as FLOAT) / NULLIF(passengers + available_seats, 0) * 100) as avg_load_factor " +
                    "FROM Flights";

            try (PreparedStatement pstmt = conn.prepareStatement(query);
                 ResultSet rs = pstmt.executeQuery()) {

                if (rs.next()) {
                    Map<String, Object> stats = new HashMap<>();
                    stats.put("totalFlights", rs.getInt("total_flights"));
                    stats.put("availableFlights", rs.getInt("available_flights"));
                    stats.put("totalPassengers", rs.getInt("total_passengers"));

                    double loadFactor = rs.getDouble("avg_load_factor");
                    stats.put("avgLoadFactor", String.format("%.1f", Double.isNaN(loadFactor) ? 0 : loadFactor));

                    out.write(convertMapToJson(stats));
                } else {
                    out.write("{\"error\": \"No flight statistics found\"}");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            out.write("{\"error\": \"Database error: " + e.getMessage() + "\"}");
        }
    }

    // Route Trends Analysis Method
    private void getRouteTrends(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try (Connection conn = DatabaseConnection.getConnection(true, true)) {
            System.out.println("Database connected for route analysis");

            // Route Performance Analysis
            String routeQuery = "SELECT " +
                    "departure_airport, " +
                    "arrival_airport, " +
                    "COUNT(*) as total_flights, " +
                    "SUM(passengers) as total_passengers, " +
                    "SUM(available_seats) as total_available_seats, " +
                    "AVG(price) as avg_price, " +
                    "SUM(passengers * price) as total_revenue, " +
                    "AVG(CASE WHEN passengers > 0 THEN CAST(passengers as FLOAT) / (passengers + available_seats) ELSE 0 END) * 100 as load_factor " +
                    "FROM flights " +
                    "GROUP BY departure_airport, arrival_airport " +
                    "ORDER BY total_passengers DESC";

            List<Map<String, Object>> routeData = new ArrayList<>();

            try (PreparedStatement pstmt = conn.prepareStatement(routeQuery);
                 ResultSet rs = pstmt.executeQuery()) {

                System.out.println("Executing route query: " + routeQuery);
                int count = 0;

                while (rs.next()) {
                    count++;
                    Map<String, Object> route = new HashMap<>();
                    route.put("route", rs.getString("departure_airport") + " → " + rs.getString("arrival_airport"));
                    route.put("total_flights", rs.getInt("total_flights"));
                    route.put("total_passengers", rs.getInt("total_passengers"));
                    route.put("total_available_seats", rs.getInt("total_available_seats"));
                    route.put("avg_price", rs.getDouble("avg_price"));
                    route.put("total_revenue", rs.getDouble("total_revenue"));
                    route.put("load_factor", rs.getDouble("load_factor"));

                    routeData.add(route);
                    System.out.println("Route " + count + ": " + route);
                }
                System.out.println("Total routes found: " + count);
            }

            // Monthly Route Trends
            String monthlyRouteQuery = "SELECT " +
                    "departure_airport + ' → ' + arrival_airport as route, " +
                    "FORMAT(departure_date, 'yyyy-MM') as month, " +
                    "SUM(passengers) as monthly_passengers, " +
                    "AVG(price) as monthly_avg_price " +
                    "FROM flights " +
                    "WHERE departure_date >= DATEADD(MONTH, -6, GETDATE()) " +
                    "GROUP BY departure_airport, arrival_airport, FORMAT(departure_date, 'yyyy-MM') " +
                    "ORDER BY month, route";

            Map<String, Map<String, Object>> monthlyTrends = new LinkedHashMap<>();

            try (PreparedStatement pstmt = conn.prepareStatement(monthlyRouteQuery);
                 ResultSet rs = pstmt.executeQuery()) {

                System.out.println("Executing monthly trends query");
                int monthlyCount = 0;

                while (rs.next()) {
                    monthlyCount++;
                    String month = rs.getString("month");
                    String route = rs.getString("route");
                    int passengers = rs.getInt("monthly_passengers");
                    double avgPrice = rs.getDouble("monthly_avg_price");

                    if (!monthlyTrends.containsKey(month)) {
                        monthlyTrends.put(month, new HashMap<>());
                    }
                    monthlyTrends.get(month).put(route + "_passengers", passengers);
                    monthlyTrends.get(month).put(route + "_price", avgPrice);
                }
                System.out.println("Monthly trends entries: " + monthlyCount);
            }

            // Prepare JSON response
            List<Map<String, Object>> monthlyTrendsList = new ArrayList<>();
            List<String> monthsList = new ArrayList<>(monthlyTrends.keySet());

            for (String month : monthsList) {
                Map<String, Object> monthData = new HashMap<>();
                monthData.put("month", month);
                monthData.putAll(monthlyTrends.get(month));
                monthlyTrendsList.add(monthData);
            }

            // Build JSON response
            StringBuilder jsonResponse = new StringBuilder();
            jsonResponse.append("{");
            jsonResponse.append("\"routePerformance\":").append(convertListMapToJson(routeData)).append(",");
            jsonResponse.append("\"monthlyTrends\":").append(convertListMapToJson(monthlyTrendsList)).append(",");
            jsonResponse.append("\"months\":[");

            boolean firstMonth = true;
            for (String month : monthsList) {
                if (!firstMonth) {
                    jsonResponse.append(",");
                }
                jsonResponse.append("\"").append(escapeJsonString(month)).append("\"");
                firstMonth = false;
            }
            jsonResponse.append("]");
            jsonResponse.append("}");

            System.out.println("Sending JSON response for route trends");
            out.write(jsonResponse.toString());

        } catch (SQLException e) {
            System.err.println("Database error in getRouteTrends: " + e.getMessage());
            e.printStackTrace();
            out.write("{\"error\": \"Database error: " + e.getMessage() + "\"}");
        }
    }

    // JSON conversion methods
    private String convertListMapToJson(List<Map<String, Object>> data) {
        if (data == null || data.isEmpty()) {
            return "[]";
        }

        StringBuilder json = new StringBuilder();
        json.append("[");

        for (int i = 0; i < data.size(); i++) {
            if (i > 0) json.append(",");
            Map<String, Object> item = data.get(i);
            json.append("{");

            int count = 0;
            for (Map.Entry<String, Object> entry : item.entrySet()) {
                if (count > 0) json.append(",");

                json.append("\"").append(entry.getKey()).append("\":");

                Object value = entry.getValue();
                if (value == null) {
                    json.append("null");
                } else if (value instanceof String) {
                    json.append("\"").append(escapeJsonString(value.toString())).append("\"");
                } else if (value instanceof Number) {
                    json.append(value);
                } else {
                    json.append("\"").append(escapeJsonString(value.toString())).append("\"");
                }
                count++;
            }

            json.append("}");
        }

        json.append("]");
        return json.toString();
    }

    private String convertMapToJson(Map<String, Object> data) {
        if (data == null || data.isEmpty()) {
            return "{}";
        }

        StringBuilder json = new StringBuilder();
        json.append("{");

        int count = 0;
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            if (count > 0) json.append(",");

            json.append("\"").append(entry.getKey()).append("\":");

            Object value = entry.getValue();
            if (value == null) {
                json.append("null");
            } else if (value instanceof String) {
                json.append("\"").append(escapeJsonString(value.toString())).append("\"");
            } else if (value instanceof Number) {
                json.append(value);
            } else {
                json.append("\"").append(escapeJsonString(value.toString())).append("\"");
            }
            count++;
        }

        json.append("}");
        return json.toString();
    }

    // Helper method to escape JSON strings
    private String escapeJsonString(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private void testConnection(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try (Connection conn = DatabaseConnection.getConnection(true, true)) {
            System.out.println("Test connection successful");
            out.write("{\"status\": \"success\", \"message\": \"Database connection successful\"}");
        } catch (SQLException e) {
            System.err.println("Test connection failed: " + e.getMessage());
            out.write("{\"status\": \"error\", \"message\": \"Database connection failed: " + e.getMessage() + "\"}");
        }
    }

    private void getMonthlyReports(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> monthlyReports = (List<Map<String, Object>>) session.getAttribute("monthlyReports");

        if (monthlyReports == null) {
            monthlyReports = new ArrayList<>();
        }

        out.write(convertListMapToJson(monthlyReports));
    }

    private void deleteReport(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String reportId = request.getParameter("reportId");

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> monthlyReports = (List<Map<String, Object>>) session.getAttribute("monthlyReports");

        if (monthlyReports != null && reportId != null) {
            boolean removed = monthlyReports.removeIf(report -> reportId.equals(report.get("report_id")));
            session.setAttribute("monthlyReports", monthlyReports);

            if (removed) {
                out.write("{\"success\": true, \"message\": \"Report deleted successfully\"}");
            } else {
                out.write("{\"success\": false, \"message\": \"Report not found\"}");
            }
        } else {
            out.write("{\"success\": false, \"message\": \"Invalid request\"}");
        }
    }

    private String updateMonthlyReport(HttpServletRequest request, HttpSession session, String username) {
        return "Report updated successfully!";
    }

    private String regenerateMonthlyReport(HttpServletRequest request, HttpSession session, String username) {
        return "Report regenerated successfully!";
    }

    private void getReportData(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        // Simple test data for charts
        String testData = "{" +
                "\"labels\":[\"Jan\",\"Feb\",\"Mar\",\"Apr\"]," +
                "\"datasets\":[{" +
                "\"label\":\"Test Data\"," +
                "\"data\":[10,20,15,25]," +
                "\"backgroundColor\":\"#36A2EB\"," +
                "\"borderColor\":\"#36A2EB\"" +
                "}]" +
                "}";

        out.write(testData);
    }

    private void loadDashboardData(HttpServletRequest request, HttpSession session) {
        // Simple test data
        // You can add any dashboard initialization logic here
    }

    private String getMonthName(String monthNumber) {
        String[] monthNames = {"January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"};
        try {
            int month = Integer.parseInt(monthNumber);
            if (month >= 1 && month <= 12) {
                return monthNames[month - 1];
            }
        } catch (NumberFormatException e) {}
        return "Unknown";
    }

    private String generateMonthlyReport(HttpServletRequest request, HttpSession session, String username) {
        String reportName = request.getParameter("report_name");
        String reportMonth = request.getParameter("report_month");
        String reportYear = request.getParameter("report_year");
        String description = request.getParameter("description");

        if (reportName == null || reportMonth == null || reportYear == null) {
            return "Missing required parameters";
        }

        Map<String, Object> newReport = new HashMap<>();
        newReport.put("report_id", "MR" + System.currentTimeMillis());
        newReport.put("report_name", reportName);
        newReport.put("report_month", reportMonth);
        newReport.put("report_year", reportYear);
        newReport.put("period", getMonthName(reportMonth) + " " + reportYear);
        newReport.put("description", description);
        newReport.put("created_date", new java.util.Date());
        newReport.put("created_by", username);
        newReport.put("status", "Generated");

        // Calculate detailed report statistics
        calculateDetailedReportStatistics(newReport, reportMonth, reportYear);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> monthlyReports = (List<Map<String, Object>>) session.getAttribute("monthlyReports");
        if (monthlyReports == null) {
            monthlyReports = new ArrayList<>();
        }

        monthlyReports.add(0, newReport);
        session.setAttribute("monthlyReports", monthlyReports);

        return "Monthly report generated successfully!";
    }

    private void calculateDetailedReportStatistics(Map<String, Object> report, String reportMonth, String reportYear) {
        String query = "SELECT " +
                "COUNT(*) as total_bookings, " +
                "SUM(seats) as total_seats, " +
                "SUM(total_price) as total_revenue, " +
                "SUM(CASE WHEN status = 'confirmed' THEN seats ELSE 0 END) as confirmed_seats, " +
                "SUM(CASE WHEN status = 'confirmed' THEN total_price ELSE 0 END) as confirmed_revenue, " +
                "SUM(CASE WHEN status = 'pending' THEN seats ELSE 0 END) as pending_seats, " +
                "SUM(CASE WHEN status = 'pending' THEN total_price ELSE 0 END) as pending_revenue, " +
                "SUM(CASE WHEN status = 'cancelled' THEN seats ELSE 0 END) as cancelled_seats, " +
                "SUM(CASE WHEN status = 'cancelled' THEN total_price ELSE 0 END) as cancelled_revenue, " +
                "COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmed_bookings, " +
                "COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_bookings, " +
                "COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_bookings " +
                "FROM Bookings " +
                "WHERE MONTH(booking_date) = ? AND YEAR(booking_date) = ?";

        try (Connection conn = DatabaseConnection.getConnection(true, true);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, Integer.parseInt(reportMonth));
            pstmt.setInt(2, Integer.parseInt(reportYear));

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int totalBookings = rs.getInt("total_bookings");
                    int totalSeats = rs.getInt("total_seats");
                    double totalRevenue = rs.getDouble("total_revenue");
                    int confirmedSeats = rs.getInt("confirmed_seats");
                    double confirmedRevenue = rs.getDouble("confirmed_revenue");
                    int pendingSeats = rs.getInt("pending_seats");
                    double pendingRevenue = rs.getDouble("pending_revenue");
                    int cancelledSeats = rs.getInt("cancelled_seats");
                    double cancelledRevenue = rs.getDouble("cancelled_revenue");
                    int confirmedBookings = rs.getInt("confirmed_bookings");
                    int pendingBookings = rs.getInt("pending_bookings");
                    int cancelledBookings = rs.getInt("cancelled_bookings");

                    double avgSeatValue = (confirmedSeats > 0) ? (confirmedRevenue / confirmedSeats) : 0;
                    double cancellationRate = (totalBookings > 0) ? (cancelledBookings * 100.0) / totalBookings : 0;

                    report.put("total_bookings", totalBookings);
                    report.put("total_seats", totalSeats);
                    report.put("total_revenue", totalRevenue);
                    report.put("confirmed_seats", confirmedSeats);
                    report.put("confirmed_revenue", confirmedRevenue);
                    report.put("pending_seats", pendingSeats);
                    report.put("pending_revenue", pendingRevenue);
                    report.put("cancelled_seats", cancelledSeats);
                    report.put("cancelled_revenue", cancelledRevenue);
                    report.put("confirmed_bookings", confirmedBookings);
                    report.put("pending_bookings", pendingBookings);
                    report.put("cancelled_bookings", cancelledBookings);
                    report.put("avg_seat_value", avgSeatValue);
                    report.put("cancellation_rate", cancellationRate);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Set default values
            setDefaultReportValues(report);
        }
    }

    private void setDefaultReportValues(Map<String, Object> report) {
        report.put("total_bookings", 0);
        report.put("total_seats", 0);
        report.put("total_revenue", 0.0);
        report.put("confirmed_seats", 0);
        report.put("confirmed_revenue", 0.0);
        report.put("pending_seats", 0);
        report.put("pending_revenue", 0.0);
        report.put("cancelled_seats", 0);
        report.put("cancelled_revenue", 0.0);
        report.put("confirmed_bookings", 0);
        report.put("pending_bookings", 0);
        report.put("cancelled_bookings", 0);
        report.put("avg_seat_value", 0.0);
        report.put("cancellation_rate", 0.0);
    }

    // PDF generation endpoint
    private void generatePdfReport(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws IOException {
        String reportId = request.getParameter("reportId");

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> monthlyReports = (List<Map<String, Object>>) session.getAttribute("monthlyReports");

        Map<String, Object> report = null;
        if (monthlyReports != null) {
            for (Map<String, Object> r : monthlyReports) {
                if (reportId.equals(r.get("report_id"))) {
                    report = r;
                    break;
                }
            }
        }

        if (report == null) {
            response.sendError(404, "Report not found");
            return;
        }

        // Set response for PDF download with proper headers
        response.setContentType("application/pdf");
        String fileName = "Monthly_Report_" +
                (report.get("report_name") != null ?
                        report.get("report_name").toString().replaceAll("[^a-zA-Z0-9_-]", "_") : "Unknown") +
                "_" + reportId + ".pdf";
        response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

        // Create simple text content that browsers will treat as PDF
        StringBuilder pdfContent = new StringBuilder();
        pdfContent.append("SkyLinkOnline - Monthly Report\n");
        pdfContent.append("================================\n\n");
        pdfContent.append("Report Name: ").append(report.get("report_name") != null ? report.get("report_name") : "N/A").append("\n");
        pdfContent.append("Period: ").append(report.get("period") != null ? report.get("period") : "N/A").append("\n");
        pdfContent.append("Description: ").append(report.get("description") != null ? report.get("description") : "N/A").append("\n\n");

        pdfContent.append("SUMMARY STATISTICS\n");
        pdfContent.append("==================\n");
        pdfContent.append("Total Bookings: ").append(report.get("total_bookings") != null ? report.get("total_bookings") : "0").append("\n");
        pdfContent.append("Total Revenue: $").append(report.get("total_revenue") != null ? String.format("%.2f", report.get("total_revenue")) : "0.00").append("\n");
        pdfContent.append("Total Seats: ").append(report.get("total_seats") != null ? report.get("total_seats") : "0").append("\n");
        pdfContent.append("Average Seat Value: $").append(report.get("avg_seat_value") != null ? String.format("%.2f", report.get("avg_seat_value")) : "0.00").append("\n");
        pdfContent.append("Cancellation Rate: ").append(report.get("cancellation_rate") != null ? String.format("%.1f", report.get("cancellation_rate")) : "0.0").append("%\n\n");

        pdfContent.append("BOOKING BREAKDOWN\n");
        pdfContent.append("=================\n");
        pdfContent.append("Confirmed Bookings: ").append(report.get("confirmed_bookings") != null ? report.get("confirmed_bookings") : "0").append("\n");
        pdfContent.append("Confirmed Seats: ").append(report.get("confirmed_seats") != null ? report.get("confirmed_seats") : "0").append("\n");
        pdfContent.append("Confirmed Revenue: $").append(report.get("confirmed_revenue") != null ? String.format("%.2f", report.get("confirmed_revenue")) : "0.00").append("\n\n");

        pdfContent.append("Pending Bookings: ").append(report.get("pending_bookings") != null ? report.get("pending_bookings") : "0").append("\n");
        pdfContent.append("Pending Seats: ").append(report.get("pending_seats") != null ? report.get("pending_seats") : "0").append("\n");
        pdfContent.append("Pending Revenue: $").append(report.get("pending_revenue") != null ? String.format("%.2f", report.get("pending_revenue")) : "0.00").append("\n\n");

        pdfContent.append("Cancelled Bookings: ").append(report.get("cancelled_bookings") != null ? report.get("cancelled_bookings") : "0").append("\n");
        pdfContent.append("Cancelled Seats: ").append(report.get("cancelled_seats") != null ? report.get("cancelled_seats") : "0").append("\n");
        pdfContent.append("Cancelled Revenue: $").append(report.get("cancelled_revenue") != null ? String.format("%.2f", report.get("cancelled_revenue")) : "0.00").append("\n\n");

        pdfContent.append("Report Generated: ").append(new java.util.Date()).append("\n");
        pdfContent.append("Generated By: ").append(report.get("created_by") != null ? report.get("created_by") : "System").append("\n");

        // Write the content
        response.getWriter().write(pdfContent.toString());
    }
}