package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.net.URLEncoder;
import com.example.util.DatabaseConnection;
import com.example.util.Logger;

public class LoginServlet extends HttpServlet {
    
    // Singleton logger instance
    private static final Logger logger = Logger.getInstance();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        logger.info("Login attempt - username=" + username + ", remoteAddr=" + request.getRemoteAddr());

        if (username == null || password == null || username.isEmpty() || password.isEmpty()) {
            response.sendRedirect("login.jsp?error=true");
            return;
        }

        try {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("SELECT id, role FROM Users WHERE username = ? AND password = ?")) {
                stmt.setString(1, username);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    logger.info("Authentication SUCCESS for username=" + username);
                    HttpSession session = request.getSession();
                    session.setAttribute("username", username);
                    session.setAttribute("user_id", rs.getInt("id"));

                    String role = rs.getString("role");
                    session.setAttribute("role", role);

                    String redirect = request.getParameter("redirect");
                    if (redirect != null && !redirect.isEmpty()) {
                        logger.info("Redirecting to provided redirect URL: " + redirect);
                        response.sendRedirect(redirect);
                    } else if ("finance_officer".equals(role)) {
                        logger.info("Redirecting to finance_dashboard.jsp");
                        response.sendRedirect("finance_dashboard.jsp");
                    } else if ("flight_scheduler".equals(role)) {
                        logger.info("Redirecting to scheduler_dashboard.jsp");
                        response.sendRedirect("scheduler_dashboard.jsp");

                    } else if ("it_admin".equals(role)) {
                        logger.info("Redirecting to admin_dashboard.jsp");
                        response.sendRedirect("admin_dashboard.jsp");

                    } else if ("support_officer".equals(role)) {
                        logger.info("Redirecting to CustomerSupportDashboard.jsp");
                        response.sendRedirect("CustomerSupportDashboard.jsp");

                    } else if ("Sales_Manager".equals(role)) {
                        logger.info("Redirecting to sales-dashboard.jsp");
                        response.sendRedirect("sales-dashboard.jsp");


                    } else {
                        logger.info("Redirecting to dashboard.jsp (customer)");
                        response.sendRedirect("dashboard.jsp"); // Customer
                    }
                } else {
                    logger.warn("Authentication FAILED for username=" + username);
                    String errorRedirect = "login.jsp?error=true";
                    if (request.getParameter("redirect") != null) {
                        errorRedirect += "&redirect=" + URLEncoder.encode(request.getParameter("redirect"), "UTF-8");
                    }
                    response.sendRedirect(errorRedirect);
                }
            }
        } catch (SQLException e) {
            logger.error("Database error during login", e);
            response.sendRedirect("login.jsp?error=true");
        }
    }
}