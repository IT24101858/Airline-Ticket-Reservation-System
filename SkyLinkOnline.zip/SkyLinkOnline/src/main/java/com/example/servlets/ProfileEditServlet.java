package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.net.URLEncoder;
import com.example.util.DatabaseConnection;
import com.example.util.Logger;

public class ProfileEditServlet extends HttpServlet {
    
    // Singleton logger instance
    private static final Logger logger = Logger.getInstance();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        
        // Check if user is logged in
        if (session == null || session.getAttribute("username") == null || !"customer".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String username = (String) session.getAttribute("username");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirm_password");
        String firstName = request.getParameter("first_name");
        String lastName = request.getParameter("last_name");
        String email = request.getParameter("email");
        String phoneNumber = request.getParameter("phone_number");
        String passportNumber = request.getParameter("passport_number");
        
        logger.info("Profile update attempt - username=" + username + ", remoteAddr=" + request.getRemoteAddr());

        // Validate required fields
        if (firstName == null || firstName.trim().isEmpty() ||
            lastName == null || lastName.trim().isEmpty() ||
            email == null || email.trim().isEmpty()) {
            response.sendRedirect("profile.jsp?error=" + URLEncoder.encode("First name, last name, and email are required", "UTF-8"));
            return;
        }
        
        // Validate password if provided
        if (password != null && !password.trim().isEmpty()) {
            if (password.length() < 6) {
                response.sendRedirect("profile.jsp?error=" + URLEncoder.encode("Password must be at least 6 characters long", "UTF-8"));
                return;
            }
            if (!password.equals(confirmPassword)) {
                response.sendRedirect("profile.jsp?error=" + URLEncoder.encode("Passwords do not match", "UTF-8"));
                return;
            }
        }

        try {
            try (Connection conn = DatabaseConnection.getConnection()) {
                // Check if email is already taken by another user
                PreparedStatement emailCheck = conn.prepareStatement("SELECT COUNT(*) FROM Users WHERE email = ? AND username != ?");
                emailCheck.setString(1, email);
                emailCheck.setString(2, username);
                ResultSet rs = emailCheck.executeQuery();
                rs.next();
                if (rs.getInt(1) > 0) {
                    logger.warn("Profile update failed - email already exists: " + email);
                    response.sendRedirect("profile.jsp?error=" + URLEncoder.encode("Email already exists", "UTF-8"));
                    return;
                }
                
                // Update user profile
                String sql;
                PreparedStatement stmt;
                
                if (password != null && !password.trim().isEmpty()) {
                    // Update with password
                    sql = "UPDATE Users SET first_name = ?, last_name = ?, email = ?, phone_number = ?, passport_number = ?, password = ? WHERE username = ?";
                    stmt = conn.prepareStatement(sql);
                    stmt.setString(1, firstName.trim());
                    stmt.setString(2, lastName.trim());
                    stmt.setString(3, email.trim());
                    stmt.setString(4, phoneNumber != null ? phoneNumber.trim() : null);
                    stmt.setString(5, passportNumber != null && !passportNumber.trim().isEmpty() ? passportNumber.trim() : null);
                    stmt.setString(6, password.trim());
                    stmt.setString(7, username);
                } else {
                    // Update without password
                    sql = "UPDATE Users SET first_name = ?, last_name = ?, email = ?, phone_number = ?, passport_number = ? WHERE username = ?";
                    stmt = conn.prepareStatement(sql);
                    stmt.setString(1, firstName.trim());
                    stmt.setString(2, lastName.trim());
                    stmt.setString(3, email.trim());
                    stmt.setString(4, phoneNumber != null ? phoneNumber.trim() : null);
                    stmt.setString(5, passportNumber != null && !passportNumber.trim().isEmpty() ? passportNumber.trim() : null);
                    stmt.setString(6, username);
                }
                
                int rowsAffected = stmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    logger.info("Profile update SUCCESS for username=" + username);
                    
                    // Update session attributes
                    session.setAttribute("fullname", (firstName.trim() + " " + lastName.trim()).trim());
                    session.setAttribute("email", email.trim());
                    
                    response.sendRedirect("profile.jsp?message=" + URLEncoder.encode("Profile updated successfully!", "UTF-8"));
                } else {
                    logger.warn("Profile update failed - no rows affected for username=" + username);
                    response.sendRedirect("profile.jsp?error=" + URLEncoder.encode("Failed to update profile. Please try again.", "UTF-8"));
                }
            }
        } catch (SQLException e) {
            logger.error("Database error during profile update", e);
            response.sendRedirect("profile.jsp?error=" + URLEncoder.encode("Database error occurred. Please try again.", "UTF-8"));
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Redirect GET requests to profile.jsp
        response.sendRedirect("profile.jsp");
    }
}
