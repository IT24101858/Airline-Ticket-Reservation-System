package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;
import com.example.util.DatabaseConnectionManager;
import com.example.util.Logger;
import com.example.util.ConfigurationManager;

/**
 * Demo servlet to showcase Singleton pattern implementations.
 * This servlet demonstrates how all Singleton instances work together.
 */
@WebServlet("/singleton-demo")
public class SingletonDemoServlet extends HttpServlet {
    
    // Singleton instances
    private static final Logger logger = Logger.getInstance();
    private static final ConfigurationManager configManager = ConfigurationManager.getInstance();
    private static final DatabaseConnectionManager connectionManager = DatabaseConnectionManager.getInstance();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        logger.info("SingletonDemoServlet accessed");
        
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");
        
        PrintWriter out = response.getWriter();
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Singleton Pattern Demo - SkyLinkOnline</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }");
        out.println(".container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }");
        out.println("h1 { color: #333; text-align: center; }");
        out.println("h2 { color: #666; border-bottom: 2px solid #eee; padding-bottom: 10px; }");
        out.println(".section { margin: 20px 0; padding: 15px; background: #f9f9f9; border-radius: 5px; }");
        out.println(".success { color: #28a745; }");
        out.println(".info { color: #17a2b8; }");
        out.println(".warning { color: #ffc107; }");
        out.println(".error { color: #dc3545; }");
        out.println("pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<h1>🔧 Singleton Pattern Implementation Demo</h1>");
        
        // Logger Singleton Demo
        out.println("<div class='section'>");
        out.println("<h2>📝 Logger Singleton</h2>");
        out.println("<p class='info'>Logger instance: " + logger.toString() + "</p>");
        out.println("<p class='info'>Log level: " + logger.getLogLevel() + "</p>");
        out.println("<p class='info'>Log file: " + logger.getLogFilePath() + "</p>");
        
        // Test different log levels
        logger.debug("This is a debug message");
        logger.info("This is an info message");
        logger.warn("This is a warning message");
        logger.error("This is an error message");
        
        out.println("<p class='success'>✓ Logger singleton working correctly</p>");
        out.println("</div>");
        
        // Configuration Manager Singleton Demo
        out.println("<div class='section'>");
        out.println("<h2>⚙️ Configuration Manager Singleton</h2>");
        out.println("<p class='info'>Configuration instance: " + configManager.toString() + "</p>");
        out.println("<p class='info'>Application name: " + configManager.getApplicationName() + "</p>");
        out.println("<p class='info'>Application version: " + configManager.getApplicationVersion() + "</p>");
        out.println("<p class='info'>Database URL: " + configManager.getDatabaseUrl() + "</p>");
        out.println("<p class='info'>Debug mode: " + configManager.isDebugEnabled() + "</p>");
        out.println("<p class='info'>Session timeout: " + configManager.getSessionTimeout() + " seconds</p>");
        out.println("<p class='info'>Max connections: " + configManager.getMaxConnections() + "</p>");
        
        // Test configuration operations
        String testKey = "test.property";
        String testValue = "test.value." + System.currentTimeMillis();
        configManager.setProperty(testKey, testValue);
        String retrievedValue = configManager.getProperty(testKey);
        
        if (testValue.equals(retrievedValue)) {
            out.println("<p class='success'>✓ Configuration Manager singleton working correctly</p>");
        } else {
            out.println("<p class='error'>✗ Configuration Manager test failed</p>");
        }
        
        // Clean up test property
        configManager.removeProperty(testKey);
        out.println("</div>");
        
        // Database Connection Manager Singleton Demo
        out.println("<div class='section'>");
        out.println("<h2>🗄️ Database Connection Manager Singleton</h2>");
        out.println("<p class='info'>Connection Manager instance: " + connectionManager.toString() + "</p>");
        out.println("<p class='info'>Active connections: " + connectionManager.getActiveConnectionCount() + "</p>");
        out.println("<p class='info'>Connection pool status: " + connectionManager.getConnectionPoolStatus() + "</p>");
        
        // Test database connection
        try {
            Connection conn = connectionManager.getConnection();
            if (conn != null && !conn.isClosed()) {
                out.println("<p class='success'>✓ Database connection successful</p>");
                out.println("<p class='info'>Connection class: " + conn.getClass().getSimpleName() + "</p>");
                out.println("<p class='info'>Connection URL: " + conn.getMetaData().getURL() + "</p>");
                out.println("<p class='info'>Database product: " + conn.getMetaData().getDatabaseProductName() + "</p>");
                out.println("<p class='info'>Database version: " + conn.getMetaData().getDatabaseProductVersion() + "</p>");
                
                // Test connection through facade
                boolean testResult = DatabaseConnection.testConnection();
                if (testResult) {
                    out.println("<p class='success'>✓ Database Connection facade working correctly</p>");
                } else {
                    out.println("<p class='error'>✗ Database Connection facade test failed</p>");
                }
            } else {
                out.println("<p class='error'>✗ Database connection failed</p>");
            }
        } catch (SQLException e) {
            out.println("<p class='error'>✗ Database connection error: " + e.getMessage() + "</p>");
            logger.error("Database connection error in demo", e);
        }
        
        out.println("</div>");
        
        // Singleton Pattern Verification
        out.println("<div class='section'>");
        out.println("<h2>🔍 Singleton Pattern Verification</h2>");
        
        // Test multiple instances
        Logger logger2 = Logger.getInstance();
        ConfigurationManager configManager2 = ConfigurationManager.getInstance();
        DatabaseConnectionManager connectionManager2 = DatabaseConnectionManager.getInstance();
        
        out.println("<pre>");
        out.println("Logger instances equal: " + (logger == logger2));
        out.println("Configuration Manager instances equal: " + (configManager == configManager2));
        out.println("Connection Manager instances equal: " + (connectionManager == connectionManager2));
        out.println("</pre>");
        
        if (logger == logger2 && configManager == configManager2 && connectionManager == connectionManager2) {
            out.println("<p class='success'>✓ All Singleton instances are properly implemented</p>");
        } else {
            out.println("<p class='error'>✗ Singleton pattern implementation has issues</p>");
        }
        
        out.println("</div>");
        
        // Usage Examples
        out.println("<div class='section'>");
        out.println("<h2>📚 Usage Examples</h2>");
        out.println("<pre>");
        out.println("// Logger Singleton Usage");
        out.println("Logger logger = Logger.getInstance();");
        out.println("logger.info(\"Application started\");");
        out.println("logger.error(\"Error occurred\", exception);");
        out.println("");
        out.println("// Configuration Manager Singleton Usage");
        out.println("ConfigurationManager config = ConfigurationManager.getInstance();");
        out.println("String dbUrl = config.getDatabaseUrl();");
        out.println("config.setProperty(\"custom.property\", \"value\");");
        out.println("");
        out.println("// Database Connection Manager Singleton Usage");
        out.println("DatabaseConnectionManager connMgr = DatabaseConnectionManager.getInstance();");
        out.println("Connection conn = connMgr.getConnection();");
        out.println("// ... use connection ...");
        out.println("connMgr.closeConnection(conn);");
        out.println("");
        out.println("// Or use the facade");
        out.println("Connection conn = DatabaseConnection.getConnection();");
        out.println("DatabaseConnection.closeConnection(conn);");
        out.println("</pre>");
        out.println("</div>");
        
        out.println("<div class='section'>");
        out.println("<h2>🎯 Benefits of Singleton Pattern</h2>");
        out.println("<ul>");
        out.println("<li><strong>Resource Management:</strong> Single instance manages database connections efficiently</li>");
        out.println("<li><strong>Configuration Centralization:</strong> All configuration in one place</li>");
        out.println("<li><strong>Logging Consistency:</strong> Unified logging across the application</li>");
        out.println("<li><strong>Thread Safety:</strong> Thread-safe implementations for concurrent access</li>");
        out.println("<li><strong>Memory Efficiency:</strong> No duplicate instances consuming memory</li>");
        out.println("<li><strong>Global Access:</strong> Easy access from anywhere in the application</li>");
        out.println("</ul>");
        out.println("</div>");
        
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
        
        logger.info("SingletonDemoServlet completed successfully");
    }
}
