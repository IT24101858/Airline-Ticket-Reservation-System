package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;

public class RetryServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (!"finance_officer".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String transaction_idStr = request.getParameter("id");
        System.out.println("[RetryServlet] doGet - transaction_id=" + transaction_idStr);

        if (transaction_idStr == null || transaction_idStr.isEmpty()) {
            response.sendRedirect("alerts.jsp?message=Invalid transaction ID");
            return;
        }

        int transaction_id = Integer.parseInt(transaction_idStr);

        try {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("UPDATE Transactions SET status = 'success' WHERE id = ? AND status = 'failed'")) {
                stmt.setInt(1, transaction_id);
                int updated = stmt.executeUpdate();
                if (updated > 0) {
                    System.out.println("[RetryServlet] Transaction retried successfully, id=" + transaction_id);
                    response.sendRedirect("alerts.jsp?message=Transaction retried successfully");
                } else {
                    System.out.println("[RetryServlet] Transaction not found or already processed, id=" + transaction_id);
                    response.sendRedirect("alerts.jsp?message=Transaction not found or already processed");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("[RetryServlet] Error retrying transaction: " + e.getMessage());
            response.sendRedirect("alerts.jsp?message=Error retrying transaction");
        }
    }
}