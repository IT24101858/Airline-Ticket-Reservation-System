package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import com.example.util.DatabaseConnection;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class AddFlightServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (!"flight_scheduler".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String departure_airport = request.getParameter("departure_airport");
        String arrival_airport = request.getParameter("arrival_airport");
        String departure_date = request.getParameter("departure_date");
        String departure_time = request.getParameter("departure_time");
        String flight_class = request.getParameter("flight_class");
        String passengersStr = request.getParameter("passengers");
        String available_seatsStr = request.getParameter("available_seats");
        String priceStr = request.getParameter("price");

        System.out.println("[AddFlightServlet] doPost - dep=" + departure_airport + ", arr=" + arrival_airport + ", date=" + departure_date + ", time=" + departure_time + ", class=" + flight_class + ", passengers=" + passengersStr + ", seats=" + available_seatsStr + ", price=" + priceStr);

        // Fixed null check for departure_time
        if (departure_airport == null || arrival_airport == null || departure_date == null || departure_time == null ||
                flight_class == null || passengersStr == null || available_seatsStr == null || priceStr == null ||
                departure_airport.isEmpty() || arrival_airport.isEmpty() || departure_date.isEmpty() ||
                departure_time.isEmpty() || flight_class.isEmpty() || passengersStr.isEmpty() ||
                available_seatsStr.isEmpty() || priceStr.isEmpty()) {
            response.sendRedirect("add_flight.jsp?message=Please fill all fields");
            return;
        }

        try {
            int passengers = Integer.parseInt(passengersStr);
            int available_seats = Integer.parseInt(available_seatsStr);
            double price = Double.parseDouble(priceStr);

            // Parse date and time and combine them into a datetime
            LocalDate date = LocalDate.parse(departure_date);
            LocalTime time = LocalTime.parse(departure_time);
            LocalDateTime departureDateTime = LocalDateTime.of(date, time);
            Timestamp departureTimestamp = Timestamp.valueOf(departureDateTime);

            // Fixed SQL query - corrected column count and parameter mapping
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                         "INSERT INTO Flights (departure_airport, arrival_airport, departure_date, flight_class, passengers, available_seats, price) VALUES (?, ?, ?, ?, ?, ?, ?)")) {

                stmt.setString(1, departure_airport);
                stmt.setString(2, arrival_airport);
                stmt.setTimestamp(3, departureTimestamp);
                stmt.setString(4, flight_class);
                stmt.setInt(5, passengers);
                stmt.setInt(6, available_seats);
                stmt.setDouble(7, price);

                stmt.executeUpdate();
                System.out.println("[AddFlightServlet] Flight inserted successfully");
                response.sendRedirect("scheduler_dashboard.jsp?message=Flight added successfully");
            }
        } catch (NumberFormatException e) {
            // Added specific handling for number parsing errors
            e.printStackTrace();
            response.sendRedirect("add_flight.jsp?message=Invalid number format");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("add_flight.jsp?message=Error adding flight");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("add_flight.jsp?message=Invalid date/time format");
        }
    }
}