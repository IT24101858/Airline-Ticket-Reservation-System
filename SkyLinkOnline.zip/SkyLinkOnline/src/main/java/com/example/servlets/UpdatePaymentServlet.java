package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import com.example.util.DatabaseConnection;

@WebServlet("/updatePayment")
public class UpdatePaymentServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Disallow GET for state-changing operations; redirect to list
        System.out.println("[UpdatePaymentServlet] doGet - disallowed method, redirecting");
        response.sendRedirect(request.getContextPath() + "/failed_alerts.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Session + role check
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null || !"finance_officer".equals(session.getAttribute("role"))) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        String idStr = request.getParameter("id");
        System.out.println("[UpdatePaymentServlet] doPost - action=" + action + ", id=" + idStr);

        if (action == null || idStr == null) {
            redirectWithMessage(response, request, "Invalid request");
            return;
        }

        final int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            redirectWithMessage(response, request, "Invalid transaction id");
            return;
        }

        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            if ("retry".equals(action)) {
                // Mark transaction as success and update booking -> paid
                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE Transactions SET status = 'success' WHERE id = ?")) {
                    ps.setInt(1, id);
                    int updated = ps.executeUpdate();
                    if (updated == 0) {
                        conn.rollback();
                        redirectWithMessage(response, request, "Transaction not found: " + id);
                        return;
                    }
                }

                try (PreparedStatement ps2 = conn.prepareStatement(
                        "UPDATE Bookings SET status = 'paid' WHERE id = (SELECT booking_id FROM Transactions WHERE id = ?)")) {
                    ps2.setInt(1, id);
                    ps2.executeUpdate(); // if booking not found, we still continue
                }

                // Optional: insert audit/log row if you have a TransactionLog table
                try {
                    try (PreparedStatement log = conn.prepareStatement(
                            "INSERT INTO TransactionLog(transaction_id, message, log_date) VALUES (?,?,GETDATE())")) {
                        log.setInt(1, id);
                        log.setString(2, "Retry performed by finance officer - marked success");
                        log.executeUpdate();
                    }
                } catch (SQLException ignore) {
                    // don't fail whole flow if log table doesn't exist
                }

                conn.commit();
                redirectWithMessage(response, request, "Transaction " + id + " marked SUCCESS (retry).");
                return;

            } else if ("refund".equals(action)) {
                // Mark transaction as refunded and optionally update booking status
                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE Transactions SET status = 'refunded' WHERE id = ?")) {
                    ps.setInt(1, id);
                    int updated = ps.executeUpdate();
                    if (updated == 0) {
                        conn.rollback();
                        redirectWithMessage(response, request, "Transaction not found: " + id);
                        return;
                    }
                }

                try (PreparedStatement ps2 = conn.prepareStatement(
                        "UPDATE Bookings SET status = 'refunded' WHERE id = (SELECT booking_id FROM Transactions WHERE id = ?)")) {
                    ps2.setInt(1, id);
                    ps2.executeUpdate();
                }

                try {
                    try (PreparedStatement log = conn.prepareStatement(
                            "INSERT INTO TransactionLog(transaction_id, message, log_date) VALUES (?,?,GETDATE())")) {
                        log.setInt(1, id);
                        log.setString(2, "Refund processed by finance officer (DB-side). Payment gateway call required separately.");
                        log.executeUpdate();
                    }
                } catch (SQLException ignore) {
                    // ignore if log missing
                }

                conn.commit();
                redirectWithMessage(response, request, "Transaction " + id + " marked REFUNDED.");
                return;

            } else {
                conn.rollback();
                redirectWithMessage(response, request, "Unknown action: " + action);
                return;
            }

        } catch (SQLException ex) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            ex.printStackTrace();
            System.out.println("[UpdatePaymentServlet] Error: " + ex.getMessage());
            redirectWithMessage(response, request, "Error: " + ex.getMessage());
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (SQLException ignored) {}
            }
        }
    }

    private void redirectWithMessage(HttpServletResponse response, HttpServletRequest request, String message) throws IOException {
        String encoded = URLEncoder.encode(message, StandardCharsets.UTF_8.toString());
        response.sendRedirect(request.getContextPath() + "/failed_alerts.jsp?message=" + encoded);
    }
}
