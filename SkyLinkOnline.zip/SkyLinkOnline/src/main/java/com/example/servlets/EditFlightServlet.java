package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import com.example.util.DatabaseConnection;
import java.time.LocalDateTime;

public class EditFlightServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (!"flight_scheduler".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String flight_idStr = request.getParameter("flight_id");
        String departure_airport = request.getParameter("departure_airport");
        String arrival_airport = request.getParameter("arrival_airport");
        String departure_date = request.getParameter("departure_date");
        String flight_class = request.getParameter("flight_class");
        String passengersStr = request.getParameter("passengers");
        String available_seatsStr = request.getParameter("available_seats");
        String priceStr = request.getParameter("price");

        System.out.println("[EditFlightServlet] doPost - id=" + flight_idStr + ", dep=" + departure_airport + ", arr=" + arrival_airport + ", date=" + departure_date + ", class=" + flight_class + ", passengers=" + passengersStr + ", seats=" + available_seatsStr + ", price=" + priceStr);

        if (flight_idStr == null || departure_airport == null || arrival_airport == null || departure_date == null || flight_class == null || passengersStr == null || available_seatsStr == null || priceStr == null ||
                flight_idStr.isEmpty() || departure_airport.isEmpty() || arrival_airport.isEmpty() || departure_date.isEmpty() || flight_class.isEmpty() || passengersStr.isEmpty() || available_seatsStr.isEmpty() || priceStr.isEmpty()) {
            response.sendRedirect("edit_flight.jsp?message=Please fill all fields");
            return;
        }

        int flight_id = Integer.parseInt(flight_idStr);
        int passengers = Integer.parseInt(passengersStr);
        int available_seats = Integer.parseInt(available_seatsStr);
        double price = Double.parseDouble(priceStr);

        try {
            // Parse the ISO datetime string to LocalDateTime
            LocalDateTime departureDateTime = LocalDateTime.parse(departure_date);
            Timestamp departureTimestamp = Timestamp.valueOf(departureDateTime);
            
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("UPDATE Flights SET departure_airport = ?, arrival_airport = ?, departure_date = ?, flight_class = ?, passengers = ?, available_seats = ?, price = ? WHERE id = ?")) {
                stmt.setString(1, departure_airport);
                stmt.setString(2, arrival_airport);
                stmt.setTimestamp(3, departureTimestamp);
                stmt.setString(4, flight_class);
                stmt.setInt(5, passengers);
                stmt.setInt(6, available_seats);
                stmt.setDouble(7, price);
                stmt.setInt(8, flight_id);
                int updated = stmt.executeUpdate();
                if (updated > 0) {
                    System.out.println("[EditFlightServlet] Flight updated successfully, id=" + flight_id);
                    response.sendRedirect("scheduler_dashboard.jsp?message=Flight updated successfully");
                } else {
                    System.out.println("[EditFlightServlet] Flight not found, id=" + flight_id);
                    response.sendRedirect("edit_flight.jsp?message=Flight not found");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("[EditFlightServlet] Error updating flight: " + e.getMessage());
            response.sendRedirect("edit_flight.jsp?message=Error updating flight");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("[EditFlightServlet] Error parsing date: " + e.getMessage());
            response.sendRedirect("edit_flight.jsp?message=Invalid date format");
        }
    }
}