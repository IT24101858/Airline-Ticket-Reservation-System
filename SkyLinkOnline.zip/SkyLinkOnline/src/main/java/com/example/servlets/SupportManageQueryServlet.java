package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;

public class SupportManageQueryServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (!"support_officer".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        String idStr = request.getParameter("id");
        if (action == null || idStr == null) {
            response.sendRedirect("CustomerSupportDashboard.jsp?error=1");
            return;
        }

        try {
            try (Connection conn = DatabaseConnection.getConnection()) {
                if ("delete".equals(action)) {
                    PreparedStatement ps = conn.prepareStatement("DELETE FROM CustomerQueries WHERE query_id = ?");
                    ps.setInt(1, Integer.parseInt(idStr));
                    ps.executeUpdate();
                } else if ("edit".equals(action)) {
                    String officerResponse = request.getParameter("officer_response");
                    String queryStatus = request.getParameter("query_status");
                    PreparedStatement ps = conn.prepareStatement("UPDATE CustomerQueries SET officer_response = ?, query_status = ?, updated_at = GETDATE(), officer_id = ? WHERE query_id = ?");
                    ps.setString(1, officerResponse);
                    ps.setString(2, queryStatus);
                    ps.setString(3, (String) session.getAttribute("username"));
                    ps.setInt(4, Integer.parseInt(idStr));
                    ps.executeUpdate();
                }
            }
            response.sendRedirect("CustomerSupportDashboard.jsp?success=1");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("CustomerSupportDashboard.jsp?error=1");
        }
    }
}


