package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;

public class RescheduleBookingServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");
        String role = (String) session.getAttribute("role");
        if (userId == null || role == null || !"customer".equals(role)) {
            response.sendRedirect("login.jsp");
            return;
        }

        String bookingIdStr = request.getParameter("booking_id");
        String newFlightIdStr = request.getParameter("new_flight_id");
        String seatsStr = request.getParameter("seats");
        String totalPriceStr = request.getParameter("total_price");
        String bookingDateStr = request.getParameter("booking_date");
        
        // Debug: Print all received parameters
        System.out.println("[DEBUG] Received parameters:");
        System.out.println("  booking_id: " + bookingIdStr);
        System.out.println("  new_flight_id: " + newFlightIdStr);
        System.out.println("  seats: " + seatsStr);
        System.out.println("  total_price: " + totalPriceStr);
        System.out.println("  booking_date: " + bookingDateStr);
        
        if (bookingIdStr == null || newFlightIdStr == null || seatsStr == null
                || bookingIdStr.isEmpty() || newFlightIdStr.isEmpty() || seatsStr.isEmpty()) {
            response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Missing required booking fields", "UTF-8"));
            return;
        }

        int bookingId = Integer.parseInt(bookingIdStr);
        int newFlightId = Integer.parseInt(newFlightIdStr);
        int requestedSeats = Integer.parseInt(seatsStr);
        
        // Parse optional parameters
        Double newTotalPrice = null;
        if (totalPriceStr != null && !totalPriceStr.isEmpty()) {
            try {
                newTotalPrice = Double.parseDouble(totalPriceStr);
            } catch (NumberFormatException e) {
                response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Invalid total price format", "UTF-8"));
                return;
            }
        }
        
        java.sql.Timestamp newBookingDate = null;
        if (bookingDateStr != null && !bookingDateStr.isEmpty()) {
            try {
                // Handle datetime-local format (YYYY-MM-DDTHH:MM)
                String formattedDate = bookingDateStr;
                if (!formattedDate.contains(" ")) {
                    formattedDate = formattedDate.replace("T", " ");
                }
                // Add seconds if not present
                if (!formattedDate.contains(":")) {
                    formattedDate += ":00";
                }
                if (formattedDate.split(":").length == 2) {
                    formattedDate += ":00";
                }
                newBookingDate = java.sql.Timestamp.valueOf(formattedDate);
            } catch (IllegalArgumentException e) {
                System.out.println("[DEBUG] Date parsing error: " + e.getMessage() + " for input: " + bookingDateStr);
                response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Invalid booking date format: " + bookingDateStr, "UTF-8"));
                return;
            }
        }
        
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            int currentFlightId;
            int currentSeats;

            // Validate booking belongs to user and fetch current flight and seats
            try (PreparedStatement getBooking = conn.prepareStatement(
                    "SELECT flight_id, seats, status FROM Bookings WHERE id = ? AND user_id = ?")) {
                getBooking.setInt(1, bookingId);
                getBooking.setInt(2, userId);
                rs = getBooking.executeQuery();
                if (!rs.next()) {
                    conn.rollback();
                    response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Booking not found", "UTF-8"));
                    return;
                }
                currentFlightId = rs.getInt("flight_id");
                currentSeats = rs.getInt("seats");
                String currentStatus = rs.getString("status");
                if ("Cancelled".equalsIgnoreCase(currentStatus)) {
                    conn.rollback();
                    response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Cannot reschedule a cancelled booking", "UTF-8"));
                    return;
                }
            }

            boolean changingFlight = currentFlightId != newFlightId;

            // Fetch new flight availability and unit price if needed
            int availableSeats = 0;
            double unitPrice = 0.0;
            try (PreparedStatement chk = conn.prepareStatement("SELECT available_seats, price FROM Flights WHERE id = ?")) {
                chk.setInt(1, newFlightId);
                try (ResultSet rs2 = chk.executeQuery()) {
                    if (!rs2.next()) {
                        conn.rollback();
                        response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("New flight not found", "UTF-8"));
                        return;
                    }
                    availableSeats = rs2.getInt("available_seats");
                    unitPrice = rs2.getDouble("price");
                }
            }

            if (availableSeats < requestedSeats) {
                conn.rollback();
                response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Not enough seats on new flight", "UTF-8"));
                return;
            }

            // Adjust flight inventories
            if (changingFlight) {
                // return all current seats to old flight, take requested seats from new flight
                try (PreparedStatement addBack = conn.prepareStatement(
                        "UPDATE Flights SET available_seats = available_seats + ? WHERE id = ?")) {
                    addBack.setInt(1, currentSeats);
                    addBack.setInt(2, currentFlightId);
                    addBack.executeUpdate();
                }
                try (PreparedStatement takeNew = conn.prepareStatement(
                        "UPDATE Flights SET available_seats = available_seats - ? WHERE id = ?")) {
                    takeNew.setInt(1, requestedSeats);
                    takeNew.setInt(2, newFlightId);
                    takeNew.executeUpdate();
                }
            } else {
                // Same flight, adjust by delta
                int delta = requestedSeats - currentSeats;
                if (delta != 0) {
                    if (delta > 0 && availableSeats < delta) {
                        conn.rollback();
                        response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Not enough seats on this flight for seat increase", "UTF-8"));
                        return;
                    }
                    try (PreparedStatement updSeats = conn.prepareStatement(
                            "UPDATE Flights SET available_seats = available_seats - ? WHERE id = ?")) {
                        updSeats.setInt(1, delta);
                        updSeats.setInt(2, newFlightId);
                        updSeats.executeUpdate();
                    }
                }
            }

            // Recalculate total price
            double totalPrice = unitPrice * requestedSeats;

            // Update booking fields with all modifiable fields
            StringBuilder updateQuery = new StringBuilder("UPDATE Bookings SET flight_id = ?, seats = ?");
            java.util.List<Object> params = new java.util.ArrayList<>();
            params.add(newFlightId);
            params.add(requestedSeats);
            
            // Add total_price if provided
            if (newTotalPrice != null) {
                updateQuery.append(", total_price = ?");
                params.add(newTotalPrice);
                System.out.println("[DEBUG] Using custom total price: " + newTotalPrice);
            } else {
                updateQuery.append(", total_price = ?");
                params.add(totalPrice); // Use calculated total price
                System.out.println("[DEBUG] Using calculated total price: " + totalPrice);
            }
            
            // Add booking_date if provided
            if (newBookingDate != null) {
                updateQuery.append(", booking_date = ?");
                params.add(newBookingDate);
                System.out.println("[DEBUG] Using custom booking date: " + newBookingDate);
            }
            
            // Keep status unchanged (no status modification allowed)
            updateQuery.append(", status = CASE WHEN status = 'Cancelled' THEN 'Pending' ELSE status END");
            System.out.println("[DEBUG] Using default status logic - keeping current status");
            
            updateQuery.append(" WHERE id = ?");
            params.add(bookingId);
            
            System.out.println("[DEBUG] Final update query: " + updateQuery.toString());
            System.out.println("[DEBUG] Parameters: " + params.toString());
            
            try (PreparedStatement upd = conn.prepareStatement(updateQuery.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    upd.setObject(i + 1, params.get(i));
                }
                int rowsUpdated = upd.executeUpdate();
                System.out.println("[DEBUG] Rows updated: " + rowsUpdated);
                if (rowsUpdated == 0) {
                    conn.rollback();
                    response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("No booking found to update", "UTF-8"));
                    return;
                }
            }

            conn.commit();
            response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Booking updated successfully", "UTF-8"));
        } catch (Exception e) {
            System.out.println("[DEBUG] Exception occurred: " + e.getMessage());
            e.printStackTrace();
            if (conn != null) {
                try { 
                    conn.rollback(); 
                    System.out.println("[DEBUG] Transaction rolled back");
                } catch (SQLException rollbackEx) {
                    System.out.println("[DEBUG] Rollback failed: " + rollbackEx.getMessage());
                }
            }
            response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Error updating booking: " + e.getMessage(), "UTF-8"));
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException ignored) {}
            try { if (conn != null) { conn.setAutoCommit(true); conn.close(); } } catch (SQLException ignored) {}
        }
    }
}


