package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;
import com.example.util.FlightBookingSubject;
import com.example.util.DynamicObserverManager;

public class CancelBookingServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");
        String role = (String) session.getAttribute("role");
        if (userId == null || role == null || !"customer".equals(role)) {
            response.sendRedirect("login.jsp");
            return;
        }

        String bookingIdStr = request.getParameter("booking_id");
        if (bookingIdStr == null || bookingIdStr.trim().isEmpty()) {
            response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Missing booking id", "UTF-8"));
            return;
        }

        int bookingId = Integer.parseInt(bookingIdStr);

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // Ensure the booking belongs to this user and is cancellable
            try (PreparedStatement check = conn.prepareStatement(
                    "SELECT b.id, b.seats, b.status, b.flight_id FROM Bookings b WHERE b.id = ? AND b.user_id = ?")) {
                check.setInt(1, bookingId);
                check.setInt(2, userId);
                rs = check.executeQuery();
                if (!rs.next()) {
                    conn.rollback();
                    response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Booking not found", "UTF-8"));
                    return;
                }
                String status = rs.getString("status");
                int seats = rs.getInt("seats");
                int flightId = rs.getInt("flight_id");

                if ("Cancelled".equalsIgnoreCase(status)) {
                    conn.rollback();
                    response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Booking already cancelled", "UTF-8"));
                    return;
                }

                // Mark booking cancelled
                try (PreparedStatement upd = conn.prepareStatement("UPDATE Bookings SET status = 'Cancelled' WHERE id = ?")) {
                    upd.setInt(1, bookingId);
                    upd.executeUpdate();
                }

                // Return seats to flight inventory
                try (PreparedStatement updSeats = conn.prepareStatement(
                        "UPDATE Flights SET available_seats = available_seats + ? WHERE id = ?")) {
                    updSeats.setInt(1, seats);
                    updSeats.setInt(2, flightId);
                    updSeats.executeUpdate();
                }
                
                // Notify observers about the flight cancellation using user-specific data
                DynamicObserverManager.getInstance().notifyUserFlightCancelled(userId, flightId, seats);
            }

            conn.commit();
            
            response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Booking cancelled", "UTF-8"));
        } catch (Exception e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignore) {}
            }
            response.sendRedirect("dashboard.jsp?message=" + java.net.URLEncoder.encode("Error cancelling booking: " + e.getMessage(), "UTF-8"));
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException ignored) {}
            try { if (pstmt != null) pstmt.close(); } catch (SQLException ignored) {}
            try { if (conn != null) { conn.setAutoCommit(true); conn.close(); } } catch (SQLException ignored) {}
        }
    }
}


