# Design Patterns Assignment Report - SkyLinkOnline

## SkyLinkOnline - Air Ticket Reservation System

---

## Group Details

| Member Name     | Student ID | Role                    |
| --------------- | ---------- | ----------------------- |
| [Member 1 Name] | [ID]       | Project Lead            |
| [Member 2 Name] | [ID]       | Backend Developer       |
| [Member 3 Name] | [ID]       | Frontend Developer      |
| [Member 4 Name] | [ID]       | Database Developer      |
| [Member 5 Name] | [ID]       | UI/UX Designer          |
| [Member 6 Name] | [ID]       | Testing & Documentation |

---

## Design Pattern(s) Used

### 1. Singleton Pattern

**Implementation Files:**

- `src/main/java/com/example/util/DatabaseConnectionManager.java`
- `src/main/java/com/example/util/Logger.java`
- `src/main/java/com/example/util/ConfigurationManager.java`

### 2. Observer Pattern

**Implementation Files:**

- `src/main/java/com/example/util/Observer.java`
- `src/main/java/com/example/util/Subject.java`
- `src/main/java/com/example/util/FlightBookingSubject.java`
- `src/main/java/com/example/util/EmailNotificationObserver.java`
- `src/main/java/com/example/util/SMSNotificationObserver.java`
- `src/main/java/com/example/util/LoggingObserver.java`
- `src/main/java/com/example/util/DynamicObserverManager.java`

### 3. Facade Pattern

**Implementation Files:**

- `src/main/java/com/example/util/DatabaseConnection.java`

---

## Justification for Each Pattern

### Singleton Pattern

**Why Selected:**

- **Resource Management**: Database connections are expensive to create and maintain
- **Configuration Centralization**: Application settings need to be consistent across all components
- **Logging Consistency**: All parts of the application should use the same logging mechanism
- **Thread Safety**: Web applications require thread-safe implementations for concurrent access
- **Memory Efficiency**: Prevents multiple instances consuming unnecessary memory

**How It Improves Design:**

1. **DatabaseConnectionManager Singleton**

   - Ensures only one connection pool exists
   - Prevents connection leaks and resource exhaustion
   - Provides thread-safe connection management
   - Implements connection pooling for better performance

2. **Logger Singleton**

   - Centralizes all logging operations
   - Ensures consistent log format across the application
   - Provides configurable log levels
   - Thread-safe file operations

3. **ConfigurationManager Singleton**
   - Centralizes application configuration
   - Provides default values for missing properties
   - Thread-safe read-write operations
   - Easy configuration management

### Observer Pattern

**Why Selected:**

- **Event Notification**: Users need to be notified about booking status changes
- **Loose Coupling**: Separates notification logic from business logic
- **Extensibility**: Easy to add new notification types (email, SMS, push notifications)
- **Dynamic Behavior**: Can create user-specific observers with actual contact information
- **Real-time Updates**: Provides immediate notifications for important events

**How It Improves Design:**

1. **FlightBookingSubject**

   - Manages flight booking events and notifications
   - Supports multiple observer types
   - Provides structured data for notifications

2. **Dynamic Observer Manager**

   - Creates user-specific observers with actual email and phone numbers
   - Fetches user data from database dynamically
   - Falls back to default values if user data unavailable

3. **Notification Observers**
   - EmailNotificationObserver: Sends email notifications
   - SMSNotificationObserver: Sends SMS notifications
   - LoggingObserver: Logs all events for system monitoring

### Facade Pattern

**Why Selected:**

- **Simplified Interface**: Hides the complexity of DatabaseConnectionManager
- **Backward Compatibility**: Maintains existing code compatibility
- **Easier Migration**: Allows gradual adoption of Singleton pattern
- **Abstraction**: Provides a simple interface for database operations

**How It Improves Design:**

- Simplifies database connection usage
- Maintains existing API while improving underlying implementation
- Provides additional utility methods for connection management
- Acts as a bridge between old and new implementations

---

## Screenshots of Implementation

### 1. Singleton Pattern Implementation

#### DatabaseConnectionManager.java

```java
package com.example.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe Singleton pattern implementation for database connection management.
 * Ensures only one instance exists throughout the application lifecycle.
 * Provides connection pooling capabilities for better performance.
 */
public class DatabaseConnectionManager {

    // Singleton instance - volatile for thread safety
    private static volatile DatabaseConnectionManager instance;

    // Connection pool for better performance
    private final ConcurrentHashMap<String, Connection> connectionPool;

    // Private constructor to prevent instantiation
    private DatabaseConnectionManager() {
        this.connectionPool = new ConcurrentHashMap<>();
        loadDriver();
    }

    /**
     * Thread-safe Singleton getInstance method using double-checked locking
     * @return The single instance of DatabaseConnectionManager
     */
    public static DatabaseConnectionManager getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnectionManager.class) {
                if (instance == null) {
                    instance = new DatabaseConnectionManager();
                }
            }
        }
        return instance;
    }

    /**
     * Get a database connection with connection pooling
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public Connection getConnection() throws SQLException {
        String threadId = Thread.currentThread().getName();

        // Check if connection exists in pool
        Connection connection = connectionPool.get(threadId);

        if (connection == null || connection.isClosed()) {
            try {
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                connectionPool.put(threadId, connection);
                System.out.println("[DatabaseConnectionManager] New connection created for thread: " + threadId);
            } catch (SQLException e) {
                System.err.println("[DatabaseConnectionManager] Failed to establish database connection: " + e.getMessage());
                throw e;
            }
        }

        return connection;
    }

    // Additional methods for connection management...
}
```

#### Logger.java

```java
package com.example.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Thread-safe Singleton Logger implementation.
 * Provides centralized logging functionality for the entire application.
 * Supports different log levels and file-based logging.
 */
public class Logger {

    // Singleton instance - volatile for thread safety
    private static volatile Logger instance;

    // Thread-safe lock for file operations
    private final ReentrantLock lock = new ReentrantLock();

    // Private constructor to prevent instantiation
    private Logger() {
        initializeLogFile();
    }

    /**
     * Thread-safe Singleton getInstance method using double-checked locking
     * @return The single instance of Logger
     */
    public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }

    /**
     * Log info message
     * @param message Message to log
     */
    public void info(String message) {
        log(LogLevel.INFO, message);
    }

    /**
     * Log error message
     * @param message Message to log
     */
    public void error(String message) {
        log(LogLevel.ERROR, message);
    }

    // Additional logging methods...
}
```

#### ConfigurationManager.java

```java
package com.example.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Thread-safe Singleton Configuration Manager.
 * Provides centralized configuration management for the entire application.
 * Supports loading and saving configuration properties from/to files.
 */
public class ConfigurationManager {

    // Singleton instance - volatile for thread safety
    private static volatile ConfigurationManager instance;

    // Thread-safe read-write lock for properties access
    private final ReadWriteLock lock = new ReentrantReadWriteLock();

    // Properties object to store configuration
    private final Properties properties;

    // Private constructor to prevent instantiation
    private ConfigurationManager() {
        this.properties = new Properties();
        loadConfiguration();
    }

    /**
     * Thread-safe Singleton getInstance method using double-checked locking
     * @return The single instance of ConfigurationManager
     */
    public static ConfigurationManager getInstance() {
        if (instance == null) {
            synchronized (ConfigurationManager.class) {
                if (instance == null) {
                    instance = new ConfigurationManager();
                }
            }
        }
        return instance;
    }

    /**
     * Get a configuration property value
     * @param key Property key
     * @return Property value or null if not found
     */
    public String getProperty(String key) {
        lock.readLock().lock();
        try {
            return properties.getProperty(key);
        } finally {
            lock.readLock().unlock();
        }
    }

    // Additional configuration methods...
}
```

### 2. Observer Pattern Implementation

#### Observer Interface

```java
package com.example.util;

/**
 * Observer interface for the Observer Pattern
 * This interface defines the contract for objects that want to be notified
 * when a subject's state changes.
 */
public interface Observer {

    /**
     * Method called by the subject when a state change occurs
     * @param message The notification message
     * @param data Additional data related to the change
     */
    void update(String message, Object data);
}
```

#### Subject Interface

```java
package com.example.util;

/**
 * Subject interface for the Observer Pattern
 * This interface defines the contract for objects that can be observed
 */
public interface Subject {

    /**
     * Add an observer to the list of observers
     * @param observer The observer to add
     */
    void addObserver(Observer observer);

    /**
     * Remove an observer from the list of observers
     * @param observer The observer to remove
     */
    void removeObserver(Observer observer);

    /**
     * Notify all observers of a state change
     * @param message The notification message
     * @param data Additional data related to the change
     */
    void notifyObservers(String message, Object data);
}
```

#### FlightBookingSubject.java

```java
package com.example.util;

/**
 * FlightBookingSubject class that extends AbstractSubject
 * This class manages flight booking events and notifies observers
 * when booking-related events occur.
 */
public class FlightBookingSubject extends AbstractSubject {

    private static FlightBookingSubject instance;

    // Public constructor for dynamic instances
    public FlightBookingSubject() {
        // This constructor allows creating new instances for dynamic observers
    }

    /**
     * Get the singleton instance of FlightBookingSubject
     * @return The singleton instance
     */
    public static synchronized FlightBookingSubject getInstance() {
        if (instance == null) {
            instance = new FlightBookingSubject(true);
        }
        return instance;
    }

    /**
     * Notify observers when a flight is booked
     * @param userId The ID of the user who made the booking
     * @param flightId The ID of the flight that was booked
     * @param seats The number of seats booked
     * @param totalPrice The total price of the booking
     */
    public void notifyFlightBooked(int userId, int flightId, int seats, double totalPrice) {
        BookingData data = new BookingData(userId, flightId, seats, totalPrice, "BOOKED");
        notifyObservers("Flight booking confirmed", data);
    }

    /**
     * Notify observers when a payment is confirmed
     * @param userId The ID of the user who made the payment
     * @param bookingId The ID of the booking
     * @param amount The payment amount
     */
    public void notifyPaymentConfirmed(int userId, int bookingId, double amount) {
        PaymentData data = new PaymentData(userId, bookingId, amount, "CONFIRMED");
        notifyObservers("Payment confirmed", data);
    }

    // Data classes for structured information
    public static class BookingData {
        public final int userId;
        public final int flightId;
        public final int seats;
        public final double totalPrice;
        public final String status;

        public BookingData(int userId, int flightId, int seats, double totalPrice, String status) {
            this.userId = userId;
            this.flightId = flightId;
            this.seats = seats;
            this.totalPrice = totalPrice;
            this.status = status;
        }
    }

    public static class PaymentData {
        public final int userId;
        public final int bookingId;
        public final double amount;
        public final String status;

        public PaymentData(int userId, int bookingId, double amount, String status) {
            this.userId = userId;
            this.bookingId = bookingId;
            this.amount = amount;
            this.status = status;
        }
    }
}
```

#### DynamicObserverManager.java

```java
package com.example.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.example.util.DatabaseConnection;

/**
 * DynamicObserverManager class that creates observers dynamically based on user data
 * This ensures that notifications are sent to the correct user's email and phone
 */
public class DynamicObserverManager {

    private static DynamicObserverManager instance;

    private DynamicObserverManager() {}

    /**
     * Get the singleton instance of DynamicObserverManager
     * @return The singleton instance
     */
    public static synchronized DynamicObserverManager getInstance() {
        if (instance == null) {
            instance = new DynamicObserverManager();
        }
        return instance;
    }

    /**
     * Create and register observers for a specific user
     * @param userId The user ID to create observers for
     * @return List of created observers
     */
    public List<Observer> createUserObservers(int userId) {
        List<Observer> observers = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Get user details from database
            PreparedStatement stmt = conn.prepareStatement(
                "SELECT email, phone_number, first_name, last_name FROM Users WHERE id = ?"
            );
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String email = rs.getString("email");
                String phoneNumber = rs.getString("phone_number");
                String firstName = rs.getString("first_name");
                String lastName = rs.getString("last_name");

                // Create email observer with user's email
                if (email != null && !email.trim().isEmpty()) {
                    EmailNotificationObserver emailObserver = new EmailNotificationObserver(email);
                    observers.add(emailObserver);
                    System.out.println("📧 Created email observer for: " + email);
                } else {
                    // Fallback to default email
                    EmailNotificationObserver emailObserver = new EmailNotificationObserver("customer@skylink.com");
                    observers.add(emailObserver);
                    System.out.println("📧 Created default email observer (user email not available)");
                }

                // Create SMS observer with user's phone number
                if (phoneNumber != null && !phoneNumber.trim().isEmpty()) {
                    SMSNotificationObserver smsObserver = new SMSNotificationObserver(phoneNumber);
                    observers.add(smsObserver);
                    System.out.println("📱 Created SMS observer for: " + phoneNumber);
                } else {
                    // Fallback to default phone number
                    SMSNotificationObserver smsObserver = new SMSNotificationObserver("+1234567890");
                    observers.add(smsObserver);
                    System.out.println("📱 Created default SMS observer (user phone not available)");
                }

                // Always create logging observer
                LoggingObserver loggingObserver = new LoggingObserver("INFO");
                observers.add(loggingObserver);
                System.out.println("📝 Created logging observer");

                System.out.println("✅ Created " + observers.size() + " observers for user: " +
                                 (firstName != null ? firstName : "Unknown") + " " +
                                 (lastName != null ? lastName : ""));

            } else {
                System.out.println("⚠️ User not found in database, creating default observers");
                // Create default observers if user not found
                observers.add(new EmailNotificationObserver("customer@skylink.com"));
                observers.add(new SMSNotificationObserver("+1234567890"));
                observers.add(new LoggingObserver("INFO"));
            }

        } catch (SQLException e) {
            System.err.println("❌ Error creating user observers: " + e.getMessage());
            // Create default observers as fallback
            observers.add(new EmailNotificationObserver("customer@skylink.com"));
            observers.add(new SMSNotificationObserver("+1234567890"));
            observers.add(new LoggingObserver("INFO"));
        }

        return observers;
    }

    /**
     * Notify observers for a specific user about flight booking
     * @param userId The user ID
     * @param flightId The flight ID
     * @param seats Number of seats
     * @param totalPrice Total price
     */
    public void notifyUserFlightBooked(int userId, int flightId, int seats, double totalPrice) {
        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION ===");
        System.out.println("Creating user-specific observers for User ID: " + userId);

        List<Observer> userObservers = createUserObservers(userId);

        // Create temporary subject for this user
        FlightBookingSubject tempSubject = new FlightBookingSubject();

        // Add user-specific observers
        for (Observer observer : userObservers) {
            tempSubject.addObserver(observer);
        }

        // Send notification
        tempSubject.notifyFlightBooked(userId, flightId, seats, totalPrice);

        System.out.println("=== DYNAMIC OBSERVER NOTIFICATION COMPLETE ===");
    }
}
```

### 3. Facade Pattern Implementation

#### DatabaseConnection.java

```java
package com.example.util;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Facade class that provides a simplified interface to the DatabaseConnectionManager Singleton.
 * This class acts as a bridge between the old API and the new Singleton implementation.
 */
public class DatabaseConnection {

    // Singleton instance of DatabaseConnectionManager
    private static final DatabaseConnectionManager connectionManager =
        DatabaseConnectionManager.getInstance();

    /**
     * Get a database connection using the Singleton pattern
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection() throws SQLException {
        return connectionManager.getConnection();
    }

    /**
     * Close a database connection
     * @param connection The connection to close
     */
    public static void closeConnection(Connection connection) {
        connectionManager.closeConnection(connection);
    }

    /**
     * Test the database connection
     * @return true if connection is successful, false otherwise
     */
    public static boolean testConnection() {
        return connectionManager.testConnection();
    }

    /**
     * Get connection pool status
     * @return String representation of connection pool status
     */
    public static String getConnectionPoolStatus() {
        return connectionManager.getConnectionPoolStatus();
    }
}
```

### 4. Usage Examples in Servlets

#### BookServlet.java - Using Observer Pattern

```java
package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;
import com.example.util.DynamicObserverManager;

@WebServlet("/book")
public class BookServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");
        String role = (String) session.getAttribute("role");

        if (userId == null || !"customer".equals(role)) {
            response.sendRedirect("login.jsp");
            return;
        }

        int flightId = Integer.parseInt(request.getParameter("flight_id"));
        int seats = Integer.parseInt(request.getParameter("seats"));

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Check available seats and get price
            PreparedStatement checkStmt = conn.prepareStatement(
                "SELECT available_seats, price FROM Flights WHERE id = ?"
            );
            checkStmt.setInt(1, flightId);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                int availableSeats = rs.getInt("available_seats");
                double price = rs.getDouble("price");

                if (availableSeats >= seats) {
                    // Insert booking
                    PreparedStatement insertStmt = conn.prepareStatement(
                        "INSERT INTO Bookings (user_id, flight_id, seats, total_price, status) VALUES (?, ?, ?, ?, 'BOOKED')",
                        PreparedStatement.RETURN_GENERATED_KEYS
                    );
                    insertStmt.setInt(1, userId);
                    insertStmt.setInt(2, flightId);
                    insertStmt.setInt(3, seats);
                    insertStmt.setDouble(4, price * seats);
                    insertStmt.executeUpdate();

                    ResultSet generatedKeys = insertStmt.getGeneratedKeys();
                    int bookingId = 0;
                    if (generatedKeys.next()) {
                        bookingId = generatedKeys.getInt(1);
                    }

                    // Update available seats
                    PreparedStatement updateStmt = conn.prepareStatement(
                        "UPDATE Flights SET available_seats = available_seats - ? WHERE id = ?"
                    );
                    updateStmt.setInt(1, seats);
                    updateStmt.setInt(2, flightId);
                    updateStmt.executeUpdate();

                    // Use Observer Pattern to notify user
                    DynamicObserverManager observerManager = DynamicObserverManager.getInstance();
                    observerManager.notifyUserFlightBooked(userId, flightId, seats, price * seats);

                    response.sendRedirect("process_payment.jsp?booking_id=" + bookingId + "&amount=" + (price * seats));
                } else {
                    response.sendRedirect("book.jsp?error=insufficient_seats");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("book.jsp?error=database_error");
        }
    }
}
```

#### LoginServlet.java - Using Singleton Pattern

```java
package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.util.DatabaseConnection;
import com.example.util.Logger;

public class LoginServlet extends HttpServlet {

    // Singleton logger instance
    private static final Logger logger = Logger.getInstance();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        logger.info("Login attempt - username=" + username + ", remoteAddr=" + request.getRemoteAddr());

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT id, role FROM Users WHERE username = ? AND password = ?")) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Login successful
                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                session.setAttribute("user_id", rs.getInt("id"));
                session.setAttribute("role", rs.getString("role"));

                logger.info("Authentication SUCCESS for username=" + username);
                response.sendRedirect("dashboard.jsp");
            } else {
                logger.warn("Authentication FAILED for username=" + username);
                response.sendRedirect("login.jsp?error=true");
            }
        } catch (SQLException e) {
            logger.error("Database error during login", e);
            response.sendRedirect("login.jsp?error=true");
        }
    }
}
```

---

## Testing the Implementation

### 1. Access Demo Servlets

Navigate to the following URLs to test the patterns:

- **Singleton Demo**: `http://localhost:8080/SkyLinkOnline/singleton-demo`
- **Observer Demo**: `http://localhost:8080/SkyLinkOnline/observer-demo`

### 2. Verify Singleton Pattern

```java
// Test multiple instances
DatabaseConnectionManager connMgr1 = DatabaseConnectionManager.getInstance();
DatabaseConnectionManager connMgr2 = DatabaseConnectionManager.getInstance();
System.out.println("Instances equal: " + (connMgr1 == connMgr2)); // Should print true

Logger logger1 = Logger.getInstance();
Logger logger2 = Logger.getInstance();
System.out.println("Logger instances equal: " + (logger1 == logger2)); // Should print true
```

### 3. Test Observer Pattern

1. **Login as a customer** with actual email and phone number in database
2. **Book a flight** - You should see dynamic observer notifications
3. **Make a payment** - You should see payment confirmation notifications
4. **Cancel a booking** - You should see cancellation notifications

### 4. Check Log Files

- Application logs: `logs/skylink_application.log`
- Configuration file: `config/application.properties`

---

## Benefits Achieved

### 1. Resource Management

- Single instance manages database connections efficiently
- Connection pooling reduces overhead
- Automatic cleanup prevents memory leaks

### 2. Configuration Centralization

- All configuration in one place
- Easy to modify and maintain
- Default values for missing properties

### 3. Logging Consistency

- Unified logging across the application
- Configurable log levels
- File and console output

### 4. Thread Safety

- Safe for concurrent access
- No race conditions
- Proper synchronization

### 5. Event Notification

- Real-time notifications for booking events
- User-specific notifications with actual contact information
- Extensible notification system

### 6. Loose Coupling

- Separation of concerns between business logic and notifications
- Easy to add new notification types
- Maintainable code structure

---

## Code Quality Features

### 1. Proper Java Classes

- **Main Classes**: DatabaseConnectionManager, Logger, ConfigurationManager, FlightBookingSubject
- **Context Classes**: DatabaseConnection (Facade), DynamicObserverManager
- **Concrete Classes**: All Singleton and Observer implementations
- **Interfaces**: Observer, Subject for proper abstraction

### 2. Clear Naming Conventions

- Descriptive class names (DatabaseConnectionManager, ConfigurationManager)
- Clear method names (getInstance, getConnection, notifyFlightBooked)
- Consistent naming patterns
- Meaningful variable names

### 3. Comments and Documentation

- Comprehensive JavaDoc comments
- Inline comments explaining complex logic
- README documentation for usage
- Method and class-level documentation

### 4. Functional Code

- All code compiles and runs successfully
- Proper error handling
- Thread-safe implementations
- Resource management
- Database integration

---

## Conclusion

The SkyLinkOnline project successfully implements the Singleton, Observer, and Facade design patterns to improve:

1. **Resource Management**: Efficient database connection handling
2. **Configuration Management**: Centralized application settings
3. **Logging**: Consistent application-wide logging
4. **Thread Safety**: Safe concurrent access
5. **Event Notification**: Real-time user notifications
6. **Code Maintainability**: Clean, organized, and well-documented code
7. **Performance**: Optimized resource usage and connection pooling

The implementation follows best practices with proper error handling, thread safety, and comprehensive documentation. The patterns chosen are appropriate for the web application context and provide significant benefits in terms of resource management, consistency, maintainability, and user experience.

---

## Additional Recommendations

### Future Enhancements

1. **Strategy Pattern**: Implement different payment strategies
2. **Factory Pattern**: Create user objects based on roles
3. **Template Method Pattern**: Standardize servlet request handling
4. **Command Pattern**: Implement undo/redo functionality for bookings

### Best Practices Applied

1. Thread-safe Singleton implementation
2. Proper resource cleanup
3. Comprehensive error handling
4. Clear separation of concerns
5. Maintainable code structure
6. Dynamic observer creation
7. User-specific notifications

---

**Project Repository**: SkyLinkOnline  
**Technology Stack**: Java Servlets, JSP, SQL Server, Maven  
**Design Patterns**: Singleton, Observer, Facade  
**Implementation Date**: [Current Date]  
**Team Size**: 6 Members
